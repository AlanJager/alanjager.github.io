#!/usr/bin/env python3
import csv,gzip,hashlib,json,pathlib,re,statistics
root=pathlib.Path(__file__).resolve().parent
rows=[];churn=[];trace_summary=[];functions=[];budget=[]
for path in sorted((root/'results').glob('*.log')):
 variant,mode,rep=path.stem.split('-');text=path.read_text(errors='replace')
 if 'FBATCH_DONE' not in text:continue
 for traced,batch,attempt,ns in re.findall(r'SAMPLE traced=(\d+) batch=(\d+) attempt=(\d+) ns=(\d+)',text):
  rows.append(dict(variant=variant,mode=mode,rep=int(rep),batch=int(batch),attempt=int(attempt),ns=int(ns)))
 for ns in re.findall(r'CHURN_PASS .*? ns=(\d+)',text):churn.append(dict(variant=variant,rep=int(rep),ns=int(ns)))
 for batch,calls,ns in re.findall(r'BUDGET_PASS batch=(\d+) pages=4096 calls=(\d+) sum_syscall_ns=(\d+)',text):
  budget.append(dict(variant=variant,rep=int(rep),batch=int(batch),pages=4096,calls=int(calls),sum_syscall_ns=int(ns)))
 if mode=='pressure':
  raw=gzip.decompress(path.with_suffix('.trace.gz').read_bytes())
  assert hashlib.sha256(raw).hexdigest()==re.search(r'TRACE_SHA256 ([0-9a-f]{64})',text)[1]
  (root/'results'/f'{variant}.pressure.trace').write_bytes(raw)
 if mode=='trace':
  raw=gzip.decompress(path.with_suffix('.trace.gz').read_bytes())
  assert hashlib.sha256(raw).hexdigest()==re.search(r'TRACE_SHA256 ([0-9a-f]{64})',text)[1]
  (root/'results'/f'{variant}.trace').write_bytes(raw)
  t=raw.decode(errors='replace')
  trace_summary.append(dict(variant=variant,bytes=len(raw),lru_cache_disable_calls=len(re.findall(r'lru_cache_disable\(\)',t)),synchronize_rcu_expedited_calls=len(re.findall(r'synchronize_rcu_expedited\(\)',t)),move_begin_markers=t.count('MOVE_BEGIN'),move_end_markers=t.count('MOVE_END')))
  stack=[];batch=None;attempt=None;roots=0
  for line in t.splitlines():
   marker=re.search(r'MOVE_BEGIN batch=(\d+) attempt=(\d+)',line)
   if marker:
    assert not stack,line
    batch,attempt=map(int,marker.groups())
   if '|' not in line:continue
   call=line.rsplit('|',1)[1].strip();duration=re.search(r'(\d+\.\d+) us',line)
   if call.endswith('() {'):stack.append(call[:-4])
   elif call=='}':
    assert stack and duration,line
    name=stack.pop();functions.append(dict(variant=variant,batch=batch,attempt=attempt,name=name,ancestry='>'.join(stack),inclusive_us=float(duration[1])))
    if name=='__x64_sys_move_pages':roots+=1
   elif call.endswith('();') and duration:
    functions.append(dict(variant=variant,batch=batch,attempt=attempt,name=call[:-3],ancestry='>'.join(stack),inclusive_us=float(duration[1])))
  assert not stack and roots==9,(variant,len(stack),roots)
with (root/'samples.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=['variant','mode','rep','batch','attempt','ns']);w.writeheader();w.writerows(rows)
summary=[];per_guest=[]
for variant in ('base','patched'):
 for batch in (1,16,256):
  values=sorted(r['ns']/1000 for r in rows if r['variant']==variant and r['mode']=='nop' and r['batch']==batch)
  assert len(values)==600,(variant,batch,len(values))
  summary.append(dict(variant=variant,batch=batch,n=len(values),median_us=statistics.median(values),p95_us=values[int(.95*(len(values)-1))],p99_us=values[int(.99*(len(values)-1))],max_us=max(values)))
  for rep in range(3):
   v=sorted(r['ns']/1000 for r in rows if r['variant']==variant and r['mode']=='nop' and r['batch']==batch and r['rep']==rep)
   assert len(v)==200
   per_guest.append(dict(variant=variant,batch=batch,rep=rep,median_us=statistics.median(v),max_us=max(v)))
function_summary=[]
for variant in ('base','patched'):
 for batch in (1,16,256):
  for name in ('__x64_sys_move_pages','lru_cache_disable','synchronize_rcu_expedited','lru_add_drain_all','__lru_add_drain_all','lru_add_drain_cpu','flush_work','migrate_pages','cram_migrate_to','alloc_cram_folio','folio_mc_copy'):
   v=[x['inclusive_us'] for x in functions if x['variant']==variant and x['batch']==batch and x['name']==name]
   function_summary.append(dict(variant=variant,batch=batch,name=name,n=len(v),median_us=statistics.median(v) if v else None,max_us=max(v) if v else None))
with (root/'functions.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=['variant','batch','attempt','name','ancestry','inclusive_us']);w.writeheader();w.writerows(functions)
assert len(churn)==6 and len(budget)==18
lru_roots=[]
for variant in ('base','patched'):
 for batch in (1,16,256):
  for attempt in range(3):
   f=[x for x in functions if x['variant']==variant and x['batch']==batch and x['attempt']==attempt]
   admission=sum(x['inclusive_us'] for x in f if x['name']=='lru_cache_disable')
   finish=sum(x['inclusive_us'] for x in f if x['name']=='lru_add_drain_all' and 'cram_migrate_to' in x['ancestry'])
   root_time=next(x['inclusive_us'] for x in f if x['name']=='__x64_sys_move_pages')
   lru_roots.append(dict(variant=variant,batch=batch,attempt=attempt,root_inclusive_us=root_time,admission_lru_disable_us=admission,cram_finish_drain_us=finish,nonoverlap_lru_total_us=admission+finish))
result=dict(lru_roots=lru_roots,migration=summary,per_guest=per_guest,budget=budget,churn=churn,traces=trace_summary,function_summary=function_summary)
(root/'summary.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
