#!/bin/bash
set -euo pipefail
cd /opt/cram-lab/cram-fbatch-ab-20261010
variant=${1:?base or patched};mode=${2:?nop trace or churn}
tracefile=${3:-/opt/cram-lab/cram-fbatch-ab-20261010/trace-export.gz}
case "$variant" in base|patched|diagnostic);; *)exit 2;;esac
variant_kernel=build-$variant/arch/x86/boot/bzImage
if [ "$variant" = base ]; then variant_kernel=build-base-fixed/arch/x86/boot/bzImage; fi
if [ "$variant" = diagnostic ]; then variant_kernel=bzImage-promote-failure-test; fi
case "$mode" in nop|trace|churn|budget|safety|pressure|retry);; *)exit 2;;esac
exec timeout 180 /opt/cram-lab/cram-lab-20261009/build-qemu/qemu-system-x86_64 \
 -L /opt/cram-lab/cram-lab-20261009/qemu/pc-bios \
 -machine q35,cxl=on -accel kvm -cpu host -m 512M,maxmem=2G,slots=8 -smp 2 \
 -name fbatch-ab,debug-threads=on \
 -object memory-backend-ram,id=ram0,size=512M \
 -numa node,nodeid=0,memdev=ram0 \
 -numa node,nodeid=1 \
 -kernel "${variant_kernel}" -initrd initramfs.cpio.gz \
 -append "console=ttyS0 nokaslr panic=-1 clocksource=kvm-clock labmode=$mode" \
 -chardev "file,id=trace,path=$tracefile" \
 -device virtio-serial-pci \
 -device virtserialport,chardev=trace,name=lab.trace \
 -qmp unix:qmp.sock,server=on,wait=off \
 -object memory-backend-ram,id=cxl-mem0,size=512M,share=on \
 -object memory-backend-ram,id=cxl-lsa0,size=1M,share=on \
 -device pxb-cxl,bus_nr=12,bus=pcie.0,id=cxl.1 \
 -device cxl-rp,port=0,bus=cxl.1,id=root_port0,chassis=0,slot=2 \
 -device cxl-ct3,bus=root_port0,volatile-memdev=cxl-mem0,lsa=cxl-lsa0,id=cxl-ct3-0 \
 -M cxl-fmw.0.targets.0=cxl.1,cxl-fmw.0.size=1G,cxl-fmw.0.interleave-granularity=8k \
 -display none -serial stdio -monitor none -no-reboot -nic none
