import pathlib,json,re,collections,hashlib,tarfile
r=pathlib.Path(__file__).resolve().parent
runs=json.loads((r/'host-results/runs.json').read_text());rep=int(json.loads((r/'build-metadata.json').read_text())['rep_movsb_rip'],16);out=[]
rx=re.compile(r'-(\d+)\s+\[(\d+)\].*? (\d+\.\d+): (\w+): (.*)')
for run in runs:
 label=run['label'];pid0=int(run['vcpu_tids']['0']);path=r/'host-results'/f'{label}.host.trace';first=set();calls=[];current=None;pending=None;digest=hashlib.sha256();nbytes=0;archive=None
 if path.exists():stream=path.open('rb')
 else:
  archive=tarfile.open(r/'full-host-traces.tar.gz','r:gz');stream=archive.extractfile('host-results/'+path.name)
 for line in stream:
  digest.update(line);nbytes+=len(line);z=rx.search(line.decode(errors='replace'))
  if not z:continue
  pid,cpu,ts,name,args=z.groups();pid=int(pid);ts=float(ts)
  new=False;gpa=None
  if name=='kvm_page_fault':
   gpa=int(re.search(r'address 0x([a-f0-9]+)',args)[1],16)>>12;new=gpa not in first;first.add(gpa)
  if pid!=pid0:continue
  if name=='kvm_pio' and '0x505' in args:
   val=int(re.search(r'val 0x([a-f0-9]+)',args)[1],16)
   if val>>16==1:
    assert current is None
    current=dict(attempt=val&65535,start=ts,copy_ept_exits=0,copy_ept_exit_to_entry_ms=0.,copy_ept_userspace_returns=0,first_observed_fault_pages=0,gpa_pages=[],exit_reasons=collections.Counter());pending=None
   elif val>>16==2:
    assert current and current['attempt']==val&65535
    current['host_pio_window_ms']=(ts-current.pop('start'))*1000;calls.append(current);current=None;pending=None
  if current is None:continue
  if name=='kvm_exit':
   reason=re.search(r'reason (\S+)',args)[1];rip=int(re.search(r'rip 0x([a-f0-9]+)',args)[1],16);current['exit_reasons'][reason]+=1
   pending=dict(start=ts,copy=reason=='EPT_VIOLATION' and rip==rep,userspace=False)
   if pending['copy']:current['copy_ept_exits']+=1
  elif name=='kvm_page_fault' and pending and pending['copy']:
   current['first_observed_fault_pages']+=int(new);current['gpa_pages'].append(gpa)
  elif name=='kvm_userspace_exit' and pending:pending['userspace']=True
  elif name=='kvm_entry' and pending:
   if pending['copy']:
    current['copy_ept_exit_to_entry_ms']+=(ts-pending['start'])*1000;current['copy_ept_userspace_returns']+=int(pending['userspace'])
   pending=None
 stream.close()
 if archive:archive.close()
 assert len(calls)==256 and [c['attempt'] for c in calls]==list(range(256)),(label,len(calls))
 def aggregate(cs):return dict(calls=len(cs),copy_ept_exits=sum(c['copy_ept_exits'] for c in cs),calls_with_copy_ept=sum(c['copy_ept_exits']>0 for c in cs),first_observed_fault_pages=sum(c['first_observed_fault_pages'] for c in cs),copy_ept_exit_to_entry_ms=sum(c['copy_ept_exit_to_entry_ms'] for c in cs),copy_ept_userspace_returns=sum(c['copy_ept_userspace_returns'] for c in cs))
 item=dict(label=label,variant=run['variant'],repeat=run['repeat'],full=aggregate(calls),after_first_two=aggregate(calls[2:]),calls=calls,full_trace_sha256=digest.hexdigest(),full_trace_bytes=nbytes);out.append(item);print(label,item['full'],flush=True)
(r/'host-summary.json').write_text(json.dumps(out,indent=2))
