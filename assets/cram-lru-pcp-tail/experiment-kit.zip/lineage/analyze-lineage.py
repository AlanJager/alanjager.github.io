import pathlib,re,json,collections,csv,gzip,hashlib
r=pathlib.Path(__file__).resolve().parent;runs=json.loads((r/'host-results/runs.json').read_text());hosts={x['label']:x for x in json.loads((r/'host-summary.json').read_text())};summary=[];all_alloc=[];all_chains=[]
rx=re.compile(r'-(\d+)\s+\[(\d+)\].*? (\d+\.\d+): (\w+): (.*)')
for run in runs:
 label=run['label'];host=hosts[label];raw=gzip.decompress((r/'host-results'/f'{label}.guest.trace.gz').read_bytes());log=(r/'host-results'/f'{label}.log').read_text();assert hashlib.sha256(raw).hexdigest()==re.search(r'TRACE_SHA256 ([a-f0-9]{64})',log)[1]
 states={};generations=collections.Counter();release={};dequeues={};allocs={};seen_alloc=set();records=[];chains=[];attempt=-1;seq=0;send_stack={};sends=[];cpu_events=collections.defaultdict(collections.Counter);base_values=set();first_pfns=set();pcp_cpu={};release_count=0;enqueue_count=0;drain_count=0;refill_count=0;copy_pfn_counts=collections.Counter();pcp_misses=0;enqueued_generations=set()
 def pfn(args,key='page'):
  pointer=int(re.search(key+r'=(0x[0-9a-f]+)',args)[1],16);base=int(re.search(r'base=(0x[0-9a-f]+)',args)[1],16);base_values.add(base)
  if not pointer:return None
  assert base==0xffd4000000000000 and (pointer-base)%64==0,(label,key,hex(pointer),hex(base))
  return (pointer-base)//64
 def field(args,key):return int(re.search(key+r'=(0x[0-9a-f]+|\d+)',args)[1],0)
 for line in raw.decode().splitlines():
  z=rx.search(line)
  if not z:continue
  pid,cpu,ts,name,args=z.groups();pid=int(pid);cpu=int(cpu);ts=float(ts);seq+=1
  if name=='tracing_mark_write':
   m=re.search(r'MOVE_BEGIN batch=256 attempt=(\d+)',args)
   if m:attempt=int(m[1])
   continue
  if name not in ['release','enqueue','dequeue','alloc','copy','send_in','send_out','overflow_in','overflow_out','mm_page_free','mm_page_alloc','mm_page_alloc_zone_locked','mm_page_pcpu_drain']:continue
  cpu_events[cpu][name]+=1
  if name in ['send_in','send_out']:
   if name=='send_in':send_stack[pid]=dict(start=ts,cpu=cpu,count=field(args,'count'))
   else:
    a=send_stack.pop(pid);a.update(end=ts,ms=(ts-a['start'])*1000)
    if a['count']:sends.append(a)
   continue
  if name in ['overflow_in','overflow_out']:continue
  if name=='copy':
   dest=pfn(args,'dst');source=pfn(args,'src')
   if dest>=0x100000:
    assert dest in allocs,(label,'copy without allocation',hex(dest),attempt)
    rec=allocs[dest];assert rec['attempt']==attempt
    rec['copy_ts']=ts;rec['source_pfn']=source;rec['copy_cpu']=cpu;copy_pfn_counts[dest]+=1
   continue
  if name in ['release','enqueue','dequeue','alloc']:pf=pfn(args)
  else:pf=int(re.search(r'pfn=0x([a-f0-9]+)',args)[1],16)
  if pf is None:continue
  if not 0x100000<=pf<0x1000000:continue
  event=dict(seq=seq,ts=ts,cpu=cpu,pid=pid,pfn=pf,event=name,attempt=attempt,generation=generations[pf],allocated_in_attempt=allocs[pf]['attempt'] if pf in allocs else None)
  if name=='release':
   release_count+=1;assert field(args,'ref')==1,(label,'release ref',pf,args);release[pf]=event
  elif name=='enqueue':
   enqueue_count+=1;assert (pf,generations[pf]) not in enqueued_generations;enqueued_generations.add((pf,generations[pf]));event.update(pcp=field(args,'pcp'),list=field(args,'list'),count=field(args,'count'))
   pc=event['pcp'];assert pc not in pcp_cpu or pcp_cpu[pc]==cpu,(label,'pcp owner changed');pcp_cpu[pc]=cpu
   rel=release.get(pf);event['release']=rel if rel and rel['generation']==event['generation'] else None
   if event['release']:assert rel['pid']==pid and rel['cpu']==cpu and rel['seq']<seq
   states[pf]=event
  elif name=='mm_page_pcpu_drain':
   drain_count+=1;event['previous']=states.get(pf);states[pf]=event
  elif name=='mm_page_alloc_zone_locked':
   refill_count+=1;event.update(percpu_refill=field(args,'percpu_refill'),previous=states.get(pf));states[pf]=event
  elif name=='dequeue':
   previous=states.get(pf);event.update(pcp=field(args,'pcp'),count=field(args,'count'),previous=previous)
   assert field(args,'order')==0
   event['list']=event['pcp']+32+field(args,'mt')*16
   assert event['pcp'] not in pcp_cpu or pcp_cpu[event['pcp']]==cpu
   pcp_cpu[event['pcp']]=cpu
   if previous and previous['event']=='enqueue':
    assert (previous['cpu'],previous['pcp'],previous['list'])==(cpu,event['pcp'],event['list']),(label,'direct PCP mismatch',pf,previous,event)
   elif not previous or previous['event']!='mm_page_alloc_zone_locked':pcp_misses+=1
   dequeues[pf]=event;states[pf]=event
  elif name=='alloc':
   deq=dequeues.pop(pf,None);assert deq and deq['pid']==pid and deq['cpu']==cpu,(label,'allocation missing dequeue',pf,attempt)
   prev=deq['previous'];rel=None;origin_enqueue=None
   if prev and prev['event']=='enqueue':
    origin_enqueue=prev;rel=prev.get('release');kind='direct_media' if rel else 'direct_inline'
   elif prev and prev['event']=='mm_page_alloc_zone_locked':
    ancestor=prev.get('previous')
    while ancestor and ancestor['event'] not in ['enqueue','dequeue']:ancestor=ancestor.get('previous')
    if pf not in seen_alloc:kind='buddy_refill_new'
    elif ancestor and ancestor['event']=='enqueue':
     origin_enqueue=ancestor;rel=ancestor.get('release');kind='buddy_refill_media' if rel else 'buddy_refill_inline'
    else:kind='buddy_refill_reused_other'
   else:kind='unclassified'
   generations[pf]+=1
   rec=dict(label=label,variant=run['variant'],attempt=attempt,pfn=pf,pfn_hex=hex(pf),generation=generations[pf],allocation_ts=ts,allocation_cpu=cpu,dequeue_ts=deq['ts'],dequeue_cpu=deq['cpu'],pcp=hex(deq['pcp']),pcp_list=hex(deq['list']),source=kind,workload_first_allocation=pf not in seen_alloc,release_cpu=rel['cpu'] if rel else None,release_ts=rel['ts'] if rel else None,enqueue_ts=origin_enqueue['ts'] if origin_enqueue else None,copy_ts=None)
   records.append(rec);allocs[pf]=rec;seen_alloc.add(pf);release.pop(pf,None)
   if rel:
    chain=[];cursor=prev
    while cursor and cursor['event']!='enqueue':
     chain.append({k:v for k,v in cursor.items() if k not in ['previous','release']});cursor=cursor.get('previous')
    chains.append(dict(label=label,variant=run['variant'],source=kind,pfn=hex(pf),attempt=attempt,source_attempt=rel['allocated_in_attempt'],release=rel,enqueue={k:v for k,v in origin_enqueue.items() if k!='release'},intermediate=list(reversed(chain)),dequeue={k:v for k,v in deq.items() if k!='previous'},alloc=event))
 assert enqueued_generations=={(a['pfn'],a['generation']) for a in records},(label,'target enqueue conservation',len(enqueued_generations),len(records))
 assert len(records)==256*256 and all(a['copy_ts'] is not None for a in records),(label,len(records))
 assert all(sum(a['attempt']==i for a in records)==256 for i in range(256))
 assert pcp_misses==0,(label,'missing PCP origin',pcp_misses)
 faults={c['attempt']:collections.Counter(c['gpa_pages']) for c in host['calls']}
 for a in records:
  a['copy_ept_faults']=faults[a['attempt']][a['pfn']]
  if a['source']=='direct_media':
   # add to complete chain after parsing to avoid timestamp-domain comparison
   pass
 assert sum(a['copy_ept_faults'] for a in records)==host['full']['copy_ept_exits'],(label,'EPT PFN join')
 for c in chains:c['copy_ept_faults']=faults[c['attempt']][int(c['pfn'],16)]
 cats=[]
 for kind in sorted({a['source'] for a in records}):
  rs=[a for a in records if a['source']==kind];warm=[a for a in rs if a['attempt']>=2]
  cats.append(dict(source=kind,allocations=len(rs),ept_faults=sum(a['copy_ept_faults'] for a in rs),warm_allocations=len(warm),warm_ept_faults=sum(a['copy_ept_faults'] for a in warm),warm_first_allocations=sum(a['workload_first_allocation'] for a in warm)))
 res=dict(label=label,variant=run['variant'],rounds=256,allocations=len(records),unique_target_pfns=len(seen_alloc),release_count=release_count,enqueue_count=enqueue_count,refill_count=refill_count,drain_count=drain_count,pcp_misses=pcp_misses,pcp_cpu={hex(k):v for k,v in pcp_cpu.items()},sources=cats,cpu_events={k:dict(v) for k,v in cpu_events.items()},send_cpu_counts=dict(collections.Counter(x['cpu'] for x in sends)),sends=sends,full_ept=host['full'],warm_ept=host['after_first_two'],guest_trace_sha256=hashlib.sha256(raw).hexdigest());summary.append(res);all_alloc.extend(records);all_chains.extend(chains);print(label,'pfns',len(seen_alloc),'sources',cats,flush=True)
(r/'lineage-summary.json').write_text(json.dumps(summary,indent=2));(r/'media-reuse-chains.json').write_text(json.dumps(all_chains,indent=2))
with (r/'allocations.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(all_alloc[0]));w.writeheader();w.writerows(all_alloc)
