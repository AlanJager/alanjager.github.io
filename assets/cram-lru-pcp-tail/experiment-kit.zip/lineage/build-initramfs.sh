#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p rootfs/{bin,sbin,proc,sys,dev,tmp}
gcc -static -O2 -g -pthread -Wall -Wextra -Werror -o probe probe.c 2>probe-build.log
cp probe rootfs/bin/
gcc -static -O2 -g -Wall -Wextra -Werror -o stress stress.c 2>stress-build.log
cp stress rootfs/bin/
cp /usr/bin/busybox rootfs/bin/busybox
for app in sh mount mkdir cat sleep uname poweroff gzip sha256sum mkswap swapon swapoff; do ln -sf busybox "rootfs/bin/$app"; done
cp guest-init rootfs/init; chmod +x rootfs/init
(cd rootfs && find . -print0 | cpio --null -o --format=newc) | gzip -1 > initramfs.cpio.gz
