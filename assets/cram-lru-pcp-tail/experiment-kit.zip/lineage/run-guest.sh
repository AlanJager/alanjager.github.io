#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
variant=${1:?local remote or split};mode=${2:?nop trace or host}
tracefile=${3:-"$PWD/trace-export.gz"}
case "$variant" in local) flushcpu=-1;releasecpu=-1;; remote) flushcpu=1;releasecpu=-1;; split) flushcpu=1;releasecpu=0;; *)exit 2;;esac
variant_kernel=${KERNEL_IMAGE:?set KERNEL_IMAGE to the split-capable bzImage}
case "$mode" in nop|host|fast|trace|churn|budget|safety|pressure|retry);; *)exit 2;;esac
exec timeout 180 "${QEMU_BIN:?set QEMU_BIN to the fixed CT3-capable QEMU}" \
 -L "${BIOS_DIR:?set BIOS_DIR to QEMU pc-bios}" \
 -machine q35,cxl=on -accel kvm -cpu host -m 512M,maxmem=2G,slots=8 -smp 2 \
 -name fbatch-ab,debug-threads=on \
 -object memory-backend-ram,id=ram0,size=512M \
 -numa node,nodeid=0,memdev=ram0 \
 -numa node,nodeid=1 \
 -kernel "${variant_kernel}" -initrd initramfs.cpio.gz \
 -append "console=ttyS0 nokaslr panic=-1 clocksource=kvm-clock labmode=$mode cxl_compression.flush_cpu=$flushcpu cxl_compression.release_cpu=$releasecpu" \
 -chardev "file,id=trace,path=$tracefile" \
 -device virtio-serial-pci \
 -device virtserialport,chardev=trace,name=lab.trace \
 -qmp unix:qmp.sock,server=on,wait=off \
 -object memory-backend-ram,id=cxl-mem0,size=512M,share=on \
 -object memory-backend-ram,id=cxl-lsa0,size=1M,share=on \
 -device pxb-cxl,bus_nr=12,bus=pcie.0,id=cxl.1 \
 -device cxl-rp,port=0,bus=cxl.1,id=root_port0,chassis=0,slot=2 \
 -device cxl-ct3,bus=root_port0,volatile-memdev=cxl-mem0,lsa=cxl-lsa0,id=cxl-ct3-0 \
 -M cxl-fmw.0.targets.0=cxl.1,cxl-fmw.0.size=1G,cxl-fmw.0.interleave-granularity=8k \
 -display none -serial stdio -monitor none -no-reboot -nic none
