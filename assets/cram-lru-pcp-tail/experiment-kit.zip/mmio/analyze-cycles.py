import pathlib,re,json,collections,statistics
root=pathlib.Path(__file__).resolve().parent;allrows=[]
paths=list(root.glob('*.guest.trace'))+list((root/'counter').glob('*.guest.trace'))
for gp in paths:
 label=gp.name.removesuffix('.guest.trace');
 if 'SYNC tag=205' not in gp.read_text():allrows.append(dict(label=label,status='no captured syscall tail / end sync'));continue
 hp=gp.with_name(label+'.host.window.trace');guest=gp.read_text();host=hp.read_text();events=[]
 for line in host.splitlines():
  m=re.search(r'-(\d+)\s+\[(\d+)\].*? (\d+\.\d+): (.*)',line)
  if m:events.append((float(m[3]),int(m[1]),m[4],line))
 events.sort(key=lambda x:x[0]);sync=[]
 for tag,val in [(171,'ab'),(205,'cd')]:
  m=re.search(r'SYNC tag='+str(tag)+r' lo=(\d+) hi=(\d+)',guest);a,b=map(lambda x:int(x)/1e9,m.groups())
  h=next(t for t,p,e,l in events if 'kvm_pio: pio_write at 0x505' in e and 'val 0x'+val in e)
  sync.append(dict(host=h,guest=(a+b)/2,bracket_us=(b-a)*1e6))
 scale=(sync[1]['host']-sync[0]['host'])/(sync[1]['guest']-sync[0]['guest']);offset=sync[0]['host']-scale*sync[0]['guest']
 row=dict(label=label,sync=sync,clock_scale=scale,status='no memcpy span');pairs=[];begin=None
 for line in guest.splitlines():
  m=re.search(r'(\d+\.\d+): f5_(in|out)',line)
  if not m:continue
  if m[2]=='in':begin=float(m[1])
  elif begin is not None:pairs.append((begin,float(m[1])));begin=None
 if not pairs:allrows.append(row);continue
 gs,ge=pairs[-1];alo=gs*scale+offset;ahi=ge*scale+offset
 candidates=[]
 for i,(t,p,e,l) in enumerate(events):
  m=re.search(r'kvm_mmio: mmio write len (\d+) gpa (0x[0-9a-f]+) val (0x[0-9a-f]+)',e)
  if m and int(m[1])==4 and int(m[2],16)==0xfe8000a8 and int(m[3],16)==0x101 and alo-.0002<=t<=ahi+.0002:candidates.append(i)
 assert len(candidates)==1,(label,candidates)
 first=candidates[0];idx=[]
 for i in range(first,len(events)):
  m=re.search(r'kvm_mmio: mmio write len (\d+) gpa (0x[0-9a-f]+)',events[i][2])
  if m:
   assert int(m[1])==4 and int(m[2],16)==0xfe8000a8+4*len(idx),(label,i,len(idx),m.groups())
   idx.append(i)
   if len(idx)==510:break
 assert len(idx)==510,label
 last=idx[-1];startindex=max(i for i in range(first) if events[i][2].startswith('kvm_entry:'))
 endindex=next(i for i in range(last+1,len(events)) if events[i][2].startswith('kvm_entry:'))
 lo=events[startindex][0];hi=events[endindex][0];tid=events[first][1]
 stage='unknown';on=True;prev=events[0][0];parts=collections.defaultdict(float);reasons=collections.Counter();counts=collections.Counter();off=[];away=None
 for t,p,e,l in events:
  a=max(prev,lo);b=min(t,hi)
  if b>a:parts[stage if on else 'host_offcpu']+=(b-a)*1000
  prev=t
  if lo<=t<=hi:
   counts[e.split(':')[0]]+=1
   if e.startswith('kvm_exit:'):reasons[re.search(r'reason (\S+)',e)[1]]+=1
  if 'sched_switch:' in e:
   if f'prev_pid={tid} ' in e:on=False;away=t
   if f'next_pid={tid} ' in e:
    if away is not None and min(t,hi)>max(away,lo):off.append((max(away,lo),min(t,hi)))
    on=True;away=None
  if p==tid:
   if e.startswith('sys_ioctl('):stage='kernel_reentry'
   elif e.startswith('sys_ioctl ->'):stage='qemu_userspace'
   elif e.startswith('kvm_entry:'):stage='guest_and_transition'
   elif e.startswith('kvm_exit:'):stage='kernel_exit_handling'
 assert abs(sum(parts.values())-(hi-lo)*1000)<.00001,(label,parts)
 callbacks=[];stack=[]
 for t,p,e,l in events:
  if p!=tid:continue
  if re.match(r'(dispatch|mailbox)_in:',e):stack.append((t,e))
  elif re.match(r'(dispatch|mailbox)_out:',e) and stack:
   st,entry=stack.pop()
   if lo<=st and t<=hi:callbacks.append(dict(us=(t-st)*1e6,entry=entry))
 diag=[]
 log=gp.with_name(label+'.log').read_text()
 for count,bytes_,ns,a,b in re.findall(r'CRAM_DIAG count=(\d+) bytes=(\d+) callback_ns=(\d+) start_ns=(\d+) end_ns=(\d+)',log):
  a,b=int(a)/1e9,int(b)/1e9
  if lo-.0002<=a<=hi+.0002:diag.append(dict(count=int(count),bytes=int(bytes_),callback_ms=int(ns)/1e6,start=a,end=b))
 row.update(status='payload validated',guest_memcpy_ms=(ge-gs)*1000,payload_cycle_ms=(hi-lo)*1000,payload_bounds=[lo,hi],payload_writes=510,payload_bytes=2040,parts_ms=dict(parts),exit_reasons=dict(reasons),events=dict(counts),callback_count=len(callbacks),callback_instrumented_ms=sum(x['us'] for x in callbacks)/1000,counter=diag,selected_host_lines=[l for t,p,e,l in events if lo<=t<=hi])
 allrows.append(row)
(root/'cycle-summary.json').write_text(json.dumps(allrows,indent=2))
for r in allrows:print(r['label'],r['status'],r.get('guest_memcpy_ms'),r.get('payload_cycle_ms'),r.get('parts_ms'),r.get('exit_reasons'),r.get('counter'))
