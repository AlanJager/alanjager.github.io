import pathlib,re,json,csv,gzip,hashlib,math,statistics,collections
root=pathlib.Path(__file__).resolve().parent;results=root/'results';samples=[];guests=[];traces=[]
def percentile(v,p):v=sorted(v);return v[math.ceil(len(v)*p)-1]
for log in sorted(results.glob('*.log')):
 variant,mode,rep=log.stem.split('-');text=log.read_text();assert 'FBATCH_DONE' in text,log
 vals=[]
 for attempt,ns in re.findall(r'SAMPLE .* batch=256 attempt=(\d+) ns=(\d+)',text):
  n=int(ns);vals.append(n/1e6);samples.append(dict(variant=variant,mode=mode,rep=int(rep),attempt=int(attempt),ns=n))
 assert len(vals)==1000,log
 guests.append(dict(variant=variant,mode=mode,rep=int(rep),count=len(vals),median_ms=statistics.median(vals),p95_ms=percentile(vals,.95),p99_ms=percentile(vals,.99),max_ms=max(vals),over10ms=sum(x>=10 for x in vals),workload_ms=int(re.search(r'WORKLOAD_NS=(\d+)',text)[1])/1e6,mean_ms=statistics.mean(vals)))
 if mode!='trace':continue
 raw=gzip.decompress(log.with_suffix('.trace.gz').read_bytes());assert hashlib.sha256(raw).hexdigest()==re.search(r'TRACE_SHA256 ([a-f0-9]{64})',text)[1]
 log.with_suffix('.trace').write_bytes(raw);t=raw.decode();stack=collections.defaultdict(list);spans=[];entries=[]
 for line in t.splitlines():
  m=re.search(r'-(\d+)\s+\[(\d+)\].*? (\d+\.\d+): f(\d+)_(in|out):',line)
  if not m:continue
  pid,cpu,ts,n,kind=m.groups();ts=float(ts);key=(pid,n)
  if kind=='in':
   count=re.search(r'count=(\d+)',line);r=dict(start=ts,pid=int(pid),cpu=int(cpu),function=int(n),count=int(count[1]) if count else None);stack[key].append(r);entries.append(r)
  else:
   assert stack[key],line;r=stack[key].pop();r.update(end=ts,ms=(ts-r['start'])*1000);spans.append(r)
 assert not any(stack.values()),[(k,len(v)) for k,v in stack.items() if v]
 send=[x for x in spans if x['function']==1 and x['count']];copy=[x for x in spans if x['function']==2]
 sent=sum(x['count'] for x in send)
 assert all(x['cpu']==1 for x in send) if variant!='local' else any(x['cpu']==0 for x in send),(variant,'send cpu')
 release=[x for x in spans if x['function']==5 and x['count']];assert sum(x['count'] for x in release)==sent,(log,'release pages')
 if variant!='local':assert all(x['cpu']==(0 if variant=='split' else 1) for x in release),(variant,'release cpu')
 profiles=re.findall(r'^\s*(?:tail/)?(f\d+_\w+)\s+(\d+)\s+(\d+)\s*$',text,re.M)
 assert len(profiles)==11 and all(int(x[2])==0 for x in profiles),(log,'kprobe misses',profiles)
 inline=int(next(x[1] for x in profiles if x[0]=='f4_in'));assert sent+inline==256000,(log,sent,inline)
 # Probe runnable/sleep intervals and concurrent cleanup, independent of timed samples.
 moves=[x for x in spans if x['function']==0];assert len(moves)==1000,(log,len(moves))
 probe_pid=moves[0]['pid'];off=[];off_start=None;prev_state=None;markers=[]
 for line in t.splitlines():
  z=re.search(r' (\d+\.\d+): sched_switch: .*prev_pid=(\d+).*prev_state=(\S+) ==> .*next_pid=(\d+)',line)
  if z:
   ts,prev,state,nxt=z.groups();ts=float(ts)
   if int(nxt)==probe_pid and off_start is not None:
    off.append((off_start,ts,prev_state));off_start=None
   if int(prev)==probe_pid:off_start=ts;prev_state=state
  z=re.search(r' (\d+\.\d+): .*MOVE_BEGIN batch=256 attempt=(\d+)',line)
  if z:markers.append((float(z[1]),int(z[2])))
 def overlap(a,b,c,d):return max(0,min(b,d)-max(a,c))
 details=[]
 for x in moves:
  a,b=x['start'],x['end'];relevant_off=[(c,d,state) for c,d,state in off if c<b and d>a];relevant_send=[z for z in send if z['cpu']==0 and z['start']<b and z['end']>a];o=sum(overlap(a,b,c,d) for c,d,_ in relevant_off)*1000
  interference=sum(overlap(max(a,c),min(b,d),z['start'],z['end']) for c,d,_ in relevant_off for z in relevant_send)*1000
  attempt=max((v for ts,v in markers if ts<=a),default=-1)
  details.append(dict(attempt=attempt,ms=x['ms'],off_cpu_ms=o,off_cpu_during_cpu0_send_ms=interference,start=a,end=b))
 top=sorted(details,key=lambda x:x['ms'],reverse=True)[:10]
 traces.append(dict(variant=variant,rep=int(rep),commands=len(send),flushed_pages=sent,inline_zero_pages=inline,total_cleaned_pages=sent+inline,send_cpu_counts=dict(collections.Counter(x['cpu'] for x in send)),send_median_ms=statistics.median(x['ms'] for x in send),memcpy_median_ms=statistics.median(x['ms'] for x in copy),release_cpu_counts=dict(collections.Counter(x['cpu'] for x in release)),release_median_ms=statistics.median(x['ms'] for x in release),top_migrations=top,spans=spans,sha256=hashlib.sha256(raw).hexdigest()))
summary=[]
for variant in ['local','remote','split']:
 v=[x['ns']/1e6 for x in samples if x['variant']==variant and x['mode']=='nop']
 if not v:continue
 summary.append(dict(variant=variant,count=len(v),median_ms=statistics.median(v),p95_ms=percentile(v,.95),p99_ms=percentile(v,.99),max_ms=max(v),over10ms=sum(x>=10 for x in v),mean_ms=statistics.mean(v)))
with (root/'samples.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=['variant','mode','rep','attempt','ns']);w.writeheader();w.writerows(samples)
(root/'summary.json').write_text(json.dumps(dict(pooled_nop=summary,per_guest=guests,trace=traces),indent=2))
print('POOLED',summary)
print('GUESTS',[(x['variant'],x['mode'],x['rep'],round(x['p99_ms'],3),round(x['max_ms'],3),x['over10ms']) for x in guests])
print('TRACE',[(x['variant'],x['rep'],x['commands'],x['flushed_pages'],x['inline_zero_pages'],x['send_cpu_counts'],x['release_cpu_counts'],x['memcpy_median_ms']) for x in traces])
