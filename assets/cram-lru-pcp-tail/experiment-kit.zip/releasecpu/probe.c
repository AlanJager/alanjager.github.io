#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <inttypes.h>
#include <linux/mempolicy.h>
#include <sched.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/syscall.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/io.h>
static int hostmode;

static uint64_t ns(void) { struct timespec t; clock_gettime(CLOCK_MONOTONIC_RAW,&t); return (uint64_t)t.tv_sec*1000000000+t.tv_nsec; }
static void fail(const char *s) { perror(s); exit(2); }
static void put(const char *name,const char *v) {
 char p[256]; snprintf(p,sizeof(p),"/sys/kernel/tracing/%s",name);
 int fd=open(p,O_WRONLY|O_TRUNC); if(fd<0)fail(p);
 if(write(fd,v,strlen(v))!=(ssize_t)strlen(v))fail(p);
 close(fd);
}
static uint64_t pattern(size_t w) { return 0x9e3779b97f4a7c15ULL ^ (w*0xbf58476d1ce4e5b9ULL); }
static void migrate(int traced,int budget) {
 cpu_set_t cpu;CPU_ZERO(&cpu);CPU_SET(0,&cpu);if(sched_setaffinity(0,sizeof(cpu),&cpu))fail("affinity");
 put("tracing_on","0");put("current_tracer","nop");put("events/enable","0");
 if(traced) {
  put("buffer_size_kb","8192");put("trace","");put("trace_clock","mono");
  const char *fn[]={"cram_migrate_to","cxl_flush_buf_send_body","memcpy_toio","cxl_flush_overflow_work","unused","cxl_flush_buf_release"};
  put("kprobe_events","");
  for(unsigned j=0;j<6;j++) {
   if(j==4)continue;
   char spec[256],filter[64],path[128];
   snprintf(spec,sizeof(spec),"p:tail/f%u_in %s\nr128:tail/f%u_out %s\n",j,fn[j],j,fn[j]);
   if(j==1)snprintf(spec,sizeof(spec),"p:tail/f1_in cxl_flush_buf_send_body count=+0(%%si):u32\nr128:tail/f1_out cxl_flush_buf_send_body\n");
   if(j==5)snprintf(spec,sizeof(spec),"p:tail/f5_in cxl_flush_buf_release count=+0(%%di):u32\nr128:tail/f5_out cxl_flush_buf_release\n");
   int fd=open("/sys/kernel/tracing/kprobe_events",O_WRONLY|O_APPEND);if(fd<0)fail("kprobe open");
   if(write(fd,spec,strlen(spec))!=(ssize_t)strlen(spec))fail("kprobe write");
   close(fd);
   if(j>0)continue;
   snprintf(filter,sizeof(filter),"common_pid == %d",getpid());
   snprintf(path,sizeof(path),"events/tail/f%u_in/filter",j);put(path,filter);
   snprintf(path,sizeof(path),"events/tail/f%u_out/filter",j);put(path,filter);
  }
  int zfd=open("/sys/kernel/tracing/kprobe_events",O_WRONLY|O_APPEND);if(zfd<0)fail("zero counter open");
  const char *zspec="p:tail/f4_in cram_zero_folio\n";
  if(write(zfd,zspec,strlen(zspec))!=(ssize_t)strlen(zspec))fail("zero counter write");
  close(zfd);
  /* Count fallback calls in kprobe_profile without filling the ring buffer. */
  put("events/tail/f4_in/filter","common_pid < 0");
  put("events/tail/enable","1");
  put("events/sched/sched_switch/enable","1");put("events/sched/sched_wakeup/enable","1");
  put("events/workqueue/enable","1");
  char trigger[96];snprintf(trigger,sizeof(trigger),"stacktrace if prev_pid == %d",getpid());
  put("events/sched/sched_switch/trigger",trigger);
  put("events/irq/enable","1");put("events/vmscan/enable","1");
 }
 if(traced)put("tracing_on","1");
 int mark=open("/sys/kernel/tracing/trace_marker",O_WRONLY);
 if(hostmode && ioperm(0x505,4,1))fail("ioperm");
 uint64_t workload_start=ns();
 size_t counts[]={256};
 for(size_t k=0;k<1;k++) {
 uint64_t sum=0;unsigned rounds=1000;
 for(unsigned i=0;i<rounds;i++) {
  size_t n=counts[k],len=n*4096;uint64_t *b=mmap(NULL,len,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);
  if(b==MAP_FAILED)fail("mmap");
  if(madvise(b,len,MADV_NOHUGEPAGE) && errno!=EINVAL)fail("nohugepage");
  unsigned long mask=1;if(syscall(SYS_mbind,b,len,MPOL_BIND,&mask,8*sizeof(mask),0))fail("mbind");
  for(size_t w=0;w<len/8;w++)b[w]=pattern(w);
  void *pages[256];int nodes[256],status[256];for(size_t j=0;j<n;j++){pages[j]=(char*)b+j*4096;nodes[j]=2;status[j]=-999;}
  if(syscall(SYS_move_pages,0,n,pages,NULL,status,0))fail("query before");
  for(size_t j=0;j<n;j++)if(status[j]!=0){fprintf(stderr,"SOURCE_FAIL %d\n",status[j]);exit(3);}
  
  if(hostmode)outl(0x10000+i,0x505);
  char m[80];int ml=snprintf(m,sizeof(m),"MOVE_BEGIN batch=%zu attempt=%u\n",n,i);if(traced && write(mark,m,ml)!=ml)fail("marker");
  uint64_t start=ns();long rc=syscall(SYS_move_pages,0,n,pages,nodes,status,0);uint64_t elapsed=ns()-start;
  ml=snprintf(m,sizeof(m),"MOVE_END batch=%zu attempt=%u ns=%"PRIu64"\n",n,i,elapsed);if(traced && write(mark,m,ml)!=ml)fail("marker");
  
  if(hostmode)outl(0x20000+i,0x505);
  if(rc)fail("move_pages");
  for(size_t j=0;j<n;j++)if(status[j]!=2){fprintf(stderr,"TARGET_FAIL %d\n",status[j]);exit(3);}
  if(syscall(SYS_move_pages,0,n,pages,NULL,status,0))fail("query after");
  for(size_t j=0;j<n;j++)if(status[j]!=2)exit(3);
  for(size_t w=0;w<len/8;w++)if(b[w]!=pattern(w)){puts("DATA_FAIL");exit(3);}
  if(syscall(SYS_move_pages,0,n,pages,NULL,status,0))fail("query after read");
  for(size_t j=0;j<n;j++)if(status[j]!=2){puts("READ_POSITION_FAIL");exit(3);}
  for(size_t j=0;j<n;j++)b[j*512]^=0xfeed123456789abcULL;
  for(size_t w=0;w<len/8;w++)if(b[w]!=(pattern(w)^(w%512==0?0xfeed123456789abcULL:0))){puts("WRITE_FAIL");exit(3);}
  if(syscall(SYS_move_pages,0,n,pages,NULL,status,0))fail("query after write");
  for(size_t j=0;j<n;j++)if(status[j]!=0){puts("PROMOTE_POSITION_FAIL");exit(3);}
  sum+=elapsed;
  printf("SAMPLE traced=%d batch=%zu attempt=%u ns=%"PRIu64"\n",traced,n,i,elapsed);
  munmap(b,len);
  
 }
 if(budget)printf("BUDGET_PASS batch=%zu pages=4096 calls=%u sum_syscall_ns=%"PRIu64"\n",counts[k],rounds,sum);
 }
 close(mark);printf("WORKLOAD_NS=%"PRIu64"\n",ns()-workload_start);puts("MIGRATE_CONTENT_POSITION_PASS");
}
static void churn(void) {
 const size_t len=8*1024*1024;uint64_t start=ns();
 for(int p=0;p<4;p++) {
  pid_t pid=fork();if(pid<0)fail("fork");if(pid==0) {
   cpu_set_t c;CPU_ZERO(&c);CPU_SET(p%2,&c);if(sched_setaffinity(0,sizeof(c),&c))_exit(2);
   uint64_t *b=mmap(NULL,len,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);if(b==MAP_FAILED)_exit(2);
   if(madvise(b,len,MADV_NOHUGEPAGE) && errno!=EINVAL)_exit(2);
   unsigned long mask=1;if(syscall(SYS_mbind,b,len,MPOL_BIND,&mask,8*sizeof(mask),0))_exit(2);
   for(unsigned round=0;round<100;round++) {
    for(size_t j=0;j<len/8;j+=512)b[j]=pattern(j)^round;
    for(size_t j=0;j<len/8;j+=512)if(((volatile uint64_t*)b)[j]!=(pattern(j)^round))_exit(3);
    if(round==0){void *page=b;int where=-999;if(syscall(SYS_move_pages,0,1,&page,NULL,&where,0)||where!=0)_exit(3);}
    if(madvise(b,len,MADV_DONTNEED))_exit(2);
   }
   munmap(b,len);_exit(0);
  }
 }
 for(int p=0;p<4;p++){int st;if(wait(&st)<0)fail("wait");if(!WIFEXITED(st)||WEXITSTATUS(st))exit(3);}
 printf("CHURN_PASS processes=4 rounds=100 bytes_per_process=%zu ns=%"PRIu64"\n",len,ns()-start);
}
static pthread_barrier_t barrier;
static volatile uint64_t *shared;
static void *writer(void *arg) {
 intptr_t i=(intptr_t)arg; cpu_set_t c;CPU_ZERO(&c);CPU_SET(i,&c);
 if(pthread_setaffinity_np(pthread_self(),sizeof(c),&c))return (void*)1;
 pthread_barrier_wait(&barrier); shared[i]^=0xfeed123456789abcULL;return NULL;
}
static void concurrent(void) {
 for(int round=0;round<200;round++) {
  uint64_t *b=mmap(NULL,4096,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);
  if(b==MAP_FAILED)fail("mmap");
  unsigned long mask=1;if(syscall(SYS_mbind,b,4096,MPOL_BIND,&mask,64,0))fail("mbind");
  for(size_t w=0;w<512;w++)b[w]=pattern(w);
  void *page=b;int target=2,status=-999;
  shared=b;pthread_t a,t;pthread_barrier_init(&barrier,NULL,3);
  if(pthread_create(&a,NULL,writer,(void*)0)||pthread_create(&t,NULL,writer,(void*)1))fail("thread");
  if(syscall(SYS_move_pages,0,1,&page,&target,&status,0)||status!=2)fail("concurrent migrate");
  pthread_barrier_wait(&barrier);
  void *ra,*rt;pthread_join(a,&ra);pthread_join(t,&rt);if(ra||rt)exit(3);
  pthread_barrier_destroy(&barrier);
  for(size_t w=0;w<512;w++)if(b[w]!=(pattern(w)^(w<2?0xfeed123456789abcULL:0)))exit(3);
  if(syscall(SYS_move_pages,0,1,&page,NULL,&status,0)||status!=0)exit(3);
  munmap(b,4096);
 }
 for(int round=0;round<200;round++) {
  uint64_t *b=mmap(NULL,4096,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);
  if(b==MAP_FAILED)fail("mmap immediate");
  unsigned long mask=1;if(syscall(SYS_mbind,b,4096,MPOL_BIND,&mask,64,0))fail("mbind");
  for(size_t w=0;w<512;w++)b[w]=pattern(w);
  void *page=b;int target=2,status=-999;
  long rc=syscall(SYS_move_pages,0,1,&page,&target,&status,0);
  ((volatile uint64_t*)b)[0]^=0xfeed123456789abcULL;
  if(rc||status!=2)fail("immediate migrate");
  for(size_t w=0;w<512;w++)if(b[w]!=(pattern(w)^(w==0?0xfeed123456789abcULL:0)))exit(3);
  if(syscall(SYS_move_pages,0,1,&page,NULL,&status,0)||status!=0)exit(3);
  munmap(b,4096);
 }
 puts("IMMEDIATE_PROMOTE_PASS rounds=200");
 for(int round=0;round<200;round++) {
  uint64_t *b=mmap(NULL,65536,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);
  if(b==MAP_FAILED)fail("mmap release");
  unsigned long mask=1;if(syscall(SYS_mbind,b,65536,MPOL_BIND,&mask,64,0))fail("mbind");
  for(size_t w=0;w<8192;w++)b[w]=pattern(w);
  void *pages[16];int targets[16],status[16];
  for(int j=0;j<16;j++){pages[j]=b+j*512;targets[j]=2;status[j]=-999;}
  if(syscall(SYS_move_pages,0,16,pages,targets,status,0))fail("release migrate");
  for(int j=0;j<16;j++)if(status[j]!=2)exit(3);
  if(munmap(b,65536))fail("immediate munmap");
 }
 puts("CRAM_RELEASE_PASS rounds=200 pages_per_round=16");
 puts("CONCURRENT_PROMOTE_PASS rounds=200 writers=2");
 for(int round=0;round<100;round++) {
  uint64_t *b=mmap(NULL,65536,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);
  if(b==MAP_FAILED)fail("mmap mlock");
  if(mlock(b,65536))fail("mlock");
  for(int w=0;w<8192;w++)b[w]=pattern(w);
  if(munlock(b,65536))fail("munlock");
  if(madvise(b,65536,MADV_FREE))fail("madv free");
  // Pages may be reclaimed after MADV_FREE; write them before validating.
  for(int w=0;w<8192;w++)b[w]=pattern(w)^round;
  for(int w=0;w<8192;w++)if(b[w]!=(pattern(w)^round))exit(3);
  munmap(b,65536);
 }
 puts("MLOCK_LAZYFREE_PASS rounds=100");
}
int main(int argc,char **argv) {
 setvbuf(stdout,NULL,_IOLBF,0);if(argc!=2)return 2;
 hostmode=!strcmp(argv[1],"host");
 if(hostmode || !strcmp(argv[1],"nop"))migrate(0,0);else if(!strcmp(argv[1],"trace"))migrate(1,0);else if(!strcmp(argv[1],"fast"))migrate(1,1);else if(!strcmp(argv[1],"budget"))migrate(0,1);else if(!strcmp(argv[1],"churn"))churn();else if(!strcmp(argv[1],"safety"))concurrent();else return 2;return 0;
}
