import os,pathlib,subprocess,time,json,socket,re,gzip,hashlib,threading,select
root=pathlib.Path(__file__).resolve().parent;os.chdir(root)
tr=pathlib.Path('/sys/kernel/tracing');inst=tr/'instances/cram_releasecpu_20261010'
assert not inst.exists();inst.mkdir()
def put(p,s):p.write_text(s)
def qmp(cmd):
 with socket.socket(socket.AF_UNIX) as s:
  s.settimeout(3);s.connect(str(root/'qmp.sock'));f=s.makefile('r');json.loads(f.readline())
  for command in [{'execute':'qmp_capabilities'},{'execute':cmd}]:
   s.sendall((json.dumps(command)+'\n').encode())
   while True:
    response=json.loads(f.readline())
    if 'return' in response or 'error' in response:break
   assert 'return' in response,response
 return response
out=root/'host-results';out.mkdir(exist_ok=True);os.chown(out,1000,1000);rows=[];upnames=[]
qbin=os.environ['QEMU_BIN']
try:
 put(inst/'tracing_on','0');put(inst/'trace_clock','mono');put(inst/'buffer_size_kb','32768');put(inst/'tracing_cpumask','c0')
 for mode,repeat in [('local',0),('remote',0),('split',0),('split',1),('remote',1),('local',1)]:
  label=mode+'-'+str(repeat);log=out/(label+'.log');pipefile=out/(label+'.host.trace');stop=threading.Event()
  put(inst/'events/enable','0');put(inst/'trace','')
  with log.open('wb') as stream:
   # -S ensures every tracing filter and vCPU affinity is in place before guest execution.
   script=(root/'run-guest.sh').read_text().replace(' -display none',' -S -display none')
   p=subprocess.Popen(['runuser','-u',os.environ['LAB_USER'],'--','bash','-c',script+'\n', 'unused',mode,'host',str(out/(label+'.guest.trace.gz'))],stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
   os.sched_setaffinity(p.pid,{6,7});deadline=time.monotonic()+190;pinned={};qpid=None
   while len(pinned)<2:
    procs=[p.pid]
    for pid in procs:
     try:procs.extend(int(x) for x in pathlib.Path(f'/proc/{pid}/task/{pid}/children').read_text().split())
     except FileNotFoundError:pass
    for pid in procs:
     try:tasks=list(pathlib.Path(f'/proc/{pid}/task').iterdir())
     except FileNotFoundError:continue
     for task in tasks:
      try:
       name=(task/'comm').read_text().strip();m=re.fullmatch(r'CPU (\d+)/KVM',name)
       if m and int(m[1])<2:
        cpu=int(m[1]);os.sched_setaffinity(int(task.name),{6+cpu});pinned[cpu]=int(task.name);qpid=pid
      except (FileNotFoundError,ProcessLookupError):pass
    if p.poll() is not None:raise RuntimeError(log.read_text())
    if time.monotonic()>deadline:raise RuntimeError('setup timeout')
    time.sleep(.01)
   tid=pinned[0];peer=pinned[1]
   for ev in ['kvm/kvm_entry','kvm/kvm_exit','kvm/kvm_userspace_exit','kvm/kvm_mmio','kvm/kvm_pio','kvm/kvm_page_fault','syscalls/sys_enter_ioctl','syscalls/sys_exit_ioctl']:
    path=inst/'events'/ev;put(path/'filter',f'common_pid == {tid} || common_pid == {peer}');put(path/'enable','1')
   put(inst/'events/sched/sched_switch/filter',f'prev_pid == {tid} || next_pid == {tid} || prev_pid == {peer} || next_pid == {peer}');put(inst/'events/sched/sched_switch/enable','1')
   put(inst/'events/sched/sched_wakeup/filter',f'pid == {tid} || pid == {peer}');put(inst/'events/sched/sched_wakeup/enable','1')
   def reader():
    fd=os.open(inst/'trace_pipe',os.O_RDONLY|os.O_NONBLOCK)
    with pipefile.open('wb') as dest:
     while not stop.is_set():
      ready,_,_=select.select([fd],[],[],.1)
      if ready:
       try:dest.write(os.read(fd,1024*1024))
       except BlockingIOError:pass
     while True:
      try:data=os.read(fd,1024*1024)
      except BlockingIOError:break
      if not data:break
      dest.write(data)
    os.close(fd)
   thread=threading.Thread(target=reader);thread.start();put(inst/'tracing_on','1');qmp('cont')
   while p.poll() is None:
    text=log.read_text(errors='replace')
    if re.search(r'kernel BUG|BUG:|Kernel panic|detected stalls',text):raise RuntimeError('kernel failure')
    if time.monotonic()>deadline:raise RuntimeError('timeout')
    time.sleep(.05)
   put(inst/'tracing_on','0');stop.set();thread.join()
   text=log.read_text();assert p.returncode==0 and 'PROBE_EXIT_0' in text and 'MIGRATE_CONTENT_POSITION_PASS' in text and 'FBATCH_DONE' in text
   assert not re.search(r'WARNING:|BUG:|detected stalls|soft lockup',text)
   stats='\n'.join(p.read_text() for p in (inst/'per_cpu').glob('cpu*/stats'));(out/(label+'.host.stats')).write_text(stats)
   assert all(x=='0' for x in re.findall(r'(?:overrun|dropped events): (\d+)',stats)),stats
   assert all(x=='0' for x in re.findall(r'(?:overrun|dropped events): (\d+)',text)),text
   assert len(re.findall(r'SAMPLE .* batch=256 .* ns=\d+',text))==1000
   assert re.search(r'FLUSH_CPU '+str(-1 if mode=='local' else 1)+r'\b',text)
   assert re.search(r'RELEASE_CPU '+str(0 if mode=='split' else -1)+r'\b',text)
   rows.append(dict(label=label,variant=mode,repeat=repeat,qemu_pid=qpid,vcpu_tids=pinned,host_trace_bytes=pipefile.stat().st_size,clock='mono'));(out/'runs.json').write_text(json.dumps(rows,indent=2))
   print(label+' PASS',flush=True)
finally:
 put(inst/'tracing_on','0');put(inst/'events/enable','0')
 for ev in upnames:
  fd=os.open(tr/'uprobe_events',os.O_WRONLY);os.write(fd,('-:cramhost/'+ev+'\n').encode());os.close(fd)
 inst.rmdir()
 for p in out.iterdir():os.chown(p,1000,1000)
print('HOST_MATRIX_ALL_PASS',flush=True)
