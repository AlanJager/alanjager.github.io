#!/usr/bin/env python3
"""Sequential fresh guests; balanced A/B order; pin each KVM vCPU."""
import json, os, pathlib, re, subprocess, time, socket
root=pathlib.Path(__file__).resolve().parent
os.chdir(root)
out=root/'results';out.mkdir(exist_ok=True)
allowed=sorted(os.sched_getaffinity(0));hostcpus=allowed[-2:]
assert len(hostcpus)==2
results=[]
orders=[('local','remote','split'),('remote','split','local'),('split','local','remote'),('split','remote','local'),('remote','local','split'),('local','split','remote')]
matrix=[(v,'nop',i) for i,order in enumerate(orders) for v in order]+[(v,'trace',i) for i,order in enumerate([orders[0],orders[3]]) for v in order]
for variant,mode,rep in matrix:
 label=f'{variant}-{mode}-{rep}';log=out/f'{label}.log'
 host={'allowed_cpus':allowed,'vcpu_host_cpus':hostcpus,'loadavg':pathlib.Path('/proc/loadavg').read_text().strip()}
 with log.open('wb') as stream:
  p=subprocess.Popen(['bash','run-guest.sh',variant,mode,str(out/f'{label}.trace.gz')],stdout=stream,stderr=subprocess.STDOUT)
  os.sched_setaffinity(p.pid,set(hostcpus))
  pinned={};sent=set();qmp_events=[];deadline=time.monotonic()+190
  while p.poll() is None:
   # timeout is parent of QEMU; walk descendants rather than assuming PID.
   processes=[p.pid]
   for pid in processes:
    child=pathlib.Path(f'/proc/{pid}/task/{pid}/children')
    try:processes.extend(int(x) for x in child.read_text().split())
    except FileNotFoundError:pass
   for pid in processes:
    try:tasks=list(pathlib.Path(f'/proc/{pid}/task').iterdir())
    except FileNotFoundError:continue
    for task in tasks:
     try:
      name=(task/'comm').read_text().strip();hit=re.fullmatch(r'CPU (\d+)/KVM',name)
      if hit and int(hit[1])<2 and task.name not in pinned:
       target=hostcpus[int(hit[1])];os.sched_setaffinity(int(task.name),{target});pinned[task.name]={'name':name,'cpu':target}
     except (FileNotFoundError,ProcessLookupError):pass
   if mode=='pressure':
    current=log.read_text(errors='replace')
    for water,cmd in [('LOW','cxl-inject-ct3-lthresh-watermark'),('HIGH','cxl-inject-ct3-hthresh-watermark')]:
     if 'INJECT_'+water+'_READY' in current and water not in sent:
      with socket.socket(socket.AF_UNIX) as sock:
       sock.settimeout(5);sock.connect(str(root/'qmp.sock'));rf=sock.makefile('r');json.loads(rf.readline())
       def request(command):
        sock.sendall((json.dumps(command)+'\n').encode())
        while True:
         response=json.loads(rf.readline())
         if 'return' in response or 'error' in response:return response
       assert 'return' in request({'execute':'qmp_capabilities'})
       response=request({'execute':cmd,'arguments':{'path':'/machine/peripheral/cxl-ct3-0'}})
       assert 'return' in response,response
       qmp_events.append({'water':water,'command':cmd,'response':response});sent.add(water)
      (out/f'{label}.qmp.json').write_text(json.dumps(qmp_events,indent=2))
   if re.search(r'kernel BUG|BUG:|Kernel panic|detected stalls',log.read_text(errors='replace')):
    p.terminate();p.wait();raise RuntimeError(f'guest kernel failure {label}')
   if time.monotonic()>deadline:p.kill();raise RuntimeError(f'timeout {label}')
   time.sleep(.05)
 text=log.read_text(errors='replace');status=p.returncode
 assert status==0 and 'PROBE_EXIT_0' in text and 'FBATCH_DONE' in text,(label,status)
 assert not re.search(r'kernel BUG|BUG:|WARNING:|Kernel panic|DATA_FAIL|TARGET_FAIL|SOURCE_FAIL|WRITE_FAIL|READ_POSITION_FAIL|PROMOTE_POSITION_FAIL|TOPOLOGY_FAIL|detected stalls|soft lockup',text),label
 assert len(pinned)==2,(label,pinned)
 assert 'FLUSH_CPU '+('-1' if variant=='local' else '1') in text,(label,'param')
 assert 'RELEASE_CPU '+('0' if variant=='split' else '-1') in text,(label,'release param')
 assert len(re.findall(r'SAMPLE .* batch=256 .* ns=\d+',text))==1000,(label,'samples')
 for counter in ('nr_isolated_anon','nr_isolated_file','nr_mlock'):
  found=re.findall(r'^'+counter+r' (\d+)\r?$',text,re.M)
  assert found and int(found[-1])==0,(label,counter,found[-1:] if found else [])
 if mode=='pressure':
  assert sent=={'LOW','HIGH'},(label,sent)
  for tag in ('PRESSURE_ALLOC_KPROBE_SETUP_EXIT_0','PRESSURE_FAULT_KPROBE_SETUP_EXIT_0','PRESSURE_ENABLED_EXIT_0','PRESSURE_BLOCKED_EXIT_0','PROBE_INITIAL_EXIT_0','PROBE_BLOCKED_EXIT_0','PROBE_RESUMED_EXIT_0'):
   assert tag in text,(label,tag)
  assert 'errno=28' in text and text.count('WORKLOAD_DATA_PASS')==2 and text.count('PROBE_DATA_PASS')==3,label
 if mode=='safety':
  for tag in ('IMMEDIATE_PROMOTE_PASS','CONCURRENT_PROMOTE_PASS','CRAM_RELEASE_PASS','MLOCK_LAZYFREE_PASS'):assert tag in text,(label,tag)
 if mode in ('fast','trace','pressure'):
  import gzip,hashlib
  assert 'TRACE_EXPORT_EXIT_0' in text,label
  expected=re.search(r'TRACE_SHA256 ([0-9a-f]{64})',text)[1]
  raw=gzip.decompress((out/f'{label}.trace.gz').read_bytes())
  assert hashlib.sha256(raw).hexdigest()==expected,label
  overruns=re.findall(r'(?:overrun|dropped events): (\d+)',text)
  assert len(overruns)==6 and all(x=='0' for x in overruns),label
 results.append({'label':label,'exit':status,'pinned_threads':pinned,**host})
 (out/'runs.json').write_text(json.dumps(results,indent=2))
 print(f'{label} PASS',flush=True)
print('MATRIX_ALL_PASS',flush=True)
