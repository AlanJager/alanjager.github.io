# HumanEval / HumanEval+ 完整编程基线

2026-10-15，执行前冻结。用户要求用较好性能配置跑编程标准评测，给完成时间和分数，以便后续不同硬件/公共API复测。

- 题集：官方HumanEvalPlus v0.1.10全部164题，完整增强输入，不使用Mini/NoExtreme。数据哈希见dataset-manifest.json。
- 评分：固定EvalPlus提交26d6d00bb1fd0fa37f39c99d5290da67891d1c5e，使用官方sanitize(entrypoint)与evaluate；HumanEval Base和HumanEval+ Base+Extra分别pass@1，n=1。
- 生成：官方OpenAI chat提示格式（公开题目加英文instruction prefix），单user消息；隐藏测试和参考实现不发送。按HumanEval编号0–163顺序，每题一次，串行；temperature0、top_p0.95、seed20261015、reasoning_effort none、max_tokens4096；无质量驱动重试、修复或选优。
- 配置：原引擎SHA256及IQ2_XS，RTX3090/16vCPU/63.305GiB；PLE RAM、pcie_frac1、tail0、prefill2048/CPU share0、7workers、auxauto、18GiB/13432槽、MTP4/minP0.5、32K/int8KV，prompt/conversation缓存0，自适应专家缓存开启。称为已测较好候选，不宣称全局最优。
- 模型加载后同一短预热（只回答就绪），正式164题计时。每题TTFT/E2E、usage/decode、原始SSE/正文/结束原因、读盘缺页/CPU，2秒资源采样。生成期间不评分，避免争用；总墙钟与请求耗时之和分列，加载、预热和评分单列。
- 全部生成后在无网络、无GPU、低权限、只读系统/输入、限内存/CPU/PID的Docker容器内评分。使用宿主Python3.10.12和隔离vendor依赖，官方评分器源码不修改。Docker Hub不可达的构建失败日志保留；未修改全局依赖。
- 正式输出按官方sanitize整理，保留原文与整理后版本。截断若保留完整可测函数，依官方结果计分，并单列截断状态。基础设施错误保留并停止，无隐藏重试。每道题的分数、时长、失败类型写入CSV。
- 评分环境以标准参考实现做完整164题自检，要求Base与Plus均164/164；该自检只测试评分基础设施，参考实现不进入模型输入。
- 原日常8080服务仅在空闲时停止；生成结束或异常在finally恢复，核验loaded、短生成、idle。本轮不调用付费公共API，不发布文章。
- 可比口径：函数级Python代码正确性；性能是单请求loopback时延，后续公共API保留客户端位置/网络、模型版本、推理模式、token上限与价格。公共榜分数仅作同版本同协议参考；本轮不据分数推断仓库级Agent能力。
