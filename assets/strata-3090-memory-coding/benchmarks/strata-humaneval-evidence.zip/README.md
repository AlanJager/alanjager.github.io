# Strata HumanEval / HumanEval+ 可复测证据

164道公开Python函数题，每题一次生成，temperature0、输出4096、并发1。results.csv为逐题分数和时间，summary.json为精确汇总；comparison.csv保留后续硬件和公共API栏位。

REPLAY.md给出同输入重放、官方sanitize与评分步骤。cases.json只含模型可见题目；dataset压缩包另含参考实现与隐藏测试，仅评分使用。EvalPlus源码及许可证在evalplus-source.tar.gz中；源码固定26d6d00bb1fd0fa37f39c99d5290da67891d1c5e。

recordings/candidate含原始SSE/回答/日志、逐题时间和资源数据；recordings/evaluation含参考自检、官方评分、整理后程序与sanitize审计；原始失败完整保留。截断状态与官方程序正确性分别记录，未通过任务不排除于耗时统计。

不要在日常宿主直接执行生成代码。score-container.sh使用隔离Docker、无网络、非root、只读系统与输入、内存CPU限制。该脚本依赖Linux系统库和独立vendor；参考自检必须全过。模型或第三方依赖未打包，dependencies.json记录本次环境。容器Docker Hub构建失败与随后使用主机Python隔离的记录单列，不属于模型性能样本。

安装路径与内部IP已脱敏；原记录单独保留。SHA256SUMS.txt校验本包脱敏后文件，input-sha256.json标记执行前原输入哈希。
