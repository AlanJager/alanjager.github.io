# RTX 3090 / Strata：164 道 Python 编程题的分数与完成时间

在 64GiB 虚拟机上，使用前轮表现较好的 **PLE RAM + pcie_frac=1** 配置，完整跑了 HumanEval 的 164 道题。每题一次生成，随后用 EvalPlus 同时检查原版测试和 HumanEval+ 增强测试。

**HumanEval 得分 98.17%（161/164），HumanEval+ 得分 95.12%（156/164）。164 题正式生成耗时 10 分 37.2 秒，每题端到端耗时中位数 3.17 秒，P95 为 7.52 秒。**

## 分数和时间

| 指标 | 本次结果 |
|---|---:|
| HumanEval pass@1 | 98.17% · 161/164 |
| HumanEval+ pass@1 | 95.12% · 156/164 |
| 原版通过、增强测试失败 | 5 题 |
| 正式 164 题生成总墙钟时间 | 10 分 37.2 秒 |
| 164 次请求耗时之和 | 10 分 10.6 秒 |
| 每题 E2E 均值 / 中位数 / P95 | 3.72 / 3.17 / 7.52 s |
| 单题最大 E2E | 17.70 s |
| TTFT 中位数 / P95 | 0.50 / 1.29 s |
| 模型加载 | 2 分 34.3 秒 |
| 短预热请求 | 0.34 s |
| 后处理与官方测试评分 | 50.9 秒 |
| 自然结束 / 达到输出上限 | 164/164 · 0/164 |
| 总输出 token | 40828 |

pass@1 表示每题只提交一份答案，该题所有对应测试通过才计一分。HumanEval+ 同时要求原版和新增测试通过。两个分数分别呈现。评分器先使用官方参考实现自检，原版与增强版均 **164/164**。[EvalPlus 官方评测说明](https://github.com/evalplus/evalplus/blob/26d6d00bb1fd0fa37f39c99d5290da67891d1c5e/docs/cli.md)

总墙钟从第一题发出计至最后一题完成并保存记录，包含串行请求之间约 0.15 秒的日志收尾。单题 E2E 从请求发出计到 SSE DONE。加载、短预热、后处理与评分单独计时；模型生成期间没有并行评分。

![本次得分与逐题完成时间](benchmark-results.png)

## 这次具体跑了什么

| 项目 | 固定条件 |
|---|---|
| 模型 | Qwen3.8-Flash-Next-GSQ-RCO IQ2_XS |
| 引擎 | Strata 0.1.43，源码 7695859aa13afb248bdb4d36f9b2e95707db079d |
| 硬件 | RTX 3090 24GiB；Xeon Gold 5318Y 的 16 vCPU；系统可见 63.305GiB |
| 驻留与分工 | PLE RAM；pcie_frac=1；18GiB / 13432 专家槽；7 workers / aux auto |
| 其他引擎设置 | prefill 2048 / CPU share=0；tail skip=0；MTP 4 / minP=0.5；32K / int8 KV |
| 请求设置 | 串行、每题一次；temperature=0、top_p=0.95、seed=20261015；reasoning_effort=none；输出上限 4096 token |
| 缓存 | prompt / conversation 缓存关闭；自适应专家缓存开启；只在开头做一次短预热 |
| 题集 | HumanEvalPlus v0.1.10，全部 164 题、完整增强测试；按编号顺序执行 |
| 提示词 | 官方 OpenAI chat 格式：英文 instruction 加原始题目；单 user 消息 |
| 评分环境 | 官方 EvalPlus 固定提交；Python 3.10.12；无网络、非 root、只读输入的 Docker 容器；并行评分 2 |

题目中的函数签名、说明和示例提供给模型；参考实现与隐藏测试只用于评分。每题直接保存首次答案，全部纳入评分和耗时统计。官方 sanitize 只提取可评测的程序，原始回答和处理后代码都保留。

本次 164 个请求全部 HTTP 200、收到 SSE 结束标记，前缀复用 token 为零。请求期累计读盘 **52KiB**，累计 major fault **1**，均出现在 HumanEval/27；本轮未追踪这次读取的文件归属。引擎 decode 吞吐中位数为 **84.8 token/s**；按总输出 token / 引擎 decode 总秒数计算为 **79.4 token/s**。横向使用体验优先看同一套题的完成时间；不同模型的 token 切分和回答长度会变化。

## 哪些题还没通过

HumanEval+ 共 8 题未通过，题号、结束原因、原版/新增测试状态和每题耗时在 [results.csv](results.csv) 中。失败记录与成功记录使用同一套统计口径。

| 题号 | 函数 | 原版测试 | 新增测试 | 输出结束 | E2E / s |
|---|---|---|---|---|---:|
| HumanEval/22 | `filter_integers` | pass | fail | stop | 1.47 |
| HumanEval/39 | `prime_fib` | pass | fail | stop | 4.99 |
| HumanEval/76 | `is_simple_power` | pass | fail | stop | 2.69 |
| HumanEval/91 | `is_bored` | pass | fail | stop | 3.96 |
| HumanEval/124 | `valid_date` | pass | fail | stop | 7.45 |
| HumanEval/132 | `is_nested` | fail | fail | stop | 7.30 |
| HumanEval/140 | `fix_spaces` | fail | fail | stop | 3.74 |
| HumanEval/145 | `order_by_points` | fail | fail | stop | 2.25 |

## 后续怎样比较显卡与公共服务

[comparison.csv](comparison.csv) 已填本机一行，另外留出候选硬件和公共 API 两行。对比时固定这 164 题、提示词、顺序、每题一次和输出预算，分别记录：

- **质量：** HumanEval+ pass@1，原版分数作为辅助；截断数另列。
- **时间：** 整套生成时间、每题 E2E 均值/中位数/P95，以及 TTFT。
- **条件：** 准确模型版本、量化、推理模式、客户端位置与并发。
- **费用：** API 实际账单或自有机器的计费口径，留空项保持未知。

本机客户端通过 loopback 访问服务；公共 API 的端到端时间会包含网络和服务端排队。同一客户端重放，能比较各自真实使用体验。当前没有调用公共 API，表中也没有填入推测成绩或耗时。

[重放步骤与命令](REPLAY.md) · [固定请求集](cases.json) · [逐题数据](results.csv) · [完整汇总](summary.json) · [脱敏证据包](strata-humaneval-evidence.zip)

## 注

- 这是一套 Python 函数实现基线，题目公开已久。跨模型比较需同时关注训练数据重合与是否已接近题集上限；仓库修改、多文件协作和工具调用适合另设真实项目任务。
- 正式整套只跑一轮；每题一份答案，n=1。P95 是 164 道不同题目的耗时分布，采用线性插值，反映本轮任务组合。固定同一题的重复波动需要额外重复整套或固定子集。
- 自适应专家缓存随题目顺序变化；本轮保留编号顺序与原始时间线。设置温度 0 和固定 seed，后续重复仍应记录实际输出差异。
- 评分按官方 sanitize 后的程序执行，原始回答与处理后代码均保留。本轮 164 题全部自然结束，8 道增强测试未通过题均为功能测试失败。
- 官方评分源码固定为 `26d6d00bb1fd0fa37f39c99d5290da67891d1c5e`，数据压缩文件 SHA256 为 `272720b90ac375502c8ed23cd791c2a93dfb22a911641a494da74a426c09f101`。Python、依赖、容器限制、全部请求和评分记录随附件保存。
- 评分容器使用 4 CPU、6GiB 内存、256 PID 上限，关闭网络、移除 capabilities；EvalPlus 每个程序内存上限为 4GiB。官方参考实现自检通过后才开始模型评测。
