from pathlib import Path
import json,re,hashlib,csv,statistics as st,math,collections
R=Path(__file__).resolve().parent;D=R/'remote/candidate';E=R/'remote/evaluation'
cases=json.loads((R/'cases.json').read_text())['cases'];assert len(cases)==164
scored=json.loads((E/'generated-eval-results.json').read_text());reference=json.loads((E/'reference-eval-results.json').read_text());assert len(scored['eval'])==len(reference['eval'])==164
assert all(v[0]['base_status']==v[0]['plus_status']=='pass' for v in reference['eval'].values())
rows=[]
for case in cases:
 d=json.loads((D/(case['id']+'.json')).read_text());g=scored['eval'][case['task_id']];assert len(g)==1;g=g[0]
 assert d['request']['messages']==case['messages'];assert d['http_status']==200 and d['sse_done'] and d['error'] is None
 for k,v in {'temperature':0,'top_p':.95,'seed':20261015,'reasoning_effort':'none','max_tokens':4096}.items():assert d['request'][k]==v
 assert d['input_sha256']==hashlib.sha256(json.dumps(case['messages'],ensure_ascii=False,sort_keys=True).encode()).hexdigest()
 reuse=re.search(r'prompt (\d+) tokens = (\d+) reused',d['engine_log']);assert reuse and int(reuse[2])==0
 t=d['timings'];b=d['before'];a=d['after'];usage=d['usage'];tokens=usage['completion_tokens'];base=g['base_status']=='pass';plus=base and g['plus_status']=='pass'
 row={'task_id':case['task_id'],'entry_point':case['entry_point'],'input_sha256':d['input_sha256'],'base_pass':base,'plus_pass':plus,'base_status':g['base_status'],'extra_status':g['plus_status'],'finish_reason':d['finish_reason'],'natural_stop':d['finish_reason']=='stop','ttft_s':d['ttft'],'e2e_s':d['e2e'],'input_tokens':usage['prompt_tokens'],'output_tokens':tokens,'engine_decode_tps':t['predicted_per_second'],'engine_decode_s':t['predicted_ms']/1000,'engine_prefill_s':t['prompt_ms']/1000,'draft_accept_ratio':t.get('draft_n_accepted',0)/t['draft_n'] if t.get('draft_n') else None,'read_MB':(a['io']['read_bytes']-b['io']['read_bytes'])/1e6,'major_faults':a['major_faults']-b['major_faults'],'cpu_seconds':(a['cpu_ticks']-b['cpu_ticks'])/100,'reused_tokens':int(reuse[2]),'reasoning_characters':len(d['reasoning']),'response_sha256':hashlib.sha256(d['content'].encode()).hexdigest(),'record':'candidate/'+case['id']+'.json'}
 rows.append(row)
assert len(rows)==164
base=sum(r['base_pass'] for r in rows);plus=sum(r['plus_pass'] for r in rows);assert abs(scored['pass_at_k']['base']['pass@1']-base/164)<1e-10;assert abs(scored['pass_at_k']['plus']['pass@1']-plus/164)<1e-10

def quantile(v,p):
 v=sorted(v);idx=(len(v)-1)*p;lo=math.floor(idx);hi=math.ceil(idx);return v[lo]+(v[hi]-v[lo])*(idx-lo)

def stats(k):
 v=[r[k] for r in rows if r[k] is not None];return {'mean':st.mean(v),'median':st.median(v),'p95':quantile(v,.95),'min':min(v),'max':max(v),'sum':sum(v)}
env=json.loads((D/'environment.json').read_text());suite=json.loads((D/'suite-timing.json').read_text());warm=json.loads((D/'warmup.json').read_text());scoretime=json.loads((E/'generated-timing.json').read_text())
summary={'n':164,'human_eval':{'passed':base,'score_percent':100*base/164},'human_eval_plus':{'passed':plus,'score_percent':100*plus/164},'base_pass_plus_fail':base-plus,'suite_wall_s':suite['suite_wall_s'],'load_s':env['load_seconds'],'warmup_s':warm['e2e'],'score_wall_s':scoretime['wall_s'],'finish_counts':dict(collections.Counter(r['finish_reason'] for r in rows)),'cutoff_plus_pass':sum(r['plus_pass'] and r['finish_reason']=='length' for r in rows),'stats':{k:stats(k) for k in ['ttft_s','e2e_s','input_tokens','output_tokens','engine_decode_tps','engine_decode_s','engine_prefill_s','cpu_seconds','read_MB','major_faults']},'aggregate_engine_decode_tps':sum(r['output_tokens'] for r in rows)/sum(r['engine_decode_s'] for r in rows),'request_time_per_plus_pass_s':sum(r['e2e_s'] for r in rows)/plus if plus else None,'all_zero_io':all(r['read_MB']==0 and r['major_faults']==0 for r in rows),'input_cases_sha256':hashlib.sha256((R/'cases.json').read_bytes()).hexdigest(),'scorer_selftest':'164/164 base and plus','failure_ids':[r['task_id'] for r in rows if not r['plus_pass']]}
for name,data in [('results.json',rows),('summary.json',summary)]: (R/name).write_text(json.dumps(data,ensure_ascii=False,indent=2))
with (R/'results.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
with (R/'comparison.csv').open('w') as f:
 fields=['run','model','hardware_or_provider','dataset','tasks','temperature','max_output_tokens','concurrency','human_eval_percent','human_eval_plus_percent','suite_wall_s','e2e_mean_s','e2e_median_s','e2e_p95_s','ttft_median_s','natural_stop','length_cutoff','cost','status'];w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerow({'run':'strata-3090-64g-pcie1','model':'Qwen3.8-Flash-Next-GSQ-RCO-IQ2_XS','hardware_or_provider':'RTX3090 24GiB / Xeon5318Y 16vCPU / 63.305GiB','dataset':'HumanEvalPlus v0.1.10 full','tasks':164,'temperature':0,'max_output_tokens':4096,'concurrency':1,'human_eval_percent':100*base/164,'human_eval_plus_percent':100*plus/164,'suite_wall_s':suite['suite_wall_s'],'e2e_mean_s':stats('e2e_s')['mean'],'e2e_median_s':stats('e2e_s')['median'],'e2e_p95_s':stats('e2e_s')['p95'],'ttft_median_s':stats('ttft_s')['median'],'natural_stop':sum(r['natural_stop'] for r in rows),'length_cutoff':sum(r['finish_reason']=='length' for r in rows),'status':'measured'})
 for run in ['candidate-hardware','public-api']:w.writerow({'run':run,'dataset':'HumanEvalPlus v0.1.10 full','tasks':164,'temperature':0,'max_output_tokens':4096,'concurrency':1,'status':'not measured'})
print(json.dumps(summary,ensure_ascii=False,indent=2))
