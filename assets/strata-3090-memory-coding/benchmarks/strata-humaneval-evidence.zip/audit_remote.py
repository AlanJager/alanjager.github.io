from pathlib import Path
import json,hashlib,subprocess
R=Path(__file__).resolve().parent
manifest=json.loads((R/'input-sha256.json').read_text());checks={f:hashlib.sha256((R/f).read_bytes()).hexdigest()==sha for f,sha in manifest.items()};assert all(checks.values())
sources=['evalplus/evaluate.py','evalplus/sanitize.py','evalplus/eval/__init__.py','evalplus/eval/utils.py','evalplus/data/humaneval.py'];source_checks={}
for name in sources:
 a=(R/'evalplus-src'/name).read_bytes();b=(R/'vendor'/name).read_bytes();assert a==b,name;source_checks[name]=hashlib.sha256(a).hexdigest()
(R/'environment-audit.json').write_text(json.dumps({'input_manifest':checks,'official_scoring_sources_unchanged':source_checks,'python':subprocess.check_output(['python3','--version'],text=True).strip(),'clock_ticks_per_second':subprocess.check_output(['getconf','CLK_TCK'],text=True).strip(),'scoring_container_image_id':subprocess.check_output(['docker','image','inspect','strata-eval-sandbox:20261015','--format','{{.Id}}'],text=True).strip()},indent=2));print('Frozen inputs and official scorer verified')
