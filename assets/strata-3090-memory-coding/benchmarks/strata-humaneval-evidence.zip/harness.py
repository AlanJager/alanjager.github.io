#!/usr/bin/env python3
import os,sys,json,time,signal,subprocess,hashlib,threading,re,urllib.request,datetime,fcntl
from pathlib import Path
ROOT=Path(__file__).resolve().parent;REPO=ROOT.parent/'Strata';URL='http://127.0.0.1:8081'
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2))
def stamp():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def snap(endpoint,timeout=5):
 try:
  with urllib.request.urlopen(URL+endpoint,timeout=timeout) as r:return json.load(r)
 except Exception as e:return {'error':repr(e)}
def procstat(pid):
 try:
  p=Path('/proc')/str(pid);st=(p/'stat').read_text().rsplit(') ',1)[1].split()
  return {'pid':pid,'cpu_ticks':int(st[11])+int(st[12]),'major_faults':int(st[9]),'rss_bytes':int(st[21])*4096,'io':{k:int(v) for k,v in (x.split(':') for x in (p/'io').read_text().splitlines())}}
 except Exception:return {}
def child(pid):
 try:return int((Path('/proc')/str(pid)/'task'/str(pid)/'children').read_text().split()[0])
 except Exception:return None
def sample(out,pid,stop):
 with out.open('w') as f:
  while not stop.is_set():
   r={'utc':stamp(),'time':time.time(),'proc':procstat(pid)}
   r['meminfo']={k:int(v.strip().split()[0])*1024 for k,v in (x.split(':') for x in Path('/proc/meminfo').read_text().splitlines()) if k in ['MemAvailable','MemFree','Cached','Mlocked','SwapFree']}
   r['diskstats']=[x.split() for x in Path('/proc/diskstats').read_text().splitlines() if x.split()[2]=='vda']
   r['cpu_stat']=Path('/proc/stat').read_text().splitlines()[0]
   try:r['gpu']=subprocess.check_output(['nvidia-smi','--query-gpu=utilization.gpu,memory.used,power.draw,temperature.gpu,clocks.sm,clocks.mem,pcie.link.gen.current,pcie.link.width.current','--format=csv,noheader,nounits'],text=True,timeout=3).strip()
   except Exception as e:r['gpu_error']=repr(e)
   f.write(json.dumps(r)+'\n');f.flush();stop.wait(2)
MARK_FIRST=None
def request(case,msgs,out,pid,log):
 payload={'model':'qwen3.8-flash-next-iq2_xs','messages':msgs,'temperature':0,'seed':20261013,'reasoning_effort':'none','max_tokens':case['max_tokens'],'stream':True,'stream_options':{'include_usage':True}}
 payload.update({'strata_tune':case['tune']} if case.get('tune') else {})
 rec={'id':case['id'],'case_id':case.get('case_id',case['id']),'request':payload,'utc':stamp(),'time':time.time(),'content':'','reasoning':'','events':[],'sse_done':False,'error':None,'before':procstat(pid),'ttft':None}
 offset=log.stat().st_size if log.exists() else 0;t=time.perf_counter()
 try:
  q=urllib.request.Request(URL+'/v1/chat/completions',data=json.dumps(payload).encode(),headers={'Content-Type':'application/json'})
  with urllib.request.urlopen(q,timeout=600) as r:
   rec['http_status']=r.status
   for line in r:
    if not line.startswith(b'data:'):continue
    raw=line[5:].strip()
    if raw==b'[DONE]':rec['sse_done']=True;break
    event=json.loads(raw);elapsed=time.perf_counter()-t;rec['events'].append({'seconds':elapsed,'data':event})
    if 'error' in event:rec['error']=event['error']
    for c in event.get('choices',[]):
     d=c.get('delta') or {};s=d.get('content') or '';rec['content']+=s;rec['reasoning']+=d.get('reasoning_content') or d.get('reasoning') or ''
     if s and rec['ttft'] is None:
      rec['ttft']=elapsed
      if MARK_FIRST:MARK_FIRST()
     if c.get('finish_reason'):rec['finish_reason']=c['finish_reason']
    for k in ['usage','timings']:
     if k in event:rec[k]=event[k]
 except Exception as e:rec['error']=repr(e)
 rec['e2e']=time.perf_counter()-t;rec['after']=procstat(pid);time.sleep(.15)
 rec['engine_log']=log.read_bytes()[offset:].decode(errors='replace') if log.exists() else ''
 (out/(case['id']+'.engine.log')).write_text(rec['engine_log']);save(out/(case['id']+'.json'),rec);(out/(case['id']+'.txt')).write_text(rec['content'])
 summary={k:rec.get(k) for k in ['id','finish_reason','ttft','e2e','error','usage','timings']};print(json.dumps(summary,ensure_ascii=False),flush=True)
 return rec

def stop_server(p):
 if p and p.poll() is None:
  os.killpg(p.pid,signal.SIGTERM)
  try:p.wait(timeout=20)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
