from pathlib import Path
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
R=Path(__file__).resolve().parent;s=json.loads((R/'summary.json').read_text());rows=json.loads((R/'results.json').read_text());font=next(Path('/System/Library/AssetsV2/com_apple_MobileAsset_Font7').glob('*/AssetData/PingFang.ttc'));font_manager.fontManager.addfont(str(font))
plt.rcParams.update({'font.family':font_manager.FontProperties(fname=str(font)).get_name(),'font.size':11,'axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'#fcfbf8','axes.facecolor':'#fcfbf8','savefig.facecolor':'#fcfbf8','axes.unicode_minus':False})
fig,axs=plt.subplots(1,2,figsize=(12,4.4),gridspec_kw={'width_ratios':[1,1.6]},layout='constrained')
ax=axs[0];vals=[s['human_eval']['score_percent'],s['human_eval_plus']['score_percent']];bars=ax.bar(['HumanEval','HumanEval+'],vals,color=['#71a5ad','#146d65'],width=.5);ax.bar_label(bars,labels=[f'{v:.2f}%\n{n}/164' for v,n in zip(vals,[s['human_eval']['passed'],s['human_eval_plus']['passed']])],padding=5);ax.set_ylim(0,110);ax.set_yticks([0,20,40,60,80,100]);ax.set_ylabel('pass@1 / %');ax.set_title('每题一次，全部测试通过计分',fontsize=12);ax.grid(axis='y',alpha=.15);ax.set_axisbelow(True)
ax=axs[1]
for passed,color,label in [(True,'#146d65','HumanEval+ 通过'),(False,'#c1734a','未通过')]:
 rr=[r for r in rows if r['plus_pass']==passed];ax.scatter([int(r['task_id'].split('/')[1]) for r in rr],[r['e2e_s'] for r in rr],c=color,label=label,s=24,alpha=.8)
ax.axhline(s['stats']['e2e_s']['p95'],color='#8b9291',ls='--',lw=1,label=f"P95 {s['stats']['e2e_s']['p95']:.2f}s");ax.set_xlabel('题目编号（执行顺序）');ax.set_ylabel('端到端耗时 / 秒');ax.set_ylim(bottom=0);ax.set_title(f"164 题生成总时间：{s['suite_wall_s']/60:.2f} 分钟",fontsize=12);ax.legend(frameon=False,fontsize=9);ax.grid(axis='y',alpha=.15)
fig.suptitle('RTX 3090 / 64GiB · Strata IQ2_XS 编程基线',x=.02,ha='left',fontsize=17,fontweight='bold');fig.supxlabel('HumanEval+ v0.1.10 全量 · n=1 · 串行 · temperature=0 · 输出上限4096 · PLE RAM / pcie_frac=1 / tail=0',fontsize=9)
fig.savefig(R/'benchmark-results.png',dpi=180,bbox_inches='tight');fig.savefig(R/'benchmark-results.svg',bbox_inches='tight')
