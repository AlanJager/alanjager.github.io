"""Run with the pinned EvalPlus installation. This parses code; it does not execute solutions."""
import argparse,json
from pathlib import Path
from evalplus.sanitize import sanitize
p=argparse.ArgumentParser();p.add_argument('--cases',default='cases.json');p.add_argument('--records',required=True);p.add_argument('--output',required=True);a=p.parse_args();target=Path(a.output);assert not target.exists()
cases=json.loads(Path(a.cases).read_text())['cases'];rows=[]
for c in cases:
 r=json.loads((Path(a.records)/(c['id']+'.json')).read_text());assert r['request']['messages']==c['messages'];assert r['sse_done'] and r['error'] is None
 rows.append({'task_id':c['task_id'],'solution':sanitize(r['content'],entrypoint=c['entry_point'])})
target.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows));print(len(rows),'solutions')
