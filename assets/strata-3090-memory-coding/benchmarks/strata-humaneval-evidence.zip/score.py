import json,time,gzip,sys,hashlib,platform,importlib.metadata
from pathlib import Path
from evalplus.data import get_human_eval_plus,write_jsonl
from evalplus.sanitize import sanitize
from evalplus.evaluate import evaluate
D=Path('/out');B=Path('/bench');mode=sys.argv[1];problems=get_human_eval_plus();assert len(problems)==164
start=time.perf_counter()
if mode=='reference':
 samples=[{'task_id':key,'solution':p['prompt']+p['canonical_solution']} for key,p in problems.items()]
 path=D/'reference.jsonl';write_jsonl(str(path),samples)
elif mode=='generated':
 cases=json.loads((B/'cases.json').read_text())['cases'];samples=[];changes=[]
 for c in cases:
  rec=json.loads((B/'candidate'/(c['id']+'.json')).read_text());assert rec['task_id']==c['task_id']
  solution=sanitize(rec['content'],entrypoint=c['entry_point']);samples.append({'task_id':c['task_id'],'solution':solution});changes.append({'task_id':c['task_id'],'raw_sha256':hashlib.sha256(rec['content'].encode()).hexdigest(),'sanitized_sha256':hashlib.sha256(solution.encode()).hexdigest(),'finish_reason':rec.get('finish_reason'),'raw_chars':len(rec['content']),'sanitized_chars':len(solution)})
 path=D/'samples-sanitized.jsonl';write_jsonl(str(path),samples);(D/'sanitizer-audit.json').write_text(json.dumps(changes,indent=2))
else:raise ValueError(mode)
sanitized_s=time.perf_counter()-start
result_file=D/(mode+'-eval-results.json');assert not result_file.exists()
evaluate(dataset='humaneval',samples=str(path),parallel=2,test_details=True,output_file=str(result_file))
(D/(mode+'-timing.json')).write_text(json.dumps({'wall_s':time.perf_counter()-start,'prepare_s':sanitized_s,'python':platform.python_version(),'platform':platform.platform(),'tasks':164,'evalplus_revision':'26d6d00bb1fd0fa37f39c99d5290da67891d1c5e'},indent=2))
if mode=='reference':
 r=json.loads(result_file.read_text());assert all(x['base_status']=='pass' and x['plus_status']=='pass' for task in r['eval'].values() for x in task), 'Reference implementation failed; do not issue model scores'
print('SCORING_COMPLETE '+mode,flush=True)
