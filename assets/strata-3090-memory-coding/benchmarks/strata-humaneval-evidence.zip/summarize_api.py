"""Portable summary for identical cases replayed through a chat API."""
import argparse,json,statistics as st,math,hashlib
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--cases',default='cases.json');p.add_argument('--records',required=True);p.add_argument('--evaluation',required=True);p.add_argument('--output',required=True);a=p.parse_args()
cases=json.loads(Path(a.cases).read_text())['cases'];ev=json.loads(Path(a.evaluation).read_text());records=[]
for c in cases:
 r=json.loads((Path(a.records)/(c['id']+'.json')).read_text());assert r['request']['messages']==c['messages'];assert r['request'].get('max_tokens',r['request'].get('max_completion_tokens'))==c['max_tokens'];assert r['sse_done'] and not r['error'];records.append(r)
assert len(ev['eval'])==len(cases);base=sum(ev['eval'][c['task_id']][0]['base_status']=='pass' for c in cases);plus=sum(ev['eval'][c['task_id']][0]['base_status']==ev['eval'][c['task_id']][0]['plus_status']=='pass' for c in cases)
def stats(k):
 v=sorted(r[k] for r in records if r[k] is not None);idx=(len(v)-1)*.95;lo=int(idx);hi=math.ceil(idx)
 return {'mean':st.mean(v),'median':st.median(v),'p95':v[lo]+(v[hi]-v[lo])*(idx-lo),'sum':sum(v),'max':max(v)}
out={'tasks':len(cases),'cases_sha256':hashlib.sha256(Path(a.cases).read_bytes()).hexdigest(),'human_eval_percent':100*base/len(cases),'human_eval_plus_percent':100*plus/len(cases),'e2e_s':stats('e2e'),'ttft_s':stats('ttft'),'natural_stop':sum(r['finish_reason']=='stop' for r in records),'length_cutoff':sum(r['finish_reason']=='length' for r in records),'model':records[0]['request']['model'],'parameters':{k:v for k,v in records[0]['request'].items() if k not in ['messages','model']}}
Path(a.output).write_text(json.dumps(out,ensure_ascii=False,indent=2));print(json.dumps(out,ensure_ascii=False,indent=2))
