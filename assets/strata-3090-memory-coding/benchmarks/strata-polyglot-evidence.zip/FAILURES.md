# Aider Polyglot：具体代码轨迹

以下案例取自初轮正式固定题序中的记录，用于解释成功与失败方式。C++轨迹包含默认头文件lint问题；修正复测后的逐题变化见cpp-control-summary.json，最终功能汇总见FINAL-REPORT.md。原始案例保留，便于追踪工作流变化。

| 任务 | 首次测试 | 一次反馈后 | 观察 |
| --- | --- | --- | --- |
| JavaScript / rest-api | 通过 | 通过 | 一次模型调用完成，整题22.73秒；包含接口实现与验收测试 |
| Python / rest-api | 失败 | 通过 | 首次混淆JSON文本与Python对象；反馈后修复输入解析与返回序列化，整题52.11秒 |
| Java / rational-numbers | 失败 | 失败 | 133.85秒；修复调用达到8192-token上限，`Math.pow(2.0, 3.321928094887362)` 同一表达式出现189次 |
| Java / alphametics | 失败 | 失败 | 算式解析错误把 `=` 当成待赋值字符，最终 10 个测试中 9 个失败 |
| Go / connect | 失败 | 失败 | 470.84秒、9次调用；长回复和反复修改后仍未通过完整测试 |
| C++ / diamond | 失败 | 失败 | Aider把回复中的解释句当成文件名，新增了141字节文件；异常文件原样保留 |
| C++ / clock | 编译失败 | 编译失败 | 首次定义 `Clock`，测试使用 `date_independent::clock`；改名后仍缺少字符串转换和 `!=` 运算接口 |
| C++ / space-age | 编译失败 | 通过 | 耗时237.76秒，11次模型调用；其中一次输出达到8192-token上限，包含反复解释类名与命名空间的文本 |
| Rust / robot-name | 编译失败 | 通过 | 首次在静态变量里调用非 const 的 `HashSet::new`；根据编译错误修改后通过完整测试 |
| JavaScript / transpose | 失败 | 失败 | 测试要求字符串数组，最终输出仍是连接后的单个字符串；包括空输入在内的验收不符 |

这些任务揭示了三个具体环节：理解需求，遵守现有接口，根据反馈修复。模型能生成看似合理的核心算法，仍可能在类名、类型、运算符和静态初始化约束上失败。任务耗时需覆盖修复循环，验收应执行测试。

原始路径均在 `remote/formal/<语言>/exercises/practice/<题目>/`：`.api-*.json` 保存请求与响应，`.test-*.log` 保存编译测试日志，`.task.json` 保存两次测试结果和各项耗时。模型输出文件也保留在同目录。

五题接入预检另有 Rust / accumulate 的 `Fn` 与可变捕获闭包不兼容问题，该次预检不进入正式分数。正式题集中同名题的结果单独统计。

## 上下文超限

正式途中发现 C++ spiral-matrix 的编译错误反馈约163958 token；Java phone-number 为30919，Java bowling 为25521。它们与8192输出预留相加超过32768总上下文，引擎返回明确拒绝。原始错误保存在对应.api记录中；全部超限任务和最终数量以summary.json为准。这些失败保留在完整题集的分母里，单列为上下文和反馈处理限制。
## Go paasio：并发计数错误和过长测试反馈

初次生成后，并发读写测试发现计数丢失：例如要求读取 400000 bytes、调用 8000 次，实测报告 340800 bytes、6831 次。随后一致性检查逐条输出失败，第一次测试日志约 933KiB。Aider 把测试反馈交回模型时，引擎测得输入 415070 token，加上预留 8192 输出超过 32768 上下文，因此拒绝该修复调用。该题两次测试均未通过，仍计入完整成绩。初始实现的并发正确性和修复阶段的反馈长度是两个可直接观察的问题。

证据：`remote/formal/go/exercises/practice/paasio/.test-00.log`、`.api-001.json`、`.task.json`。

## JavaScript scale-generator：生成很快，重复输出仍未完成任务

两次模型调用均生成 8192 token 后以 `length` 结束，首次与最终测试均未通过，任务 E2E 为 173.56 秒。第二次调用输入 16246 token，引擎记录 prefill 10.915 秒、decode 76.367 秒（107.3 token/s），请求期 OS 读取 0MB、major fault 为 0。输出包含反复解释音名转换的注释；这说明本例的高生成速率可以与低任务完成质量同时出现。

证据：`remote/formal/javascript/exercises/practice/scale-generator/.api-000.json`、`.api-001.json`、`.api-001.engine.log`、`.task.json`。

