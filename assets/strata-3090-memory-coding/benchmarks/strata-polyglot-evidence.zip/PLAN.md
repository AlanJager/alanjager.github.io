# Aider Polyglot / Strata 3090

用户授权先5题接入预检，再完整225题串行。测试固定模型与上一轮HumanEval相同；PLE RAM、pcie_frac1、tail0、prefill2048/CPUshare0、7workers、18GiB专家缓存、32K/int8 KV、MTP4；禁用prompt/conversation缓存。

- Aider源码：5dc9490bb35f9729ef2c95d00a19ccd30c26339c
- 题库：7e0611e77b54e2dea774cdc0aa00cf9f7ed6144f
- 225题：C++26、Go39、Java47、JavaScript49、Python34、Rust30。
- 每题独立目录，官方提示和测试；whole编辑格式；尝试2次（首次+一次测试反馈）。保留Aider自身格式纠错行为和每次API调用。
- temperature0、top_p0.95、reasoning_effort none、单次输出8192；所有模型请求只发往本地Strata。
- 正式任务顺序预先固定：排序后的路径列表以seed20261015打乱，保存order.json。预检5题为Python/Go/Java/JS/Rust每种路径排序第一题；正式重启引擎，重新从原题开始。
- Docker测试：无网络/无GPU、非root、只读工具链与系统，4CPU/6GiB、PID256、每次官方测试180秒超时。生成代码只在该环境执行。
- 评分前用题库参考实现对全部题目做环境自检。环境故障独立记录并修复；不改验收断言，不按模型结果筛题。
- 官方duration只覆盖coder.run，排除测试。另测端到端任务时间（调用、应用修改、编译测试、反馈）及完整串行墙钟；环境装配/模型加载单列。
- 输出首次通过率、最多两次尝试通过率、E2E分布、API/测试耗时、token数、截断/格式错误/环境异常，失败也计入任务数。超时记失败并保留轨迹。
- 公共榜单只作协议核对；本轮没有调用付费公共API。编辑格式/版本/预算不同的成绩分列。

参考实现装配：Rust采用题库.meta/Cargo-example.toml，仅用于参考自检；Java复制.meta中完整辅助类；C++头文件实现使用空.cpp。正式题目保留原文件和Cargo配置。依赖提前缓存，正式测试断网。Aider默认lint和格式修正保持开启，因此一次测试尝试可能包含多个模型请求，逐调用记录。

预检修正：Aider默认后台摘要可能跨题继续，初次5题只用作接入/功能检查，不作正式耗时基线。正式协议将summarize_start后立即summarize_end，等待摘要完成；保留摘要功能和内容，所有模型调用严格串行，计入本题时间。这一调度调整需在后续API对比中保持相同。
