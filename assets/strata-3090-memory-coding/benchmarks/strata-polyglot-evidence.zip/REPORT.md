# 原始记录：3090 跑 Aider Polyglot 完整 225 题

> 本报告保留初轮原始结果，其中 C++ 头文件被默认 lint 按 C 解析，产生额外错误反馈。全部 26 道 C++ 题已安排修正复测；最终结果请看 [修正后的汇总报告](FINAL-REPORT.md)。

RTX 3090 / 64GiB 上，Strata 运行 Qwen3.8-Flash-Next-GSQ-RCO IQ2_XS，完成了 Aider Polyglot 全部 225 题。首次运行测试通过 **43/225（19.11%）**，允许一次测试反馈后最终通过 **111/225（49.33%）**。完整串行评测耗时 **270.60 分钟**；单题端到端中位数 **52.1 秒**，P95 **200.6 秒**。

测试流程是“读需求与已有源文件 → 输出修改后的完整文件 → 编译测试 → 根据报错修复一次”。Aider 默认 lint 和格式纠错仍启用，首次测试前可能有额外模型调用。通过要求是该题全部验收测试通过。初始上下文包含题目说明和可编辑源文件，验收测试作为执行后的反馈；本轮没有让模型主动检索仓库或读取其他文件。

![分语言成绩和总时间分解](benchmark-results.png)

## 六种语言分别完成了多少

| 语言 | 题数 | 首次测试通过 | 一次反馈后最终通过 | 单题 E2E 中位数 | P95 |
| --- | ---: | ---: | ---: | ---: | ---: |
| C++ | 26 | 2（7.7%） | 13（50.0%） | 156.7 秒 | 250.5 秒 |
| Go | 39 | 6（15.4%） | 15（38.5%） | 33.2 秒 | 209.1 秒 |
| Java | 47 | 7（14.9%） | 20（42.6%） | 67.6 秒 | 157.7 秒 |
| JavaScript | 49 | 11（22.4%） | 26（53.1%） | 47.5 秒 | 102.4 秒 |
| Python | 34 | 10（29.4%） | 23（67.6%） | 41.3 秒 | 138.7 秒 |
| Rust | 30 | 7（23.3%） | 14（46.7%） | 40.7 秒 | 181.3 秒 |

测试反馈额外挽回 **68 题**，最终还有 **114 题**未通过。逐题结果、所有模型输出和编译测试日志均保留，失败题包含在分母与耗时统计中。

## 时间花在哪里

| 指标 | 本轮实测 | 计量范围 |
| --- | ---: | --- |
| 完整 225 题墙钟 | 270.60 分钟 | 从正式套件启动到最后一题完成，含任务间开销 |
| Aider 编辑平均时间 | 61.6 秒/题 | coder.run，含本轮同步摘要，排除编译测试 |
| 全部模型调用 | 230.20 分钟 | 代码、格式纠错及对话摘要 |
| 其中代码与格式纠错 | 185.15 分钟 | 534 次调用 |
| 其中对话摘要 | 45.05 分钟 | 264 次调用 |
| 编译和测试 | 39.53 分钟 | 容器启动、编译及测试执行 |
| 任务内客户端其他 | 50.6 秒 | 文件处理、应用修改、lint、清理等剩余时间 |
| 最长单题 E2E | 470.8 秒 | 包含生成、摘要与测试 |
| 单题 E2E 中位数 / P95 | 52.1 / 200.6 秒 | 完整处理过程，包含失败题 |
| 模型加载 | 168.3 秒 | 独立于正式套件时间 |

在累计任务E2E中，模型API调用占 **85.1%**，编译测试占 **14.6%**。模型调用包括代码生成、内部纠错与对话摘要。

按任务结果分组，等待时间如下：

| 结果 | 题数 | E2E 中位数 | P95 |
| --- | ---: | ---: | ---: |
| 首次测试通过 | 43 | 18.2 秒 | 50.7 秒 |
| 反馈后修复成功 | 68 | 52.0 秒 | 234.7 秒 |
| 最终未通过 | 114 | 67.9 秒 | 204.3 秒 |

![各题完整等待时间](task-latency.png)

所有模型调用都串行完成。为便于归属每题时间，Aider 的后台摘要在本轮改为等待完成并提交后再继续；运行时记录方法名与脚本哈希，并检查每题 API 时间加测试时间不超过 E2E。这个改动会影响工作流耗时和摘要生效时点，复测需使用相同协议。

本轮使用非流式 Aider 请求，记录的是完整 API 耗时；客户端 TTFT 未采集。按服务返回的 usage，累计处理输入 **3,016,182 token**、输出 **833,832 token**，包含摘要和纠错调用。成功调用的最大输入 **24,525 token**、最大输出 **8,192 token**。引擎日志解析到 **792/798 次**完成记录，累计 prefill **2893.2 秒**、decode **10892.2 秒**；这些是模型内部阶段时间，口径与用户等待时间不同。

## 运行质量与资源观测

| 观测 | 数量 |
| --- | ---: |
| 输出达到 length 上限的调用 / 涉及题目 | 29 / 27 |
| 发生格式解析错误的题目 | 1 |
| Aider token 预算耗尽记录涉及题目（含输出上限） | 27 |
| 引擎拒绝上下文超限的调用 / 题目 | 6 / 5 |
| API 错误题目 | 5 |
| 测试超时题目 | 0 |
| 任务级异常题目 | 0 |
| 请求区间引擎累计磁盘读取 | 0.094 MiB |
| 请求区间引擎累计 major fault | 1 |

涉及截断的题目中有 5 题最终通过测试：Aider可能已经应用了有效修改，后续解释或纠错调用才达到输出上限。评分依据最终文件的验收结果，截断另行记录。

磁盘读量来自引擎进程 `/proc/PID/io` 在每次 API 调用前后的差值；major fault 来自同进程计数。它们用于观察模型请求期的权重读取，不包含整机编译与依赖缓存读写。资源采样另保留系统内存、GPU 利用率/功耗和块设备计数的共同时间轴。

32K总上下文需同时容纳输入和输出预留。固定8192输出上限时，单次输入可用空间为24576 token；过长的编译错误或历史会触发明确拒绝。超限任务保留在225题分母中，属于本轮上下文与反馈处理策略的限制。被拒绝的请求没有成功返回usage，未计入处理token总量。

具体失败示例见 [失败分析](FAILURES.md)，完整失败名单列在文末。

## 用来判断个人编码场景

这套结果覆盖小型源文件编辑、多语言编译和一次报错修复。完成率回答能否通过验收；单题 E2E 回答要等多久；首次与最终通过率之差回答一次反馈能挽回多少任务。把这三个指标和日常项目任务放在一起，更容易判断是否适合作为个人编码助手。

此前 HumanEval+ 的 156/164（95.12%）对应 Python 函数生成。本轮包含文件编辑协议、工具链与测试反馈，两组结果分别保留。真实项目的跨文件检索、依赖升级、长对话、工具调用和持续多轮修改，还需要项目级任务补充验证。

对比另一张显卡时，固定同一模型、量化、Aider 版本和题序，观察完成率与 E2E。对比公共 API 时，同时记录模型版本、推理模式、预算、网络延迟和实际费用。[复测协议](REPLAY.md)与[对比表](comparison.csv)已准备；当前没有公共 API 实测或费用数据。[历史榜单参考](PUBLIC-REFERENCES.md)另列测试日期、编辑格式和计时口径。

## 配置与复现

- 硬件：RTX 3090 24GiB、Xeon Gold 5318Y 16 vCPU、系统可见约 63.3GiB 内存。
- 模型：Qwen3.8-Flash-Next-GSQ-RCO IQ2_XS。Strata 0.1.43，提交 `7695859aa13afb248bdb4d36f9b2e95707db079d`。
- 引擎：PLE RAM、pcie_frac=1、prefill=2048 / CPU share=0、尾部专家跳过=0、7 workers、18GiB 专家缓存、32K/int8 KV、MTP=4；关闭 prompt 与 conversation 缓存。
- 采样：temperature=0、top_p=0.95、seed=20261015、reasoning_effort=none、单次输出上限8192。
- 编辑：whole；最多两次测试尝试；保留 Aider 默认 lint、格式修正与摘要，摘要串行等待，历史摘要阈值2048 token，摘要使用同一模型。
- 题序：225 个路径排序后按 seed20261015 打乱；同一套顺序保存在 order.json。
- 测试：无网络、非 root、无 GPU 的 Docker 环境；4 CPU / 6GiB，每次测试180秒，每题600秒。
- 环境自检：官方参考程序 225/225 通过。Aider 与题库的跟踪文件与固定提交归档一致。正式结果的验收文件和构建配置已按官方启用测试的转换规则核对。

本轮[官方 Aider 源码](https://github.com/Aider-AI/aider/blob/5dc9490bb35f9729ef2c95d00a19ccd30c26339c/benchmark/benchmark.py)、[Polyglot 题库](https://github.com/Aider-AI/polyglot-benchmark/tree/7e0611e77b54e2dea774cdc0aa00cf9f7ed6144f)。

## 注意

这是单轮、单请求并发实测。依赖缓存已经预热，专家缓存随题序自然变化；未测多人服务。与公共榜单比较时，需核对编辑格式、模型、推理模式、版本、预算以及摘要调度。工具链、CPU 配额和测试超时也会影响任务结果及时间。

初次接入预检和一批采用旧计时逻辑的记录保留在 pilot-before-serial-summary，用于排查摘要跨题问题；它们不进入本轮正式统计。最终正式 225 题没有按成绩筛选或重做。API 元数据中的零价格是本地计费占位值，未测电费和硬件摊销。

## 完整失败名单

| 任务 | E2E 秒 | 测试尝试 | 截断调用 | 格式错误 | 测试超时 |
| --- | ---: | ---: | ---: | ---: | ---: |
| `java/exercises/practice/alphametics` | 91.0 | 2 | 0 | 0 | 0 |
| `javascript/exercises/practice/twelve-days` | 53.0 | 2 | 0 | 0 | 0 |
| `cpp/exercises/practice/clock` | 74.3 | 2 | 0 | 0 | 0 |
| `javascript/exercises/practice/ledger` | 70.6 | 2 | 0 | 0 | 0 |
| `javascript/exercises/practice/transpose` | 43.4 | 2 | 0 | 0 | 0 |
| `java/exercises/practice/go-counting` | 74.6 | 2 | 0 | 0 | 0 |
| `java/exercises/practice/ocr-numbers` | 67.9 | 2 | 0 | 0 | 0 |
| `java/exercises/practice/all-your-base` | 84.3 | 2 | 0 | 0 | 0 |
| `python/exercises/practice/pov` | 121.9 | 2 | 1 | 0 | 0 |
| `go/exercises/practice/dominoes` | 42.4 | 2 | 0 | 0 | 0 |
| `go/exercises/practice/bowling` | 116.7 | 2 | 1 | 0 | 0 |
| `javascript/exercises/practice/list-ops` | 54.0 | 2 | 0 | 0 | 0 |
| `cpp/exercises/practice/kindergarten-garden` | 153.0 | 2 | 0 | 0 | 0 |
| `javascript/exercises/practice/grade-school` | 31.5 | 2 | 0 | 0 | 0 |
| `rust/exercises/practice/accumulate` | 28.1 | 2 | 0 | 0 | 0 |
| `python/exercises/practice/forth` | 93.3 | 2 | 0 | 0 | 0 |
| `cpp/exercises/practice/parallel-letter-frequency` | 257.1 | 2 | 1 | 0 | 0 |
| `go/exercises/practice/book-store` | 138.3 | 2 | 1 | 0 | 0 |
| `javascript/exercises/practice/house` | 51.3 | 2 | 0 | 0 | 0 |
| `javascript/exercises/practice/two-bucket` | 51.3 | 2 | 0 | 0 | 0 |
| `javascript/exercises/practice/connect` | 58.5 | 2 | 0 | 0 | 0 |
| `go/exercises/practice/alphametics` | 64.4 | 2 | 0 | 0 | 0 |
| `java/exercises/practice/connect` | 75.2 | 2 | 0 | 0 | 0 |
| `go/exercises/practice/error-handling` | 15.8 | 2 | 0 | 0 | 0 |
| `rust/exercises/practice/scale-generator` | 218.4 | 2 | 1 | 0 | 0 |
| `go/exercises/practice/beer-song` | 37.0 | 2 | 0 | 0 | 0 |
| `rust/exercises/practice/alphametics` | 42.6 | 2 | 0 | 0 | 0 |
| `java/exercises/practice/queen-attack` | 46.6 | 2 | 0 | 0 | 0 |
| `go/exercises/practice/simple-linked-list` | 120.3 | 2 | 1 | 0 | 0 |
| `rust/exercises/practice/poker` | 59.5 | 2 | 0 | 0 | 0 |
| `java/exercises/practice/dominoes` | 69.9 | 2 | 0 | 0 | 0 |
| `python/exercises/practice/go-counting` | 43.6 | 2 | 0 | 0 | 0 |
| `java/exercises/practice/bottle-song` | 64.7 | 2 | 0 | 0 | 0 |
| `java/exercises/practice/phone-number` | 30.3 | 2 | 0 | 0 | 0 |
| `go/exercises/practice/connect` | 470.8 | 2 | 1 | 0 | 0 |
| `javascript/exercises/practice/bowling` | 109.2 | 2 | 0 | 0 | 0 |
| `java/exercises/practice/variable-length-quantity` | 94.5 | 2 | 0 | 0 | 0 |
| `go/exercises/practice/hexadecimal` | 18.2 | 2 | 0 | 0 | 0 |
| `go/exercises/practice/counter` | 13.1 | 2 | 0 | 0 | 0 |
| `java/exercises/practice/protein-translation` | 54.3 | 2 | 0 | 0 | 0 |
| `python/exercises/practice/poker` | 79.3 | 2 | 0 | 0 | 0 |
| `go/exercises/practice/food-chain` | 33.2 | 2 | 0 | 0 | 0 |
| `java/exercises/practice/hangman` | 242.3 | 2 | 1 | 0 | 0 |
| `go/exercises/practice/ledger` | 172.2 | 2 | 1 | 0 | 0 |
| `go/exercises/practice/forth` | 206.4 | 2 | 1 | 0 | 0 |
| `cpp/exercises/practice/spiral-matrix` | 16.9 | 2 | 0 | 0 | 0 |
| `go/exercises/practice/zebra-puzzle` | 131.8 | 2 | 0 | 0 | 0 |
| `javascript/exercises/practice/robot-name` | 35.6 | 2 | 0 | 0 | 0 |
| `javascript/exercises/practice/queen-attack` | 32.7 | 2 | 0 | 0 | 0 |
| `javascript/exercises/practice/forth` | 65.7 | 2 | 0 | 0 | 0 |
| `python/exercises/practice/react` | 29.7 | 2 | 0 | 0 | 0 |
| `javascript/exercises/practice/zebra-puzzle` | 102.3 | 2 | 0 | 0 | 0 |
| `java/exercises/practice/ledger` | 76.3 | 2 | 0 | 0 | 0 |
| `go/exercises/practice/octal` | 88.0 | 2 | 0 | 0 | 0 |
| `go/exercises/practice/react` | 50.5 | 2 | 0 | 0 | 0 |
| `java/exercises/practice/bowling` | 138.4 | 2 | 0 | 0 | 0 |
| `python/exercises/practice/transpose` | 145.7 | 2 | 1 | 0 | 0 |
| `java/exercises/practice/state-of-tic-tac-toe` | 63.2 | 2 | 0 | 0 | 0 |
| `rust/exercises/practice/xorcism` | 44.0 | 2 | 0 | 0 | 0 |
| `java/exercises/practice/series` | 62.0 | 2 | 0 | 0 | 0 |
| `java/exercises/practice/mazy-mice` | 162.1 | 2 | 0 | 0 | 0 |
| `javascript/exercises/practice/react` | 36.3 | 2 | 0 | 0 | 0 |
| `go/exercises/practice/say` | 31.9 | 2 | 0 | 0 | 0 |
| `cpp/exercises/practice/sublist` | 179.8 | 2 | 0 | 0 | 0 |
| `java/exercises/practice/rational-numbers` | 133.8 | 2 | 1 | 0 | 0 |
| `java/exercises/practice/zipper` | 62.5 | 2 | 0 | 0 | 0 |
| `rust/exercises/practice/acronym` | 17.9 | 2 | 0 | 0 | 0 |
| `java/exercises/practice/react` | 67.9 | 2 | 0 | 0 | 0 |
| `python/exercises/practice/scale-generator` | 190.8 | 2 | 1 | 0 | 0 |
| `rust/exercises/practice/say` | 52.2 | 2 | 0 | 0 | 0 |
| `python/exercises/practice/sgf-parsing` | 133.7 | 2 | 1 | 0 | 0 |
| `java/exercises/practice/twelve-days` | 67.3 | 2 | 0 | 0 | 0 |
| `java/exercises/practice/pov` | 77.6 | 2 | 0 | 0 | 0 |
| `javascript/exercises/practice/ocr-numbers` | 45.8 | 2 | 0 | 0 | 0 |
| `java/exercises/practice/satellite` | 113.6 | 2 | 1 | 0 | 0 |
| `cpp/exercises/practice/diamond` | 100.7 | 2 | 0 | 0 | 0 |
| `java/exercises/practice/forth` | 69.5 | 2 | 0 | 0 | 0 |
| `java/exercises/practice/rest-api` | 175.9 | 2 | 1 | 0 | 0 |
| `javascript/exercises/practice/state-of-tic-tac-toe` | 61.8 | 2 | 0 | 0 | 0 |
| `javascript/exercises/practice/complex-numbers` | 102.6 | 2 | 1 | 0 | 0 |
| `javascript/exercises/practice/food-chain` | 77.3 | 2 | 0 | 0 | 0 |
| `go/exercises/practice/robot-simulator` | 86.9 | 2 | 0 | 0 | 0 |
| `javascript/exercises/practice/resistor-color-trio` | 52.5 | 2 | 0 | 0 | 0 |
| `cpp/exercises/practice/dnd-character` | 105.9 | 2 | 0 | 1 | 0 |
| `javascript/exercises/practice/poker` | 54.9 | 2 | 0 | 0 | 0 |
| `go/exercises/practice/poker` | 60.0 | 2 | 0 | 0 | 0 |
| `go/exercises/practice/bottle-song` | 31.4 | 2 | 0 | 0 | 0 |
| `rust/exercises/practice/book-store` | 71.3 | 2 | 0 | 0 | 0 |
| `rust/exercises/practice/decimal` | 135.9 | 2 | 0 | 0 | 0 |
| `python/exercises/practice/food-chain` | 41.3 | 2 | 0 | 0 | 0 |
| `rust/exercises/practice/react` | 353.1 | 2 | 1 | 0 | 0 |
| `python/exercises/practice/bowling` | 117.5 | 2 | 1 | 0 | 0 |
| `cpp/exercises/practice/binary-search-tree` | 123.9 | 2 | 0 | 0 | 0 |
| `cpp/exercises/practice/all-your-base` | 160.4 | 2 | 0 | 0 | 0 |
| `cpp/exercises/practice/grade-school` | 106.2 | 2 | 0 | 0 | 0 |
| `go/exercises/practice/paasio` | 17.4 | 2 | 0 | 0 | 0 |
| `javascript/exercises/practice/wordy` | 38.9 | 2 | 0 | 0 | 0 |
| `go/exercises/practice/two-bucket` | 56.1 | 2 | 0 | 0 | 0 |
| `java/exercises/practice/poker` | 96.2 | 2 | 0 | 0 | 0 |
| `cpp/exercises/practice/perfect-numbers` | 168.8 | 2 | 0 | 0 | 0 |
| `cpp/exercises/practice/meetup` | 81.0 | 2 | 0 | 0 | 0 |
| `rust/exercises/practice/dot-dsl` | 34.2 | 2 | 0 | 0 | 0 |
| `go/exercises/practice/trinary` | 11.8 | 2 | 0 | 0 | 0 |
| `java/exercises/practice/sgf-parsing` | 86.4 | 2 | 0 | 0 | 0 |
| `rust/exercises/practice/forth` | 135.9 | 2 | 2 | 0 | 0 |
| `rust/exercises/practice/fizzy` | 42.4 | 2 | 0 | 0 | 0 |
| `python/exercises/practice/paasio` | 41.9 | 2 | 0 | 0 | 0 |
| `javascript/exercises/practice/scale-generator` | 173.6 | 2 | 2 | 0 | 0 |
| `rust/exercises/practice/ocr-numbers` | 42.6 | 2 | 0 | 0 | 0 |
| `javascript/exercises/practice/phone-number` | 48.4 | 2 | 0 | 0 | 0 |
| `cpp/exercises/practice/gigasecond` | 203.1 | 2 | 1 | 0 | 0 |
| `rust/exercises/practice/nucleotide-codons` | 64.0 | 2 | 0 | 0 | 0 |
| `rust/exercises/practice/macros` | 25.0 | 2 | 0 | 0 | 0 |
| `go/exercises/practice/scale-generator` | 42.2 | 2 | 0 | 0 | 0 |
