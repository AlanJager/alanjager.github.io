from pathlib import Path
import json,csv,math,statistics as st,collections,re
R=Path(__file__).resolve().parent;D=R/'remote';order=json.loads((R/'order.json').read_text())['formal'];rows=[];calls=[]
def stat(v):
 if not v:return None
 v=sorted(v);q=(len(v)-1)*.95;lo=int(q);hi=math.ceil(q)
 return {'mean':st.mean(v),'median':st.median(v),'p95':v[lo]+(v[hi]-v[lo])*(q-lo),'min':v[0],'max':v[-1],'sum':sum(v)}
for rel in order:
 p=D/'formal'/rel/'.task.json'
 if not p.exists():continue
 d=json.loads(p.read_text());o=d.get('official',{});ap=[]
 for cp in sorted(p.parent.glob('.api-*.json')):
  a=json.loads(cp.read_text());response=a.get('response',{});usage=response.get('usage') or {};choices=response.get('choices') or [];finish=choices[0].get('finish_reason') if choices else None;before=a.get('before') or {};after=a.get('after') or {}
  row={'task_id':rel,'call':cp.name,'wall_s':a['wall_s'],'prompt_tokens':usage.get('prompt_tokens',0),'completion_tokens':usage.get('completion_tokens',0),'finish_reason':finish,'error':a.get('error'),'read_bytes':after.get('io',{}).get('read_bytes',0)-before.get('io',{}).get('read_bytes',0),'major_faults':after.get('major_faults',0)-before.get('major_faults',0),'cpu_s':(after.get('cpu_ticks',0)-before.get('cpu_ticks',0))/100}
  row['context_rejected']=bool(a.get('error') and 'exceeds the context window' in a['error'])
  row['kind']='summary' if 'summarize_worker' in a.get('thread','') else 'edit_or_reflection'
  row['start_mono']=a.get('start_mono');row['end_mono']=a.get('end_mono')
  log=cp.with_suffix('.engine.log')
  timings=re.findall(r'prompt (\d+) tokens = (\d+) reused \+ (\d+) read in ([\d.]+) ms \(([\d.]+) tok/s\), (\d+) generated in ([\d.]+) ms \(([\d.]+) tok/s\)',log.read_text() if log.exists() else '')
  row['engine_requests']=len(timings);row['prefill_ms']=sum(float(t[3]) for t in timings);row['decode_ms']=sum(float(t[6]) for t in timings);row['engine_prompt_tokens']=sum(int(t[2]) for t in timings);row['engine_generated_tokens']=sum(int(t[5]) for t in timings);row['cached_tokens']=sum(int(t[1]) for t in timings)
  ap.append(row);calls.append(row)
 row={'task_id':rel,'language':rel.split('/')[0],'first_pass':d['first_pass'],'final_pass':d['final_pass'],'test_attempts':len(o.get('tests_outcomes',[])),'e2e_s':d['e2e_s'],'aider_edit_s':o.get('duration',0),'api_s':sum(a['wall_s'] for a in ap),'test_s':d['test_s'],'api_calls':len(ap),'prompt_tokens':sum(a['prompt_tokens'] for a in ap),'completion_tokens':sum(a['completion_tokens'] for a in ap),'cutoff_calls':sum(a['finish_reason']=='length' for a in ap),'api_errors':sum(bool(a['error']) for a in ap),'test_timeouts':o.get('test_timeouts',0),'format_errors':o.get('num_malformed_responses',0),'exception':bool(d.get('error')),'read_bytes':sum(a['read_bytes'] for a in ap),'cpu_s':sum(a['cpu_s'] for a in ap),'major_faults':sum(a['major_faults'] for a in ap)};row['exhausted_context_windows']=o.get('num_exhausted_context_windows',0);rows.append(row)
for rel in order:
 d=json.loads((D/'formal'/rel/'.task.json').read_text())
 assert d['timing_serial_valid'],rel
 assert d['api_calls']==len(list((D/'formal'/rel).glob('.api-*.json'))),rel
assert len(rows)==225,len(rows)
assert len({x['task_id'] for x in rows})==225
summary={'tasks':225,'first_pass':sum(x['first_pass'] for x in rows),'final_pass':sum(x['final_pass'] for x in rows),'first_percent':100*sum(x['first_pass'] for x in rows)/225,'final_percent':100*sum(x['final_pass'] for x in rows)/225,'stats':{k:stat([x[k] for x in rows]) for k in ['e2e_s','aider_edit_s','api_s','test_s','api_calls','prompt_tokens','completion_tokens','read_bytes','cpu_s','major_faults']},'finish_counts':dict(collections.Counter(a['finish_reason'] for a in calls)),'cutoff_tasks':sum(x['cutoff_calls']>0 for x in rows),'format_error_tasks':sum(x['format_errors']>0 for x in rows),'api_error_tasks':sum(x['api_errors']>0 for x in rows),'exception_tasks':sum(x['exception'] for x in rows),'test_timeout_tasks':sum(x['test_timeouts']>0 for x in rows),'by_language':{},'suite':json.loads((D/'formal/completed.json').read_text()),'engine_environment':json.loads((D/'formal-engine/environment.json').read_text()),'failed_ids':[x['task_id'] for x in rows if not x['final_pass']]}
for lang in sorted({x['language'] for x in rows}):
 group=[x for x in rows if x['language']==lang];summary['by_language'][lang]={'n':len(group),'first_pass':sum(x['first_pass'] for x in group),'final_pass':sum(x['final_pass'] for x in group),'e2e':stat([x['e2e_s'] for x in group]),'api':stat([x['api_s'] for x in group]),'test':stat([x['test_s'] for x in group])}
summary['by_call_kind']={k:{'calls':len(v),'wall_s':sum(a['wall_s'] for a in v),'prompt_tokens':sum(a['prompt_tokens'] for a in v),'completion_tokens':sum(a['completion_tokens'] for a in v)} for k in ['summary','edit_or_reflection'] for v in [[a for a in calls if a['kind']==k]]}
summary['engine_totals']={k:sum(a[k] for a in calls) for k in ['engine_requests','prefill_ms','decode_ms','engine_prompt_tokens','engine_generated_tokens','cached_tokens']}
ordered=sorted(calls,key=lambda x:x['start_mono']);assert all(a['end_mono']<=b['start_mono']+.001 for a,b in zip(ordered,ordered[1:])), 'model call overlap'
summary['request_overlap']=False
summary['context_reject_calls']=sum(a['context_rejected'] for a in calls)
summary['context_reject_ids']=sorted({a['task_id'] for a in calls if a['context_rejected']})
summary['context_reject_details']=[{'task_id':a['task_id'],'error':a['error']} for a in calls if a['context_rejected']]
summary['aider_token_exhausted_tasks']=sum(r['exhausted_context_windows']>0 for r in rows)
summary['max_api_prompt_tokens']=max(a['prompt_tokens'] for a in calls)
summary['max_api_completion_tokens']=max(a['completion_tokens'] for a in calls)
summary['cutoff_final_pass_tasks']=sum(r['cutoff_calls']>0 and r['final_pass'] for r in rows)
summary['task_other_s']=sum(x['e2e_s']-x['api_s']-x['test_s'] for x in rows)
summary['by_outcome']={}
for label,predicate in [('first_success',lambda r:r['first_pass']),('repair_success',lambda r:r['final_pass'] and not r['first_pass']),('failed',lambda r:not r['final_pass'])]:
 group=[r for r in rows if predicate(r)]
 summary['by_outcome'][label]={'n':len(group),'e2e':stat([r['e2e_s'] for r in group]),'api':stat([r['api_s'] for r in group]),'test':stat([r['test_s'] for r in group])}
for name,data in [('results',rows),('api-results',calls)]:
 (R/(name+'.json')).write_text(json.dumps(data,ensure_ascii=False,indent=2))
 with (R/(name+'.csv')).open('w') as f:
  w=csv.DictWriter(f,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
(R/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2));print(json.dumps({k:summary[k] for k in ['tasks','first_pass','final_pass','first_percent','final_percent','finish_counts','exception_tasks']},ensure_ascii=False))
