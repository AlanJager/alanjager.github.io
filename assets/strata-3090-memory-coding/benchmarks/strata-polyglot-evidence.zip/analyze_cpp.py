from pathlib import Path
import json,csv,statistics,math,hashlib
R=Path(__file__).resolve().parent;D=R/'remote'
read=lambda p:json.loads(p.read_text())
order=read(R/'cpp-control-order.json')['cpp-control'];assert len(order)==26
assert read(D/'cpp-control-exit.json')['code']==0
assert read(D/'cpp-control-completed.json')['tasks']==26
assert read(D/'cpp-control-restored.json')['health']['loaded']
manifest=read(D/'cpp-control-input-manifest.json');runtime=read(D/'cpp-control/runtime.json')
assert runtime['source_sha256']==manifest['run_suite_cpp.py'] and runtime['header_lint_language']=='cpp'
assert read(D/'cpp-lint-selftest.json')['passed']
assert read(R/'cpp-test-integrity.json')['passed']
for name in manifest:assert hashlib.sha256((D/name).read_bytes()).hexdigest()==manifest[name],name
original=read(R/'results.json');base={x['task_id']:x for x in original}
def stats(v):
 v=sorted(v);q=(len(v)-1)*.95;i=int(q);j=math.ceil(q)
 return {'sum':sum(v),'mean':statistics.mean(v),'median':statistics.median(v),'p95':v[i]+(v[j]-v[i])*(q-i),'min':v[0],'max':v[-1]}
rows=[];allcalls=[];context_rejects=[]
for rel in order:
 p=D/'cpp-control'/rel;d=read(p/'.task.json');assert d['timing_serial_valid'];calls=[read(x) for x in sorted(p.glob('.api-*.json'))];allcalls+=calls;assert len(calls)==d['api_calls']
 row={'task_id':rel,'language':'cpp','first_pass':d['first_pass'],'final_pass':d['final_pass'],'e2e_s':d['e2e_s'],'api_s':sum(a['wall_s'] for a in calls),'test_s':d['test_s'],'api_calls':len(calls),'exception':bool(d.get('error')),'cutoff_calls':sum(any(c.get('finish_reason')=='length' for c in a.get('response',{}).get('choices',[])) for a in calls),'api_errors':sum(bool(a.get('error')) for a in calls)}
 row['read_bytes']=sum(a.get('after',{}).get('io',{}).get('read_bytes',0)-a.get('before',{}).get('io',{}).get('read_bytes',0) for a in calls)
 row['major_faults']=sum(a.get('after',{}).get('major_faults',0)-a.get('before',{}).get('major_faults',0) for a in calls)
 row['prompt_tokens']=sum((a.get('response',{}).get('usage') or {}).get('prompt_tokens',0) for a in calls)
 row['completion_tokens']=sum((a.get('response',{}).get('usage') or {}).get('completion_tokens',0) for a in calls)
 context_rejects.extend({'task_id':rel,'error':a['error']} for a in calls if a.get('error') and 'exceeds the context window' in a['error'])
 rows.append(row)
allcalls.sort(key=lambda a:a['start_mono']);assert all(a['end_mono']<=b['start_mono']+.001 for a,b in zip(allcalls,allcalls[1:]))
env0=read(D/'formal-engine/environment.json');env1=read(D/'cpp-control-engine/environment.json')
for key in ['engine_sha256','expert_profile_sha256']:assert env0[key]==env1[key],key
c0=read(D/'formal-engine/config.json');c1=read(D/'cpp-control-engine/config.json')
for k in c0:
 if k!='log':assert c0[k]==c1[k],k
old=[base[x] for x in order];new={x['task_id']:x for x in rows};combined=[new.get(x['task_id'],x) for x in original]
def group(xs):return {'n':len(xs),'first_pass':sum(x['first_pass'] for x in xs),'final_pass':sum(x['final_pass'] for x in xs),'first_percent':100*sum(x['first_pass'] for x in xs)/len(xs),'final_percent':100*sum(x['final_pass'] for x in xs)/len(xs),'e2e':stats([x['e2e_s'] for x in xs]),'api':stats([x['api_s'] for x in xs]),'test':stats([x['test_s'] for x in xs]),'api_calls':sum(x['api_calls'] for x in xs)}
s={'before_cpp':group(old),'after_cpp':group(rows),'corrected_functional_pool':group(combined),'corrected_by_language':{lang:group([x for x in combined if x['language']==lang]) for lang in sorted({x['language'] for x in combined})},'control_suite':read(D/'cpp-control/completed.json'),'corrected_pool_method':'199 non-C++ cases from original run plus all 26 C++ cases repeated with .h parsed as C++; this is a pooled functional result, not a new continuous 225-task run.','timing_caveat':'Original C++ tasks were interleaved with other languages; corrected run restarts the engine and runs only C++ in preserved relative order. Expert cache histories differ. Timing comparison is observational.','fixed_pass_ids':[x['task_id'] for x in rows if x['final_pass'] and not base[x['task_id']]['final_pass']],'lost_pass_ids':[x['task_id'] for x in rows if not x['final_pass'] and base[x['task_id']]['final_pass']],'after_exception_tasks':sum(x['exception'] for x in rows),'after_cutoff_tasks':sum(x['cutoff_calls']>0 for x in rows),'after_api_error_tasks':sum(x['api_errors']>0 for x in rows),'engine_environment':env1,'validated':True}
s['corrected_resource_totals']={k:sum(x[k] for x in combined) for k in ['read_bytes','major_faults','prompt_tokens','completion_tokens','api_errors','cutoff_calls']}
s['control_context_rejects']=context_rejects
(R/'cpp-control-summary.json').write_text(json.dumps(s,ensure_ascii=False,indent=2));(R/'cpp-control-results.json').write_text(json.dumps(rows,indent=2))
with (R/'cpp-control-results.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
merged=[dict({k:x[k] for k in rows[0]},run_phase='cpp-control' if x['language']=='cpp' else 'formal') for x in combined]
(R/'corrected-results.json').write_text(json.dumps(merged,indent=2))
with (R/'corrected-results.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(merged[0]));w.writeheader();w.writerows(merged)
print(json.dumps({k:s[k] for k in ['before_cpp','after_cpp','corrected_functional_pool','fixed_pass_ids','lost_pass_ids']},ensure_ascii=False))
