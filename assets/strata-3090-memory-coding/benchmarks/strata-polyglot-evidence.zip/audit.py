from pathlib import Path
import json,subprocess,hashlib,sys,importlib.metadata,tarfile
R=Path(__file__).resolve().parent
commands={'python':['python3','--version'],'node':[str(R/'tools/node/bin/node'),'--version'],'go':[str(R/'tools/go/bin/go'),'version'],'rust':[str(R/'tools/rust/bin/rustc'),'--version'],'java':[str(R/'tools/jdk/bin/java'),'-version'],'javac':[str(R/'tools/jdk/bin/javac'),'-version'],'gcc':['gcc','--version'],'cmake':['cmake','--version'],'docker':['docker','version','--format','{{.Server.Version}}']}
versions={k:subprocess.check_output(c,stderr=subprocess.STDOUT,text=True).strip() for k,c in commands.items()}
versions['python_distributions']=sorted((d.metadata['Name'],d.version) for d in importlib.metadata.distributions(path=[str(R/'vendor')]))
versions['image']=subprocess.check_output(['docker','image','inspect','strata-polyglot-sandbox:20261015','--format','{{.Id}}'],text=True).strip()
versions['npm_lock_sha256']=hashlib.sha256((R/'npm-install/package-lock.json').read_bytes()).hexdigest()
(R/'environment-tools.json').write_text(json.dumps(versions,indent=2))
checks={};changed=[]
for archive,folder in [('aider.tar.gz','aider-src'),('dataset.tar.gz','dataset')]:
 with tarfile.open(R/archive) as tf:
  for m in tf:
   if not m.isfile():continue
   rel=Path(*Path(m.name).parts[1:]);p=R/folder/rel
   digest=hashlib.sha256(tf.extractfile(m).read()).hexdigest()
   if not p.exists() or hashlib.sha256(p.read_bytes()).hexdigest()!=digest:changed.append(folder+'/'+str(rel))
 checks[archive]=hashlib.sha256((R/archive).read_bytes()).hexdigest()
# setuptools can produce an untracked version file; all tracked source must stay identical.
(R/'source-audit.json').write_text(json.dumps({'archives':checks,'changed_tracked_files':changed},indent=2));assert not changed,changed
inputs={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in R.glob('*.py')}
for name in ['PLAN.md','order.json','aider.tar.gz','dataset.tar.gz']:inputs[name]=hashlib.sha256((R/name).read_bytes()).hexdigest()
(R/'input-manifest.json').write_text(json.dumps(inputs,indent=2))
print('SOURCE AUDIT PASSED',len(inputs))
