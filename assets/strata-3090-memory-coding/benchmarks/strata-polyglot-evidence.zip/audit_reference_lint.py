from pathlib import Path
import os,sys,json
R=Path(__file__).resolve().parent
os.environ['PYTHONPATH']=str(R/'vendor')
sys.path[:0]=[str(R/'aider-src'),str(R/'vendor')]
from aider import linter
original=linter.filename_to_lang
linter.filename_to_lang=lambda p:'cpp' if str(p).endswith('.h') else original(p)
rows=[]
for rel in json.loads((R/'order.json').read_text())['formal']:
 p=R/'reference'/rel
 assert json.loads((p/'.reference.json').read_text())['passed']
 conf=json.loads((p/'.meta/config.json').read_text())
 lint=linter.Linter(root=str(p))
 for f in conf['files']['solution']:
  if f=='Cargo.toml':continue
  result=lint.lint(str(p/f))
  rows.append({'task':rel,'file':f,'language':linter.filename_to_lang(f),'lint_error':result})
out={'files':len(rows),'tasks':225,'flagged_files':sum(bool(x['lint_error']) for x in rows),'header_mapping':'cpp','model_calls':0,'rows':rows}
(R/'reference-lint-all.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
print(json.dumps({k:v for k,v in out.items() if k!='rows'}))
for row in rows:
 if row['lint_error']:print(json.dumps(row,ensure_ascii=False))
