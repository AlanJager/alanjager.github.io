from pathlib import Path
import json,re,sys,hashlib
R=Path(__file__).resolve().parent;rows=[];changes=[]
phase='cpp-control' if '--cpp-control' in sys.argv else 'formal'
order=json.loads((R/('cpp-control-order.json' if phase=='cpp-control' else 'order.json')).read_text())[phase]
for rel in order:
 src=R/'dataset'/rel;dst=R/'remote'/phase/rel
 if not (dst/'.task.json').exists():continue
 meta=json.loads((src/'.meta/config.json').read_text());tests=meta['files']['test'];executed=bool(list(dst.glob('.test-*.json')))
 protected=set(tests)|{'.meta/config.json'}
 protected.update(n for n in ['CMakeLists.txt','Cargo.toml','package.json','build.gradle'] if (src/n).exists())
 protected.update(str(p.relative_to(src)) for p in (src/'test').rglob('*') if p.is_file())
 for name in sorted(protected):
  a=src/name;b=dst/name
  if not a.is_file():continue
  expected=a.read_bytes()
  if executed and name in tests and name.endswith('.java'):expected=re.sub(r'@Disabled\([^)]*\)\s*\n','',expected.decode()).encode()
  if executed and rel.startswith('javascript/') and name.endswith('.spec.js'):expected=re.sub(rb'\bxtest\(',b'test(',expected)
  ok=b.is_file() and b.read_bytes()==expected
  row={'task_id':rel,'file':name,'matches_expected':ok,'expected_sha256':hashlib.sha256(expected).hexdigest(),'actual_sha256':hashlib.sha256(b.read_bytes()).hexdigest() if b.is_file() else None}
  rows.append(row)
  if not ok:changes.append(row)
tasks=len({r['task_id'] for r in rows})
if '--partial' not in sys.argv:assert tasks==len(order),tasks
result={'passed':not changes,'tasks':tasks,'files':len(rows),'unexpected_changes':changes,'checks':rows,'normalizations':['Java @Disabled removal by official benchmark','JavaScript xtest -> test by official npm-test.sh']}
name=('cpp-' if phase=='cpp-control' else '')+('test-integrity-partial.json' if '--partial' in sys.argv else 'test-integrity.json')
(R/name).write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps({k:result[k] for k in ['passed','tasks','files','unexpected_changes']},ensure_ascii=False))
assert not changes
