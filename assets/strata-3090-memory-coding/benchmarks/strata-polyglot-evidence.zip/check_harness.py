from pathlib import Path
import json,shutil,os,hashlib
import run_suite as runner
from litellm import ModelResponse
R=Path(__file__).resolve().parent;rel='python/exercises/practice/affine-cipher';dst=R/'harness-selftest-v3'/rel
shutil.copytree(R/'dataset'/rel,dst,dirs_exist_ok=True);runner.CURRENT=dst
for p in [dst,*dst.rglob('*')]:
 if p.is_dir():p.chmod(0o777)
 else:p.chmod(0o666)
solution=(R/'dataset'/rel/'.meta/example.py').read_text()
def fake(self,messages,functions,stream,temperature=None):
 return hashlib.sha1(b'harness-selftest-no-model-call'),ModelResponse(choices=[{'index':0,'message':{'role':'assistant','content':'affine_cipher.py\n```python\n'+solution+'\n```'},'finish_reason':'stop'}],model=runner.modelname,usage={'prompt_tokens':1,'completion_tokens':1,'total_tokens':2})
runner.models.Model.send_completion=fake
result=runner.b.run_test_real(R/'dataset',dst,runner.modelname,'whole',2,False,False,False,'5dc9490',None,None,None)
assert result['tests_outcomes']==[True],result
(R/'harness-selftest.json').write_text(json.dumps({'status':'pass','uses_model':False,'reference_text_via_mock':True,'result':result},indent=2));print('HARNESS SELFTEST PASSED')
