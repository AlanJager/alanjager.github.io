from types import SimpleNamespace,MethodType
from pathlib import Path
import time,json
import run_suite as r

def summarize(messages):
 time.sleep(.05);return [{'role':'assistant','content':'summary'}]
p=SimpleNamespace(summarizer=SimpleNamespace(too_big=lambda messages:True,summarize=summarize),done_messages=[{'role':'user','content':'original'}],summarizer_thread=None,verbose=False)
p.summarize_end=MethodType(r.Coder.summarize_end,p);p.summarize_worker=MethodType(r.Coder.summarize_worker,p)
t=time.perf_counter();r.serialized_summary(p);elapsed=time.perf_counter()-t
assert p.summarizer_thread is None and p.done_messages==[{'role':'assistant','content':'summary'}] and elapsed>=.05
Path('summary-selftest.json').write_text(json.dumps({'passed':True,'model_calls':0,'elapsed_s':elapsed,'method':r.Coder.summarize_start.__name__}));print('SERIAL SUMMARY SELFTEST PASSED')
