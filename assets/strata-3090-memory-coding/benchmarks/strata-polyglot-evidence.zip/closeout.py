from pathlib import Path
import json,urllib.request,datetime
R=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text())
assert read(R/'exit.json')['code']==0
assert read(R/'cpp-control-exit.json')['code']==0
assert read(R/'cpp-control-restored.json')['health']['loaded']
smoke=read(R/'cpp-control-restoration-smoke.json')
assert smoke['sse_done'] and smoke['finish_reason']=='stop' and not smoke.get('error')
def get(endpoint):
 with urllib.request.urlopen('http://127.0.0.1:8080'+endpoint,timeout=5) as f:return json.load(f)
health=get('/health');slots=get('/slots')
assert health['loaded'] and not any(s.get('is_processing') for s in slots)
out={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'health':health,'slots_idle':True,'restoration_smoke_done':smoke['sse_done'],'restoration_smoke_finish':smoke['finish_reason'],'original_exit':0,'cpp_control_exit':0}
(R/'closeout.json').write_text(json.dumps(out,indent=2));print(json.dumps(out))
