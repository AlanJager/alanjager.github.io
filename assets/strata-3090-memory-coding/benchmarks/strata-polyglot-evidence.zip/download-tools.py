from pathlib import Path
import subprocess,concurrent.futures,json,hashlib
R=Path(__file__).resolve().parent/'toolchains';R.mkdir(exist_ok=True)
urls={'node.tar.xz':'https://nodejs.org/dist/v20.19.0/node-v20.19.0-linux-x64.tar.xz','go.tar.gz':'https://go.dev/dl/go1.21.5.linux-amd64.tar.gz','rust.tar.xz':'https://static.rust-lang.org/dist/rust-1.90.0-x86_64-unknown-linux-gnu.tar.xz','jdk.tar.gz':'https://api.adoptium.net/v3/binary/latest/21/ga/linux/x64/jdk/hotspot/normal/eclipse','gradle.zip':'https://services.gradle.org/distributions/gradle-8.7-bin.zip'}
def get(item):
 n,u=item;p=R/n
 s=subprocess.run(['curl','--retry','3','--retry-all-errors','--connect-timeout','15','--max-time','600','-fL',u,'-o',str(p)],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 (R/(n+'.download.log')).write_bytes(s.stderr)
 print(n,s.returncode,p.stat().st_size if p.exists() else 0,flush=True)
 return n,{'url':u,'exit':s.returncode,'sha256':hashlib.sha256(p.read_bytes()).hexdigest() if s.returncode==0 else None}
with concurrent.futures.ThreadPoolExecutor(max_workers=5) as pool: data=dict(pool.map(get,urls.items()))
(R/'manifest.json').write_text(json.dumps(data,indent=2))
