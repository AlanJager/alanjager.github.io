from pathlib import Path
import json, csv

R=Path(__file__).resolve().parent
read=lambda name:json.loads((R/name).read_text())
s=read('summary.json');c=read('cpp-control-summary.json');p=c['corrected_functional_pool']
assert read('validation.json')['passed'] and c['validated']
assert read('closeout.json')['health']['loaded']
names={'cpp':'C++','go':'Go','java':'Java','javascript':'JavaScript','python':'Python','rust':'Rust'}
def score(g,key):return f"{g[key]}/{g['n']}（{100*g[key]/g['n']:.2f}%）"
def mins(sec):return f'{sec/60:.2f} 分钟'
languages='\n'.join(f"| {names[k]} | {g['n']} | {g['first_pass']} | {g['final_pass']}（{g['final_percent']:.1f}%） | {g['e2e']['median']:.1f} | {g['e2e']['p95']:.1f} |" for k,g in c['corrected_by_language'].items())
before=c['before_cpp'];after=c['after_cpp']
control='\n'.join(f"| {label} | {score(g,'first_pass')} | {score(g,'final_pass')} | {g['api_calls']} | {g['e2e']['median']:.1f} 秒 | {mins(g['e2e']['sum'])} |" for label,g in [('默认头文件解析',before),('按 C++ 解析头文件',after)])
fixed='、'.join('`'+x.rsplit('/',1)[-1]+'`' for x in c['fixed_pass_ids']) or '无'
lost='、'.join('`'+x.rsplit('/',1)[-1]+'`' for x in c['lost_pass_ids']) or '无'
text=f'''# 3090 跑编码任务：Aider Polyglot 的完成率与等待时间

RTX 3090 / 64GiB 上，Strata 运行 **Qwen3.8-Flash-Next-GSQ-RCO IQ2_XS**。在 Aider Polyglot 225 道任务中，修正 C++ 头文件检查后汇总的首次测试通过为 **{score(p,'first_pass')}**，允许一次测试反馈后最终通过 **{score(p,'final_pass')}**。单题完整等待时间的中位数为 **{p['e2e']['median']:.1f} 秒**，P95 为 **{p['e2e']['p95']:.1f} 秒**，包含代码生成、内部纠错、摘要、编译与测试。

这份成绩由初轮的 **199 道非 C++ 任务 + 修正检查器后重跑的全部 26 道 C++ 任务**组成。初轮完整 225 题耗时 **{mins(s['suite']['suite_wall_s'])}**；C++ 复测耗时 **{mins(c['control_suite']['suite_wall_s'])}**。两轮的原始记录、复测前后的得失分均保留。

## 怎样完成一道题

Aider 读取题目说明和可编辑源文件，模型输出修改后的完整文件，然后运行该题验收测试。首次测试失败时，把报错交给模型修复一次，再运行测试。默认 lint 与格式修正仍然启用，因此一次测试尝试可能包含多次模型调用。通过要求是该题全部验收测试通过。

本轮固定 whole 编辑格式、32K 总上下文、8192 输出上限、temperature=0，使用同一本地模型生成代码与压缩历史。摘要串行等待，所有模型请求串行执行；验收程序在无网络的容器中运行，配额为 4 CPU / 6GiB。官方参考答案已全部通过编译与测试。

## 六种语言的结果

| 语言 | 题数 | 首次通过 | 最终通过 | E2E 中位数 / 秒 | P95 / 秒 |
| --- | ---: | ---: | ---: | ---: | ---: |
{languages}

一次测试反馈额外挽回 **{p['final_pass']-p['first_pass']} 题**，最终 **{225-p['final_pass']} 题**未通过。失败题和发生截断的题目均计入分母与耗时。

![C++ 检查修正后的分语言结果](corrected-results.png)

## C++ 复测解决了什么

Aider 的默认语言映射把 `.h` 识别为 C。本题库的 26 道 C++ 题使用 C++ 头文件；用官方参考答案检查，26 份头文件均能通过真实编译与测试，却全部被 C 语法检查报错。改用 C++ 语法后，26 份参考头文件全部通过 lint，故意构造的错误 C++ 仍会被检出。

复测仅把 `.h` 的 lint 语言映射改为 C++，保留语法检查、测试、采样参数和模型配置。全部 26 题按原相对顺序重跑。

| 检查方式 | 首次通过 | 最终通过 | 模型调用数 | E2E 中位数 | 26 题 E2E 合计 |
| --- | ---: | ---: | ---: | ---: | ---: |
{control}

复测新增通过：{fixed}。复测失去通过：{lost}。最终汇总采用全部复测结果，包括失分题。

专项复测中，{len(c['control_context_rejects'])} 次调用因输入加输出预留超过 32K 被拒绝，记录在专项汇总中；任务级异常为 {c['after_exception_tasks']}。这些任务同样保留在分数和时间统计中。

复测重新启动引擎并连续运行 C++；初轮 C++ 穿插在其他语言中，专家缓存访问历史不同。因此时间变化同时受工作流和缓存历史影响。复现另一套配置时，使用已修正的完整 225 题脚本，从头按相同题序运行。

对全部参考实现的 254 份可编辑源文件进行 lint 审计，头文件映射修正后仍有两份触发提示：C++ parallel-letter-frequency 的预处理宏和 Rust react 的生命周期写法。两份参考实现均通过真实编译与测试。此轮保留其他默认 lint 行为，审计结果见 [完整参考 lint 记录](remote/reference-lint-all.json)。

检查证据见 [参考头文件审计](remote/lint-audit.json)、[检查器自测](remote/cpp-lint-selftest.json)、[C++ 对照结果](cpp-control-results.csv)。实现依据是固定版本的 [Aider linter](https://github.com/Aider-AI/aider/blob/5dc9490bb35f9729ef2c95d00a19ccd30c26339c/aider/linter.py)。

## 完成时间怎样比较

| 指标 | 实测 | 范围 |
| --- | ---: | --- |
| 初轮完整 225 题墙钟 | {mins(s['suite']['suite_wall_s'])} | 包含默认头文件检查问题 |
| C++ 26 题复测墙钟 | {mins(c['control_suite']['suite_wall_s'])} | 修正后独立运行 |
| 修正后 225 题任务 E2E 合计 | {mins(p['e2e']['sum'])} | 199 + 26 的逐题累计 |
| 修正后单题 E2E 中位数 / P95 | {p['e2e']['median']:.1f} / {p['e2e']['p95']:.1f} 秒 | 包含成功与失败题 |
| 修正后模型调用累计 | {mins(p['api']['sum'])} | 代码、纠错与摘要 |
| 修正后编译测试累计 | {mins(p['test']['sum'])} | 容器启动、编译与运行 |

199 + 26 的时间是两轮任务数据汇总；完整连续 225 题的墙钟仍以初轮记录为准。Aider 使用非流式请求，本轮未采集客户端 TTFT。公开榜单的编辑时间通常排除编译测试，比较前需对齐计时范围。

修正后的逐题汇总中，模型 API 调用占任务 E2E 的 **{100*p['api']['sum']/p['e2e']['sum']:.1f}%**，编译测试占 **{100*p['test']['sum']/p['e2e']['sum']:.1f}%**。初轮单独计量的对话摘要用了 **{mins(s['by_call_kind']['summary']['wall_s'])}**；历史摘要策略也是整个编码流程的性能因素。

199 + 26 道任务的模型请求区间累计读盘 **{c['corrected_resource_totals']['read_bytes']/1024:.1f} KiB**，累计 **{c['corrected_resource_totals']['major_faults']} 次 major fault**。这是引擎进程计数差值，覆盖生成与摘要请求，不包含模型加载和编译器的文件访问。本轮权重读取已经基本由内存承接。

初轮完整结果与时间拆解见 [原始评测报告](REPORT.md)。[逐题汇总 CSV](corrected-results.csv)保留每题来源轮次，便于与下一台机器逐题对照。

## 用在个人编码场景时看什么

本轮覆盖多语言小型文件编辑和一次报错修复。个人使用时，可以把“最终通过率、首次通过率、E2E 中位数与 P95”放在一起看：完成率决定多少结果能直接通过验收；首次与最终的差距体现测试反馈的作用；P95 反映少数困难任务需要等多久。

实际例子中，Python REST API 题根据测试报错补上 JSON 字符串与对象的转换后通过；JavaScript REST API 题首次通过。Java 有理数任务出现长段重复输出并耗尽输出预算；Go connect 多轮处理后仍未通过。完整输出和测试反馈见 [失败与修复记录](FAILURES.md)。

32K 上下文在预留 8192 输出后，可容纳的输入上限为 24576 token。初轮有 **{s['context_reject_calls']} 次调用、{len(s['context_reject_ids'])} 道题**收到明确的上下文超限拒绝，主要与长错误反馈或历史有关；相关失败保留在成绩中。工程使用还需要限制错误日志长度、管理历史，并以项目测试验收修改。

JavaScript scale-generator 两次调用都生成满 8192 token，任务等待 173.56 秒，最终未通过。第二次调用的 decode 约 107.3 token/s，请求期没有读盘；长段重复解释仍会占用生成预算与等待时间。衡量个人编码体验时，将通过率与任务 E2E 同时记录更有用。

此前 HumanEval+ 为 156/164（95.12%），对应 Python 函数生成。本轮加入文件编辑、工具链和反馈流程。跨文件仓库检索、依赖升级和持续多轮开发，需要进一步用自己的项目验证。

## 复现与对比

引擎固定为 Strata 0.1.43 / `7695859aa13afb248bdb4d36f9b2e95707db079d`：PLE RAM、pcie_frac=1、prefill=2048 / CPU share=0、尾部跳过=0、7 workers、18GiB 专家缓存、32K/int8 KV、MTP=4；prompt 与 conversation 缓存关闭。硬件为 RTX 3090 24GiB、Xeon Gold 5318Y 16 vCPU、系统可见约 63.3GiB 内存。

[复测协议](REPLAY.md)记录题库与 Aider 的固定提交、题序、预算、容器工具链和完整脚本。对比其他显卡时固定这些条件；对比公共 API 时另记录模型版本、推理模式、网络延迟和实际费用。当前没有调用付费公共服务。[历史榜单参考](PUBLIC-REFERENCES.md)单独保留，编辑格式、版本与计时口径需逐项核对。

[下载复现与证据包](strata-polyglot-evidence.zip)。日常模型服务已恢复并完成健康检查。

## 注意

这是单请求、单轮评测加一次 C++ 检查器修正复测。依赖缓存已预热，专家缓存随题序变化。CPU 配额、工具链、输出预算、摘要策略、编辑格式都会影响成绩；结论适用于本次模型、量化和工作流组合。硬件电费与摊销未测，API 元数据中的零价格为本地占位值。
'''
(R/'FINAL-REPORT.md').write_text(text)
with (R/'comparison.csv').open() as f:
 reader=csv.DictReader(f);fields=reader.fieldnames;comparisons=list(reader)
comparisons=[r for r in comparisons if r['configuration']!='RTX3090-corrected-functional-pool']
comparisons[0]['notes']+='; original full run includes C++ .h lint defect'
comparisons.insert(1,dict(configuration='RTX3090-corrected-functional-pool',model='Qwen3.8-Flash-Next-GSQ-RCO IQ2_XS',benchmark='Aider Polyglot 7e0611e / Aider 5dc9490',edit_format='whole',summary_schedule='serial',tasks=225,first_pass=p['first_pass'],final_pass=p['final_pass'],first_percent=p['first_percent'],final_percent=p['final_percent'],suite_s='',task_median_s=p['e2e']['median'],task_p95_s=p['e2e']['p95'],api_total_s=p['api']['sum'],tests_total_s=p['test']['sum'],actual_cost='未测',notes='199 original non-C++ + all 26 corrected C++; pooled functional score and task times; no continuous suite time'))
with (R/'comparison.csv').open('w') as f:
 writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader();writer.writerows(comparisons)
print('FINAL-REPORT.md written')
