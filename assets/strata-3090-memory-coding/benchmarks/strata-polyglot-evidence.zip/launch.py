from pathlib import Path
import json,subprocess,time,sys
R=Path(__file__).resolve().parent;last=None
for _ in range(240):
 xs=[json.loads(p.read_text()) for p in (R/'reference').glob('*/exercises/practice/*/.reference.json')]
 state=(len(xs),sum(x['passed'] for x in xs))
 if state!=last:print('REFERENCE',state,flush=True);last=state
 if state==(225,225):
  (R/'reference-all.json').write_text(json.dumps(sorted(xs,key=lambda x:x['id']),indent=2))
  subprocess.run([sys.executable,str(R/'audit.py')],cwd=R,check=True)
  with (R/'run.log').open('w') as f:q=subprocess.run([sys.executable,str(R/'run_experiment.py')],cwd=R,stdout=f,stderr=subprocess.STDOUT)
  (R/'exit.json').write_text(json.dumps({'code':q.returncode,'time':time.time()}));print('EXPERIMENT_EXIT',q.returncode,flush=True);sys.exit(q.returncode)
 time.sleep(5)
raise RuntimeError('Reference selftest did not reach 225/225 within 20 minutes; model benchmark not launched')
