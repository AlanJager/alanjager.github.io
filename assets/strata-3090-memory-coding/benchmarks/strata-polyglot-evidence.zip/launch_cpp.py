from pathlib import Path
import subprocess,json,hashlib,sys,time
R=Path(__file__).resolve().parent
assert json.loads((R/'exit.json').read_text())['code']==0
baseline=json.loads((R/'input-manifest.json').read_text())
for name in ['run_suite.py','test_runner.py','sandbox.py','harness.py','support.py']:
 assert hashlib.sha256((R/name).read_bytes()).hexdigest()==baseline[name],name
names=['run_suite_cpp.py','run_experiment_cpp.py','cpp-control-order.json','test_runner.py','sandbox.py','harness.py','support.py']
(R/'cpp-control-input-manifest.json').write_text(json.dumps({n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in names},indent=2))
with (R/'cpp-control-run.log').open('w') as f:
 q=subprocess.run([sys.executable,str(R/'run_experiment_cpp.py')],cwd=R,stdout=f,stderr=subprocess.STDOUT)
(R/'cpp-control-exit.json').write_text(json.dumps({'code':q.returncode,'time':time.time()}));print('CPP_CONTROL_EXIT',q.returncode,flush=True);sys.exit(q.returncode)
