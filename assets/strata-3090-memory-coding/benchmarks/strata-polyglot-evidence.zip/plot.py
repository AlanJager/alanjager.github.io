from pathlib import Path
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
R=Path(__file__).resolve().parent
s=json.loads((R/'summary.json').read_text());rows=json.loads((R/'results.json').read_text())
font=next(Path('/System/Library/AssetsV2/com_apple_MobileAsset_Font7').glob('*/AssetData/PingFang.ttc'))
font_manager.fontManager.addfont(str(font))
plt.rcParams.update({'font.family':font_manager.FontProperties(fname=str(font)).get_name(),'font.size':11,'axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'#fcfbf8','axes.facecolor':'#fcfbf8','savefig.facecolor':'#fcfbf8','axes.unicode_minus':False})
langs=list(s['by_language']);names={'cpp':'C++','go':'Go','java':'Java','javascript':'JavaScript','python':'Python','rust':'Rust'}
fig,axs=plt.subplots(1,2,figsize=(13,4.8),layout='constrained',gridspec_kw={'width_ratios':[1.3,1]})
ax=axs[0];xs=list(range(len(langs)))
for offset,key,color,label in [(-.19,'first_pass','#82b1ad','首次测试通过'),(.19,'final_pass','#126e65','一次反馈后最终通过')]:
 vals=[100*s['by_language'][k][key]/s['by_language'][k]['n'] for k in langs]
 b=ax.bar([x+offset for x in xs],vals,width=.36,color=color,label=label)
 ax.bar_label(b,labels=[f"{s['by_language'][k][key]}/{s['by_language'][k]['n']}" for k in langs],fontsize=9,padding=3)
ax.set_xticks(xs,[names[k] for k in langs]);ax.set_ylim(0,115);ax.set_yticks([0,20,40,60,80,100]);ax.set_ylabel('完整通过题目 / %');ax.legend(frameon=False,fontsize=9);ax.grid(axis='y',alpha=.15);ax.set_axisbelow(True)
ax=axs[1]
parts=[s['by_call_kind']['edit_or_reflection']['wall_s'],s['by_call_kind']['summary']['wall_s'],s['stats']['test_s']['sum'],s['task_other_s']]
left=0
for value,color,label in zip(parts,['#126e65','#82b1ad','#c59168','#d9d4ca'],['代码与格式修正','对话摘要','编译与测试','客户端其他']):
 ax.barh(['225 题'],[value/60],left=left,color=color,label=f'{label} {value/60:.1f} 分')
 left+=value/60
ax.set_xlabel('累计任务耗时 / 分钟');ax.set_ylim(-1,1);ax.legend(frameon=False,loc='upper left',fontsize=10);ax.grid(axis='x',alpha=.15);ax.set_axisbelow(True)
ax.set_title(f"正式全套墙钟：{s['suite']['suite_wall_s']/60:.1f} 分钟",fontsize=12)
fig.suptitle(f"初轮原始结果 · 首次 {s['first_pass']}/225，最终 {s['final_pass']}/225",x=.02,ha='left',fontsize=17,fontweight='bold')
fig.supxlabel('3090 / 64GiB · Qwen IQ2_XS · whole · 一次测试反馈 · 含默认 C++ 头文件 lint 误报；修正复测另列',fontsize=9)
fig.savefig(R/'benchmark-results.png',dpi=180,bbox_inches='tight');fig.savefig(R/'benchmark-results.svg',bbox_inches='tight')
plt.close(fig)
fig,ax=plt.subplots(figsize=(12,4.6),layout='constrained')
for passed,color,label in [(True,'#126e65','最终通过'),(False,'#b96742','最终未通过')]:
 rr=[(i+1,r) for i,r in enumerate(rows) if r['final_pass']==passed]
 ax.scatter([i for i,r in rr],[r['e2e_s'] for i,r in rr],color=color,label=label,s=24,alpha=.8)
ax.axhline(s['stats']['e2e_s']['p95'],color='#737d79',ls='--',lw=1,label=f"P95 {s['stats']['e2e_s']['p95']:.1f} 秒")
ax.set_xlabel('固定题序 / 1–225');ax.set_ylabel('完整任务 E2E / 秒');ax.set_ylim(bottom=0);ax.grid(axis='y',alpha=.15);ax.legend(frameon=False)
ax.set_title(f"初轮单题等待：中位数 {s['stats']['e2e_s']['median']:.1f} 秒 · P95 {s['stats']['e2e_s']['p95']:.1f} 秒",loc='left',fontsize=16,fontweight='bold')
fig.supxlabel('包括生成、摘要、修改应用、编译测试与一次失败反馈；失败题也纳入耗时分布。',fontsize=10)
fig.savefig(R/'task-latency.png',dpi=180,bbox_inches='tight');fig.savefig(R/'task-latency.svg',bbox_inches='tight')
