from pathlib import Path
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties, fontManager
R=Path(__file__).resolve().parent
c=json.loads((R/'cpp-control-summary.json').read_text())
font=next(Path('/System/Library/AssetsV2/com_apple_MobileAsset_Font7').glob('*/AssetData/PingFang.ttc'))
fontManager.addfont(str(font))
fp=FontProperties(fname=str(font));plt.rcParams.update({'font.family':fp.get_name(),'axes.spines.top':False,'axes.spines.right':False,'axes.titleweight':'bold','figure.facecolor':'#fcfbf8','axes.facecolor':'#fcfbf8'})
fig,axs=plt.subplots(1,2,figsize=(13,5.3),gridspec_kw={'width_ratios':[1.65,1]})
labels={'cpp':'C++','go':'Go','java':'Java','javascript':'JavaScript','python':'Python','rust':'Rust'}
gs=list(c['corrected_by_language'].items());x=list(range(len(gs)));w=.36
axs[0].bar([i-w/2 for i in x],[g['first_percent'] for _,g in gs],w,label='首次测试通过',color='#9bc0c3')
bars=axs[0].bar([i+w/2 for i in x],[g['final_percent'] for _,g in gs],w,label='一次反馈后通过',color='#1c6f82')
for bar,(_,g) in zip(bars,gs):axs[0].text(bar.get_x()+bar.get_width()/2,bar.get_height()+1.5,f"{g['final_pass']}/{g['n']}",ha='center',fontsize=10)
axs[0].set(xticks=x,xticklabels=[labels[k] for k,_ in gs],ylim=(0,105),ylabel='通过率 / %',title='修正后的 225 题功能结果');axs[0].legend(frameon=False,loc='upper left')
b=c['before_cpp'];a=c['after_cpp'];bars=axs[1].bar(['默认解析','C++ 解析'],[b['final_percent'],a['final_percent']],color=['#abb8bb','#1c6f82'],width=.55)
for bar,g in zip(bars,[b,a]):axs[1].text(bar.get_x()+bar.get_width()/2,bar.get_height()+2,f"{g['final_pass']}/26",ha='center')
axs[1].set(ylim=(0,105),ylabel='最终通过率 / %',title='26 道 C++ 题全部复测')
fig.suptitle('RTX 3090 · 64GiB · Strata · Qwen IQ2_XS',fontsize=17,x=.07,ha='left')
fig.text(.07,.025,'225 题 = 初轮 199 道非 C++ + 修正后全部 26 道 C++；whole / 输出 8192 / 一次测试反馈',fontsize=10,color='#63717a')
fig.tight_layout(rect=(0,.06,1,.94));fig.savefig(R/'corrected-results.png',dpi=170);fig.savefig(R/'corrected-results.svg');plt.close(fig)
