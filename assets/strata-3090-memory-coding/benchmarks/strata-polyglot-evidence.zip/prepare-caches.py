from pathlib import Path
import os,subprocess,json,hashlib,shutil,concurrent.futures,sys
R=Path(__file__).resolve().parent
env=os.environ.copy();env.update(PATH=f'{R}/tools/node/bin:{R}/tools/rust/bin:{R}/tools/jdk/bin:'+env['PATH'],JAVA_HOME=str(R/'tools/jdk'),CARGO_HOME=str(R/'cache/cargo'),GRADLE_USER_HOME=str(R/'cache/gradle'))
logdir=R/'dependency-logs';logdir.mkdir(exist_ok=True)
def rust():
 for p in sorted((R/'dataset/rust').glob('exercises/practice/*/Cargo.toml')):
  with (logdir/('rust-'+p.parent.name+'.log')).open('w') as f:r=subprocess.run(['cargo','fetch','--manifest-path',str(p)],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=300)
  print('rust',p.parent.name,r.returncode,flush=True)
def java():
 seen=set()
 for p in sorted((R/'dataset/java').glob('exercises/practice/*/build.gradle')):
  digest=hashlib.sha256(p.read_bytes()).hexdigest()
  if digest in seen:continue
  seen.add(digest)
  with (logdir/('java-'+p.parent.name+'.log')).open('w') as f:r=subprocess.run([str(R/'tools/gradle-8.7/bin/gradle'),'--no-daemon','--console=plain','--init-script',str(R/'resolve.gradle'),'resolveDeps'],cwd=p.parent,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=300)
  print('java',p.parent.name,r.returncode,flush=True)
jobs=[rust,java] if len(sys.argv)==1 else [java if sys.argv[1]=='java' else rust]
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:list(ex.map(lambda fn:fn(),jobs))
# Gradle offline cache identity contains java home path; commands will reuse distributions and dependencies.
for base,dirs,files in os.walk(R/'cache'):
 os.chmod(base,0o777)
 for fn in files:
  p=Path(base)/fn
  if not p.is_symlink():os.chmod(p,0o777 if p.stat().st_mode & 0o111 else 0o666)
print('CACHES_READY',flush=True)
