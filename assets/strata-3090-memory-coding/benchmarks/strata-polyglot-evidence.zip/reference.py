from pathlib import Path
import json,shutil,os,time,traceback,sys
from test_runner import run_tests
R=Path(__file__).resolve().parent;DS=R/'dataset';out=R/'reference';out.mkdir(exist_ok=True)
order=json.loads((R/'order.json').read_text())['formal'];results=[]
if len(sys.argv)>1:order=[x for x in order if x.split('/')[0] in sys.argv[1].split(',')]
for rel in order:
 src=DS/rel;dst=out/rel;record=dst/'.reference.json'
 if record.exists():
  old=json.loads(record.read_text())
  if old['passed']:results.append(old);continue
  record.rename(dst/('.reference-failed-'+str(time.time_ns())+'.json'))
 dst.parent.mkdir(parents=True,exist_ok=True);shutil.copytree(src,dst,dirs_exist_ok=True)
 conf=json.loads((src/'.meta/config.json').read_text())['files'];solutions=[x for x in conf['solution'] if x!='Cargo.toml'];examples=conf['example'];t=time.perf_counter();rec={'id':rel}
 try:
  for sol in solutions:
   choices=[x for x in examples if Path(x).suffix==Path(sol).suffix]
   if len(choices)>1:choices=[x for x in choices if Path(x).name==Path(sol).name]
   if not choices and sol.endswith('.cpp') and any(x.endswith('.h') for x in examples):
    (dst/sol).write_text('');continue
   assert len(choices)==1,(rel,sol,choices)
   (dst/sol).parent.mkdir(parents=True,exist_ok=True);shutil.copy(src/choices[0],dst/sol)
  for example in examples:
   if example.startswith('.meta/src/reference/java/'):
    target=dst/'src/main/java'/example.removeprefix('.meta/src/reference/java/');target.parent.mkdir(parents=True,exist_ok=True);shutil.copy(src/example,target)
  if (src/'.meta/Cargo-example.toml').exists():shutil.copy(src/'.meta/Cargo-example.toml',dst/'Cargo.toml')
  # Only this disposable reference workspace is writable by sandbox UID.
  for base,dirs,files in os.walk(dst):
   os.chmod(base,0o777)
   for fn in files:os.chmod(Path(base)/fn,0o777 if (Path(base)/fn).stat().st_mode & 0o111 else 0o666)
  err=run_tests(DS,dst,dst/'.reference-history.md',conf['test']);rec['passed']=err is None
 except Exception:rec.update(passed=False,error=traceback.format_exc())
 rec['wall_s']=time.perf_counter()-t;record.write_text(json.dumps(rec,indent=2));results.append(rec);(out/'progress.json').write_text(json.dumps({'done':len(results),'passed':sum(x['passed'] for x in results),'total':225,'last':rec}));print(json.dumps(rec),flush=True)
 # preserve logs/results, remove build products
 for n in ['build','target','node_modules','.gradle']:
  p=dst/n
  if p.is_symlink():p.unlink()
  elif p.exists():shutil.rmtree(p)
(out/'results.json').write_text(json.dumps(results,indent=2));print('REFERENCE',sum(x['passed'] for x in results),len(results),flush=True)
