#include "all_your_base.h"
#include <stdexcept>
#include <vector>

namespace all_your_base {

std::vector<unsigned int> convert(int input_base, std::vector<unsigned int> input_digits, int output_base) {
    if (input_base < 2 || output_base < 2) {
        throw std::invalid_argument("base must be >= 2");
    }

    // Convert input digits to an integer value
    unsigned int value = 0;
    for (unsigned int digit : input_digits) {
        if (digit >= static_cast<unsigned int>(input_base)) {
            throw std::invalid_argument("digit out of range");
        }
        value = value * input_base + digit;
    }

    // Convert integer value to output base digits
    std::vector<unsigned int> result;
    if (value == 0) {
        return result;
    }

    while (value > 0) {
        result.push_back(value % output_base);
        value /= output_base;
    }

    // Reverse the result to get the correct order
    std::vector<unsigned int> reversed_result;
    for (auto it = result.rbegin(); it != result.rend(); ++it) {
        reversed_result.push_back(*it);
    }

    return reversed_result;
}

}  // namespace all_your_base
