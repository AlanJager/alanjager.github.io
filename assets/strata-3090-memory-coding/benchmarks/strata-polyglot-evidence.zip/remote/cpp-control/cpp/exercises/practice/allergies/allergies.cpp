#include "allergies.h"
#include <string>
#include <unordered_set>
#include <vector>

namespace allergies {

allergy_test::allergy_test(unsigned int score) : score_(score) {}

bool allergy_test::is_allergic_to(const std::string& item) const {
    static const std::vector<std::pair<std::string, unsigned int>> allergens = {
        {"eggs", 1},
        {"peanuts", 2},
        {"shellfish", 4},
        {"strawberries", 8},
        {"tomatoes", 16},
        {"chocolate", 32},
        {"pollen", 64},
        {"cats", 128}
    };

    for (const auto& allergen : allergens) {
        if (allergen.first == item) {
            return (score_ & allergen.second) != 0;
        }
    }
    return false;
}

std::unordered_set<std::string> allergy_test::get_allergies() const {
    std::unordered_set<std::string> result;
    static const std::vector<std::pair<std::string, unsigned int>> allergens = {
        {"eggs", 1},
        {"peanuts", 2},
        {"shellfish", 4},
        {"strawberries", 8},
        {"tomatoes", 16},
        {"chocolate", 32},
        {"pollen", 64},
        {"cats", 128}
    };

    for (const auto& allergen : allergens) {
        if (score_ & allergen.second) {
            result.emplace(allergen.first);
        }
    }

    return result;
}

}  // namespace allergies
