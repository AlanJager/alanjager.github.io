#include "bank_account.h"
#include <stdexcept>

namespace Bankaccount {

Bankaccount::Bankaccount() : balance_(0), is_open(false) {}

void Bankaccount::open() {
    std::lock_guard<std::mutex> lock(mtx);
    if (is_open) {
        throw std::runtime_error("Account already open");
    }
    is_open = true;
    balance_ = 0;
}

void Bankaccount::close() {
    std::lock_guard<std::mutex> lock(mtx);
    if (!is_open) {
        throw std::runtime_error("Account not open");
    }
    is_open = false;
}

void Bankaccount::deposit(double amount) {
    std::lock_guard<std::mutex> lock(mtx);
    if (!is_open) {
        throw std::runtime_error("Account not open");
    }
    if (amount < 0) {
        throw std::runtime_error("Deposit amount must be positive");
    }
    balance_ += amount;
}

void Bankaccount::withdraw(double amount) {
    std::lock_guard<std::mutex> lock(mtx);
    if (!is_open) {
        throw std::runtime_error("Account not open");
    }
    if (amount < 0) {
        throw std::runtime_error("Withdrawal amount must be positive");
    }
    if (balance_ < amount) {
        throw std::runtime_error("Insufficient funds");
    }
    balance_ -= amount;
}

double Bankaccount::balance() const {
    std::lock_guard<std::mutex> lock(mtx);
    if (!is_open) {
        throw std::runtime_error("Account not open");
    }
    return balance_;
}

}  // namespace Bankaccount
