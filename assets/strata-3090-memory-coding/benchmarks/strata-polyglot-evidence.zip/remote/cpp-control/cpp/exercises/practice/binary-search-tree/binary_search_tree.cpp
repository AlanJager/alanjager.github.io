#include "binary_search_tree.h"

namespace binary_search_tree {

// Implementation is mostly in header due to templates, 
// but we can keep the cpp file for any non-template helpers if needed.
// Currently, all logic is in the header for template support.

}  // namespace binary_search_tree
