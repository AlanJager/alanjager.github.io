#if !defined(BINARY_SEARCH_TREE_H)
#define BINARY_SEARCH_TREE_H

#include <memory>
#include <vector>
#include <string>

namespace binary_search_tree {

template <typename T>
class binary_tree {
public:
    T data_val;
    std::unique_ptr<binary_tree<T>> left_node;
    std::unique_ptr<binary_tree<T>> right_node;

    binary_tree(T val) : data_val(val), left_node(nullptr), right_node(nullptr) {}

    T data() const {
        return data_val;
    }

    const binary_tree<T>* left() const {
        return left_node.get();
    }

    const binary_tree<T>* right() const {
        return right_node.get();
    }

    void insert(T val) {
        if (val <= data_val) {
            if (left_node == nullptr) {
                left_node = std::make_unique<binary_tree<T>>(val);
            } else {
                left_node->insert(val);
            }
        } else {
            if (right_node == nullptr) {
                right_node = std::make_unique<binary_tree<T>>(val);
            } else {
                right_node->insert(val);
            }
        }
    }

    bool search(T val) const {
        if (val == data_val) {
            return true;
        } else if (val < data_val) {
            if (left_node == nullptr) {
                return false;
            }
            return left_node->search(val);
        } else {
            if (right_node == nullptr) {
                return false;
            }
            return right_node->search(val);
        }
    }

    // Helper to support iteration for sorting tests
    void collect(std::vector<T>& result) const {
        if (left_node) {
            left_node->collect(result);
        }
        result.push_back(data_val);
        if (right_node) {
            right_node->collect(result);
        }
    }
};

}  // namespace binary_search_tree

#endif // BINARY_SEARCH_TREE_H
