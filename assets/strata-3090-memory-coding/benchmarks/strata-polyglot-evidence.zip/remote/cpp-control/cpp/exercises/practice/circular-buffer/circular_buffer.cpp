#include "circular_buffer.h"

namespace circular_buffer {

// Implementation is in header for simplicity, but can be moved here if needed.
// Currently, all methods are defined inline in the header.

}  // namespace circular_buffer
