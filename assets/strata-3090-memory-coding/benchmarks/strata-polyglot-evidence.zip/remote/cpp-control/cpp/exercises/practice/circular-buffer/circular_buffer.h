#if !defined(CIRCULAR_BUFFER_H)
#define CIRCULAR_BUFFER_H

#include <stdexcept>
#include <vector>

namespace circular_buffer {

template <typename T>
class CircularBuffer {
public:
    CircularBuffer(size_t capacity) : capacity_(capacity), buffer_(capacity), read_idx_(0), write_idx_(0), count_(0) {}

    T read() {
        if (count_ == 0) {
            throw std::domain_error("Buffer is empty");
        }
        T value = buffer_[read_idx_];
        read_idx_ = (read_idx_ + 1) % capacity_;
        count_--;
        return value;
    }

    void write(T value) {
        if (count_ == capacity_) {
            throw std::domain_error("Buffer is full");
        }
        buffer_[write_idx_] = value;
        write_idx_ = (write_idx_ + 1) % capacity_;
        count_++;
    }

    void overwrite(T value) {
        if (count_ == capacity_) {
            buffer_[read_idx_] = value;
            read_idx_ = (read_idx_ + 1) % capacity_;
        } else {
            write(value);
        }
    }

    void clear() {
        read_idx_ = 0;
        write_idx_ = 0;
        count_ = 0;
    }

private:
    size_t capacity_;
    std::vector<T> buffer_;
    size_t read_idx_;
    size_t write_idx_;
    size_t count_;
};

}  // namespace circular_buffer

#endif // CIRCULAR_BUFFER_H
