#include "clock.h"
#include <string>
#include <iomanip>
#include <sstream>

namespace date_independent {

clock::clock(int total_minutes) : total_minutes_(total_minutes) {
    // Normalize to 0..1439
    total_minutes_ = ((total_minutes_ % 1440) + 1440) % 1440;
}

clock clock::at(int hour, int minute) {
    int total = hour * 60 + minute;
    return clock(total);
}

clock clock::plus(int minutes) const {
    return clock(total_minutes_ + minutes);
}

clock clock::minus(int minutes) const {
    return clock(total_minutes_ - minutes);
}

std::string clock::to_string() const {
    int hours = total_minutes_ / 60;
    int minutes = total_minutes_ % 60;

    std::ostringstream oss;
    oss << std::setw(2) << std::setfill('0') << hours << ":"
        << std::setw(2) << std::setfill('0') << minutes;
    return oss.str();
}

bool clock::operator==(const clock& other) const {
    return total_minutes_ == other.total_minutes_;
}

}  // namespace date_independent
