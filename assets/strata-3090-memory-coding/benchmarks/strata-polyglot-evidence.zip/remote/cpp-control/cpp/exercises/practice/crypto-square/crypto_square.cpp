#include "crypto_square.h"
#include <string>
#include <cmath>
#include <cctype>
#include <vector>

namespace crypto_square {

cipher::cipher(const std::string& text) {
    for (char c : text) {
        if (std::isalnum(c)) {
            normalized_text_ += std::tolower(c);
        }
    }

    int len = normalized_text_.size();
    if (len == 0) {
        encoded_text_ = "";
        return;
    }

    int c = static_cast<int>(std::ceil(std::sqrt(len)));
    int r = static_cast<int>(std::floor(std::sqrt(len)));

    if (r * c < len) {
        r++;
    }

    std::vector<std::string> chunks;
    for (int col = 0; col < c; ++col) {
        std::string chunk;
        for (int row = 0; row < r; ++row) {
            int index = row * c + col;
            if (index < len) {
                chunk += normalized_text_[index];
            } else {
                chunk += ' ';
            }
        }
        chunks.push_back(chunk);
    }

    for (size_t i = 0; i < chunks.size(); ++i) {
        if (i > 0) {
            encoded_text_ += ' ';
        }
        encoded_text_ += chunks[i];
    }
}

std::string cipher::normalized_cipher_text() const {
    return encoded_text_;
}

}  // namespace crypto_square
