#include "diamond.h"
#include <string>
#include <vector>

namespace diamond {

std::vector<std::string> rows(char letter) {
    std::vector<std::string> result;
    int n = letter - 'A';

    for (int i = 0; i <= n; ++i) {
        char c = 'A' + i;
        int leading_spaces = n - i;
        int inner_spaces = (i == 0) ? 0 : 2 * i - 1;

        std::string row;
        row.append(leading_spaces, ' ');
        row.push_back(c);
        if (inner_spaces > 0) {
            row.append(inner_spaces, ' ');
            row.push_back(c);
        }
        row.append(leading_spaces, ' ');

        result.push_back(row);
    }

    for (int i = n - 1; i >= 0; --i) {
        result.push_back(result[i]);
    }

    return result;
}

}  // namespace diamond
