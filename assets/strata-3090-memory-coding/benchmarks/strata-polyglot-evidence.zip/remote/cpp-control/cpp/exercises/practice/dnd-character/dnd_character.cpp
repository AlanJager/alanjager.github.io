#include "dnd_character.h"
#include <random>
#include <algorithm>
#include <vector>
#include <cmath>

namespace dnd_character {

int modifier(int score) {
    return static_cast<int>(std::floor((score - 10) / 2.0));
}

int ability() {
    static std::random_device rd;
    static std::mt19937 gen(rd());
    static std::uniform_int_distribution<> dis(1, 6);

    std::vector<int> rolls;
    for (int i = 0; i < 4; ++i) {
        rolls.push_back(dis(gen));
    }

    std::sort(rolls.begin(), rolls.end());
    // Sum the largest three dice (indices 1, 2, 3)
    return rolls[1] + rolls[2] + rolls[3];
}

Character make_character() {
    Character character = {};
    character.strength = ability();
    character.dexterity = ability();
    character.constitution = ability();
    character.intelligence = ability();
    character.wisdom = ability();
    character.charisma = ability();
    character.hitpoints = 10 + modifier(character.constitution);
    return character;
}

}  // namespace dnd_character
