#pragma once

#include <string>

namespace dnd_character {

struct Character {
    int strength;
    int dexterity;
    int constitution;
    int intelligence;
    int wisdom;
    int charisma;
    int hitpoints;
};

int modifier(int score);
int ability();
Character make_character();

}  // namespace dnd_character
