#include "grade_school.h"

namespace grade_school {

bool school::add(const std::string& name, int grade) {
    if (all_students_.count(name)) {
        return false;
    }
    grades_[grade].insert(name);
    all_students_.insert(name);
    return true;
}

std::vector<std::string> school::roster() const {
    std::vector<std::string> result;
    for (const auto& [grade_num, students] : grades_) {
        for (const auto& student : students) {
            result.push_back(student);
        }
    }
    return result;
}

std::vector<std::string> school::grade(int grade) const {
    std::vector<std::string> result;
    auto it = grades_.find(grade);
    if (it != grades_.end()) {
        for (const auto& student : it->second) {
            result.push_back(student);
        }
    }
    return result;
}

}  // namespace grade_school
