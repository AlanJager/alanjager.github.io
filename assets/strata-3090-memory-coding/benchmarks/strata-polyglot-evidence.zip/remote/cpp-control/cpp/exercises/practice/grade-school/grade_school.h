#if !defined(GRADE_SCHOOL_H)
#define GRADE_SCHOOL_H

#include <map>
#include <set>
#include <string>
#include <vector>

namespace grade_school {

class school {
public:
    bool add(const std::string& name, int grade);
    std::vector<std::string> roster() const;
    std::vector<std::string> grade(int grade) const;

private:
    std::map<int, std::set<std::string>> grades_;
    std::set<std::string> all_students_;
};

}  // namespace grade_school

#endif // GRADE_SCHOOL_H
