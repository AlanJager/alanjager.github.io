#include "kindergarten_garden.h"

#include <string>
#include <vector>
#include <map>
#include <sstream>

namespace kindergarten_garden {

std::vector<Plants> plants(const std::string& diagram, const std::string& student) {
    // List of students in alphabetical order
    static const std::vector<std::string> students = {
        "Alice", "Bob", "Charlie", "David", "Eve", "Fred",
        "Ginny", "Harriet", "Ileana", "Joseph", "Kincaid", "Larry"
    };

    // Map plant codes to plant names
    static const std::map<char, Plants> plant_map = {
        {'G', Plants::grass},
        {'C', Plants::clover},
        {'R', Plants::radishes},
        {'V', Plants::violets}
    };

    // Find the index of the student
    int student_index = -1;
    for (size_t i = 0; i < students.size(); ++i) {
        if (students[i] == student) {
            student_index = static_cast<int>(i);
            break;
        }
    }

    if (student_index == -1) {
        return {};
    }

    // Split the diagram into two rows
    std::vector<std::string> rows;
    std::stringstream ss(diagram);
    std::string row;
    while (std::getline(ss, row)) {
        if (!row.empty()) {
            rows.push_back(row);
        }
    }

    if (rows.size() < 2) {
        return {};
    }

    std::vector<Plants> result;
    // Each student gets 2 cups from each row
    // The starting position for the student is student_index * 2
    int start_pos = student_index * 2;

    for (const auto& r : rows) {
        if (start_pos + 1 < static_cast<int>(r.size())) {
            result.push_back(plant_map.at(r[start_pos]));
            result.push_back(plant_map.at(r[start_pos + 1]));
        }
    }

    return result;
}

}  // namespace kindergarten_garden
