#include "knapsack.h"
#include <vector>
#include <algorithm>

namespace knapsack
{

int maximum_value(int max_weight, const std::vector<Item>& items)
{
    // dp[w] represents the maximum value achievable with weight capacity w
    std::vector<int> dp(max_weight + 1, 0);

    for (const auto& item : items)
    {
        // Iterate backwards to ensure each item is used at most once
        for (int w = max_weight; w >= item.weight; --w)
        {
            dp[w] = std::max(dp[w], dp[w - item.weight] + item.value);
        }
    }

    return dp[max_weight];
}

} // namespace knapsack
