#pragma once

#include <cstddef>
#include <stdexcept>

namespace linked_list {

template <typename T>
class List {
private:
    struct Node {
        T data;
        Node* prev;
        Node* next;

        Node(T val, Node* p, Node* n) : data(val), prev(p), next(n) {}
    };

    Node* head;
    Node* tail;
    size_t size;

public:
    List() : head(nullptr), tail(nullptr), size(0) {}

    ~List() {
        Node* current = head;
        while (current != nullptr) {
            Node* next = current->next;
            delete current;
            current = next;
        }
    }

    void push(T val) {
        Node* new_node = new Node(val, tail, nullptr);
        if (tail) {
            tail->next = new_node;
        } else {
            head = new_node;
        }
        tail = new_node;
        size++;
    }

    T pop() {
        if (size == 0) {
            throw std::runtime_error("List is empty");
        }
        T val = tail->data;
        Node* old_tail = tail;
        tail = tail->prev;
        if (tail) {
            tail->next = nullptr;
        } else {
            head = nullptr;
        }
        delete old_tail;
        size--;
        return val;
    }

    T shift() {
        if (size == 0) {
            throw std::runtime_error("List is empty");
        }
        T val = head->data;
        Node* old_head = head;
        head = head->next;
        if (head) {
            head->prev = nullptr;
        } else {
            tail = nullptr;
        }
        delete old_head;
        size--;
        return val;
    }

    void unshift(T val) {
        Node* new_node = new Node(val, nullptr, head);
        if (head) {
            head->prev = new_node;
        } else {
            tail = new_node;
        }
        head = new_node;
        size++;
    }

    size_t count() const {
        return size;
    }

    bool erase(T val) {
        Node* current = head;
        while (current != nullptr) {
            if (current->data == val) {
                if (current == head) {
                    head = current->next;
                    if (head) {
                        head->prev = nullptr;
                    } else {
                        tail = nullptr;
                    }
                } else if (current == tail) {
                    tail = current->prev;
                    if (tail) {
                        tail->next = nullptr;
                    } else {
                        head = nullptr;
                    }
                } else {
                    current->prev->next = current->next;
                    current->next->prev = current->prev;
                }
                delete current;
                size--;
                return true;
            }
            current = current->next;
        }
        return false;
    }
};

}  // namespace linked_list
