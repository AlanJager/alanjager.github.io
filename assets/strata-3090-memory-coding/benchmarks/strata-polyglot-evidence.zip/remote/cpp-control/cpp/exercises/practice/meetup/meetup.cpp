#include "meetup.h"
#include <chrono>

namespace meetup {

std::chrono::year_month_day meetup_day(Week week, Day day, int month, int year) {
    using namespace std::chrono;

    // Convert enum Day to std::chrono::weekday
    // std::chrono::weekday expects Sunday=0, Monday=1, ..., Saturday=6
    // Our enum Day starts with Monday=0.
    // So we need to map:
    // Monday (0) -> 1
    // Tuesday (1) -> 2
    // Wednesday (2) -> 3
    // Thursday (3) -> 4
    // Friday (4) -> 5
    // Saturday (5) -> 6
    // Sunday (6) -> 0
    
    int target_weekday_index;
    switch (day) {
        case Day::Monday: target_weekday_index = 1; break;
        case Day::Tuesday: target_weekday_index = 2; break;
        case Day::Wednesday: target_weekday_index = 3; break;
        case Day::Thursday: target_weekday_index = 4; break;
        case Day::Friday: target_weekday_index = 5; break;
        case Day::Saturday: target_weekday_index = 6; break;
        case Day::Sunday: target_weekday_index = 0; break;
        default: target_weekday_index = 0;
    }

    weekday target_weekday(target_weekday_index);

    // Start date for the month
    year_month_day first_day_of_month{year, month, 1};
    
    // Find the first occurrence of the target weekday in the month
    // We can iterate from the first day to find the first matching weekday
    // Or calculate it directly.
    
    // Let's find the first matching day.
    // The weekday of the first day of the month:
    weekday first_day_weekday = weekday(first_day_of_month);
    
    // Calculate offset to the first target weekday
    int offset = (target_weekday_index - static_cast<int>(first_day_weekday) + 7) % 7;
    int first_matching_day = 1 + offset;
    
    // Now determine the specific day based on the 'week' enum
    int day_of_month = first_matching_day;
    
    switch (week) {
        case Week::first:
            day_of_month = first_matching_day;
            break;
        case Week::second:
            day_of_month = first_matching_day + 7;
            break;
        case Week::third:
            day_of_month = first_matching_day + 14;
            break;
        case Week::fourth:
            day_of_month = first_matching_day + 21;
            break;
        case Week::last:
            // Find the last day of the month
            // We can use std::chrono::year_month_day_last
            year_month_day last_day_of_month = year_month_day_last{year, month};
            // Find the last matching weekday
            // Start from the last day and go backwards
            weekday last_day_weekday = weekday(last_day_of_month);
            int last_offset = (static_cast<int>(last_day_weekday) - target_weekday_index + 7) % 7;
            day_of_month = static_cast<int>(last_day_of_month.day()) - last_offset;
            break;
        case Week::teenth:
            // Check days 13-19
            for (int d = 13; d <= 19; ++d) {
                year_month_day candidate{year, month, d};
                if (weekday(candidate) == target_weekday) {
                    day_of_month = d;
                    break;
                }
            }
            break;
    }
    
    return year_month_day{year, month, day_of_month};
}

}  // namespace meetup
