#if !defined(MEETUP_H)
#define MEETUP_H

#include <chrono>

namespace meetup {

enum class Week {
    first,
    second,
    third,
    fourth,
    last,
    teenth
};

enum class Day {
    Monday,
    Tuesday,
    Wednesday,
    Thursday,
    Friday,
    Saturday,
    Sunday
};

std::chrono::year_month_day meetup_day(Week week, Day day, int month, int year);

}  // namespace meetup

#endif // MEETUP_H
