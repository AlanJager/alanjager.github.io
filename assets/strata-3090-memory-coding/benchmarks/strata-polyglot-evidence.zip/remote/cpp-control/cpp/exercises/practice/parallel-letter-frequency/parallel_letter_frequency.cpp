#include "parallel_letter_frequency.h"

#include <algorithm>
#include <execution>
#include <array>
#include <string_view>
#include <vector>

namespace parallel_letter_frequency {

std::array<int, 26> frequency(const std::vector<std::string_view>& texts) {
    std::array<int, 26> result{};

    // Process each text in parallel
    std::vector<std::array<int, 26>> partial_results(texts.size());
    
    std::transform(std::execution::par_unseq, texts.begin(), texts.end(), partial_results.begin(),
        [](const std::string_view& text) {
            std::array<int, 26> local_counts{};
            for (char c : text) {
                if (c >= 'a' && c <= 'z') {
                    local_counts[c - 'a']++;
                } else if (c >= 'A' && c <= 'Z') {
                    local_counts[c - 'A']++;
                }
            }
            return local_counts;
        });

    // Reduce the partial results
    std::array<int, 26> zero{};
    result = std::reduce(std::execution::par_unseq, partial_results.begin(), partial_results.end(), zero,
        [](const std::array<int, 26>& a, const std::array<int, 26>& b) {
            std::array<int, 26> sum{};
            for (int i = 0; i < 26; ++i) {
                sum[i] = a[i] + b[i];
            }
            return sum;
        });

    return result;
}

}
