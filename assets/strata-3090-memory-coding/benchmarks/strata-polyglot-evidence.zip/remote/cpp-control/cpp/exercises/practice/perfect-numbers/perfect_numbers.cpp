#include "perfect_numbers.h"

namespace perfect_numbers {

classification classify(int64_t num) {
    if (num <= 0) {
        return classification::deficient;
    }

    int64_t aliquot_sum = 0;
    for (int64_t i = 1; i * i <= num; ++i) {
        if (num % i == 0) {
            aliquot_sum += i;
            if (i != 1 && i != num / i) {
                aliquot_sum += num / i;
            }
        }
    }

    if (aliquot_sum == num) {
        return classification::perfect;
    } else if (aliquot_sum > num) {
        return classification::abundant;
    } else {
        return classification::deficient;
    }
}

}  // namespace perfect_numbers
