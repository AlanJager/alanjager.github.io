#include "phone_number.h"
#include <string>
#include <stdexcept>

namespace phone_number {

phone_number::phone_number(const std::string& number) {
    std::string cleaned;
    for (char c : number) {
        if (std::isdigit(c)) {
            cleaned += c;
        }
    }

    if (cleaned.size() == 11) {
        if (cleaned[0] != '1') {
            throw std::domain_error("Invalid country code");
        }
        cleaned = cleaned.substr(1);
    }

    if (cleaned.size() != 10) {
        throw std::domain_error("Invalid number length");
    }

    if (cleaned[0] < '2' || cleaned[3] < '2') {
        throw std::domain_error("Invalid area or exchange code");
    }

    cleaned_number_ = cleaned;
}

std::string phone_number::number() const {
    return cleaned_number_;
}

}  // namespace phone_number
