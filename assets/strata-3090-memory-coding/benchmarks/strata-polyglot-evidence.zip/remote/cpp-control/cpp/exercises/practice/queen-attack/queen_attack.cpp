#include "queen_attack.h"
#include <cstdlib>
#include <stdexcept>

namespace queen_attack {

chess_board::chess_board(std::pair<int, int> white, std::pair<int, int> black)
    : white_(white), black_(black) {
    if (white_.first < 0 || white_.first > 7 || white_.second < 0 || white_.second > 7) {
        throw std::domain_error("Invalid white position");
    }
    if (black_.first < 0 || black_.first > 7 || black_.second < 0 || black_.second > 7) {
        throw std::domain_error("Invalid black position");
    }
    if (white_ == black_) {
        throw std::domain_error("Queens cannot occupy the same position");
    }
}

std::pair<int, int> chess_board::white() const {
    return white_;
}

std::pair<int, int> chess_board::black() const {
    return black_;
}

bool chess_board::can_attack() const {
    int white_row = white_.first;
    int white_col = white_.second;
    int black_row = black_.first;
    int black_col = black_.second;

    // Same row
    if (white_row == black_row) {
        return true;
    }

    // Same column
    if (white_col == black_col) {
        return true;
    }

    // Same diagonal
    if (abs(white_row - black_row) == abs(white_col - black_col)) {
        return true;
    }

    return false;
}

}  // namespace queen_attack
