#include "robot_name.h"
#include <string>
#include <set>
#include <random>

namespace robot_name {

namespace {
    std::set<std::string> used_names;
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> dis(0, 25); // for letters
    std::uniform_int_distribution<> dis_digit(0, 9); // for digits

    std::string generate_name() {
        while (true) {
            std::string new_name;
            new_name += static_cast<char>('A' + dis(gen));
            new_name += static_cast<char>('A' + dis(gen));
            new_name += static_cast<char>('0' + dis_digit(gen));
            new_name += static_cast<char>('0' + dis_digit(gen));
            new_name += static_cast<char>('0' + dis_digit(gen));

            if (used_names.find(new_name) == used_names.end()) {
                used_names.insert(new_name);
                return new_name;
            }
        }
    }
}

robot::robot() {
    name_ = generate_name();
}

std::string robot::name() const {
    return name_;
}

void robot::reset() {
    name_ = generate_name();
}

}  // namespace robot_name
