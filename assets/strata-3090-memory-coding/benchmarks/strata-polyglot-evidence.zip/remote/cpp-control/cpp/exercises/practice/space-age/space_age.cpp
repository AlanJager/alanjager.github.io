#include "space_age.h"

namespace space_age {

namespace {
    constexpr double EARTH_YEAR_IN_SECONDS = 31557600.0;
    constexpr double MERCURY_ORBITAL_PERIOD = 0.2408467;
    constexpr double VENUS_ORBITAL_PERIOD = 0.61519726;
    constexpr double EARTH_ORBITAL_PERIOD = 1.0;
    constexpr double MARS_ORBITAL_PERIOD = 1.8808158;
    constexpr double JUPITER_ORBITAL_PERIOD = 11.862615;
    constexpr double SATURN_ORBITAL_PERIOD = 29.447498;
    constexpr double URANUS_ORBITAL_PERIOD = 84.016846;
    constexpr double NEPTUNE_ORBITAL_PERIOD = 164.79132;
}

space_age::space_age(long long seconds) : seconds_(seconds) {}

long long space_age::seconds() const {
    return seconds_;
}

double space_age::on_mercury() const {
    return seconds_ / (EARTH_YEAR_IN_SECONDS * MERCURY_ORBITAL_PERIOD);
}

double space_age::on_venus() const {
    return seconds_ / (EARTH_YEAR_IN_SECONDS * VENUS_ORBITAL_PERIOD);
}

double space_age::on_earth() const {
    return seconds_ / (EARTH_YEAR_IN_SECONDS * EARTH_ORBITAL_PERIOD);
}

double space_age::on_mars() const {
    return seconds_ / (EARTH_YEAR_IN_SECONDS * MARS_ORBITAL_PERIOD);
}

double space_age::on_jupiter() const {
    return seconds_ / (EARTH_YEAR_IN_SECONDS * JUPITER_ORBITAL_PERIOD);
}

double space_age::on_saturn() const {
    return seconds_ / (EARTH_YEAR_IN_SECONDS * SATURN_ORBITAL_PERIOD);
}

double space_age::on_uranus() const {
    return seconds_ / (EARTH_YEAR_IN_SECONDS * URANUS_ORBITAL_PERIOD);
}

double space_age::on_neptune() const {
    return seconds_ / (EARTH_YEAR_IN_SECONDS * NEPTUNE_ORBITAL_PERIOD);
}

}  // namespace space_age
