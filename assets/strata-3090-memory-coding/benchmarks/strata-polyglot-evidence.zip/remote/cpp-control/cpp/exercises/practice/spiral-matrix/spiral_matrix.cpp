#include "spiral_matrix.h"
#include <vector>
#include <cstddef>

namespace spiral_matrix {

std::vector<std::vector<int>> spiral_matrix(std::size_t size) {
    std::vector<std::vector<int>> matrix(size, std::vector<int>(size, 0));
    
    if (size == 0) {
        return matrix;
    }

    int top = 0, bottom = static_cast<int>(size) - 1, left = 0, right = static_cast<int>(size) - 1;
    int num = 1;

    while (top <= bottom && left <= right) {
        // Fill top row
        for (int i = left; i <= right; ++i) {
            matrix[top][i] = num++;
        }
        top++;

        // Fill right column
        for (int i = top; i <= bottom; ++i) {
            matrix[i][right] = num++;
        }
        right--;

        // Fill bottom row
        if (top <= bottom) {
            for (int i = right; i >= left; --i) {
                matrix[bottom][i] = num++;
            }
            bottom--;
        }

        // Fill left column
        if (left <= right) {
            for (int i = bottom; i >= top; --i) {
                matrix[i][left] = num++;
            }
            left++;
        }
    }

    return matrix;
}

}  // namespace spiral_matrix
