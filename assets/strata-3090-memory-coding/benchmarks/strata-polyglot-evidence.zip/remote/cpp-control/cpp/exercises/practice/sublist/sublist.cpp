#include "sublist.h"
#include <vector>

namespace sublist {

namespace {
    bool is_sublist(const std::vector<int>& a, const std::vector<int>& b) {
        if (a.size() > b.size()) {
            return false;
        }
        if (a.empty()) {
            return true;
        }

        for (size_t i = 0; i <= b.size() - a.size(); ++i) {
            bool match = true;
            for (size_t j = 0; j < a.size(); ++j) {
                if (a[j] != b[i + j]) {
                    match = false;
                    break;
                }
            }
            if (match) {
                return true;
            }
        }
        return false;
    }
}

List_comparison sublist(const std::vector<int>& a, const std::vector<int>& b) {
    if (a == b) {
        return List_comparison::equal;
    }

    if (is_sublist(a, b)) {
        return List_comparison::sublist;
    }

    if (is_sublist(b, a)) {
        return List_comparison::superlist;
    }

    return List_comparison::unequal;
}

}  // namespace sublist
