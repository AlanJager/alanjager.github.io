#include "yacht.h"
#include <algorithm>
#include <map>
#include <numeric>
#include <string>

namespace yacht {

int score(const std::vector<int>& dice, const std::string& category) {
    // Helper to count occurrences
    std::map<int, int> counts;
    for (int d : dice) {
        counts[d]++;
    }

    if (category == "ones") {
        return counts[1] * 1;
    } else if (category == "twos") {
        return counts[2] * 2;
    } else if (category == "threes") {
        return counts[3] * 3;
    } else if (category == "fours") {
        return counts[4] * 4;
    } else if (category == "fives") {
        return counts[5] * 5;
    } else if (category == "sixes") {
        return counts[6] * 6;
    } else if (category == "full house") {
        bool hasThree = false;
        bool hasTwo = false;
        for (const auto& pair : counts) {
            if (pair.second == 3) hasThree = true;
            if (pair.second == 2) hasTwo = true;
        }
        if (hasThree && hasTwo) {
            return std::accumulate(dice.begin(), dice.end(), 0);
        }
        return 0;
    } else if (category == "four of a kind") {
        for (const auto& pair : counts) {
            if (pair.second >= 4) {
                return pair.first * 4;
            }
        }
        return 0;
    } else if (category == "little straight") {
        std::vector<int> sorted_dice = dice;
        std::sort(sorted_dice.begin(), sorted_dice.end());
        if (sorted_dice == std::vector<int>{1, 2, 3, 4, 5}) {
            return 30;
        }
        return 0;
    } else if (category == "big straight") {
        std::vector<int> sorted_dice = dice;
        std::sort(sorted_dice.begin(), sorted_dice.end());
        if (sorted_dice == std::vector<int>{2, 3, 4, 5, 6}) {
            return 30;
        }
        return 0;
    } else if (category == "choice") {
        return std::accumulate(dice.begin(), dice.end(), 0);
    } else if (category == "yacht") {
        if (counts.size() == 1 && counts.begin()->second == 5) {
            return 50;
        }
        return 0;
    }

    return 0;
}

}  // namespace yacht
