#pragma once

#include <string>
#include <vector>

namespace yacht {

enum class Category {
    ONES,
    TWOS,
    THREES,
    FOURS,
    FIVES,
    SIXES,
    FULL_HOUSE,
    FOUR_OF_A_KIND,
    LITTLE_STRAIGHT,
    BIG_STRAIGHT,
    CHOICE,
    YACHT
};

int score(const std::vector<int>& dice, const std::string& category);

}  // namespace yacht
