#include "zebra_puzzle.h"
#include <algorithm>
#include <array>
#include <vector>
#include <string>
#include <cmath>

namespace zebra_puzzle {

// Indices for attributes
enum Attribute {
    Nationality,
    Color,
    Pet,
    Drink,
    Hobby
};

// Values for attributes
enum Nationality {
    Englishman,
    Spaniard,
    Ukrainian,
    Norwegian,
    Japanese
};

enum Color {
    Red,
    Green,
    Ivory,
    Yellow,
    Blue
};

enum Pet {
    Dog,
    Snail,
    Fox,
    Horse,
    Zebra
};

enum Drink {
    Coffee,
    Tea,
    Milk,
    OrangeJuice,
    Water
};

enum Hobby {
    Dancing,
    Painting,
    Reading,
    Football,
    Chess
};

// Helper to check if two houses are adjacent
bool adjacent(int house1, int house2) {
    return std::abs(house1 - house2) == 1;
}

// Helper to check if house1 is immediately to the right of house2
bool right_of(int house1, int house2) {
    return house1 == house2 + 1;
}

std::string getNationalityName(int nat) {
    switch (nat) {
        case Englishman: return "Englishman";
        case Spaniard: return "Spaniard";
        case Ukrainian: return "Ukrainian";
        case Norwegian: return "Norwegian";
        case Japanese: return "Japanese";
        default: return "";
    }
}

Solution solve() {
    // We need to assign each attribute value to one of the 5 houses.
    // Since there are 5! permutations for each attribute, and 5 attributes,
    // the total search space is (5!)^5 = 24,883,200,000.
    // However, we can fix some attributes to reduce the search space significantly.
    // For example, we can fix the order of Nationalities or Colors based on constraints,
    // but a simple brute force with pruning or just iterating permutations is feasible
    // if we structure it well.
    
    // Let's use a vector of indices for each attribute.
    // house[i] will store the index of the value for that attribute.
    // Actually, it's easier to have arrays where index is house number, value is attribute value.
    
    std::array<int, 5> nat;
    std::array<int, 5> col;
    std::array<int, 5> pet;
    std::array<int, 5> drink;
    std::array<int, 5> hobby;

    // Initialize with identity permutation
    for (int i = 0; i < 5; ++i) {
        nat[i] = i;
        col[i] = i;
        pet[i] = i;
        drink[i] = i;
        hobby[i] = i;
    }

    // We will iterate through permutations of nationalities, colors, pets, drinks, hobbies.
    // To make it efficient, we can fix Nationality permutation to identity (0..4) 
    // and permute the others, or just permute all.
    // Given the constraints, we can prune early.
    
    // Let's iterate through permutations of Nationalities first.
    // Then for each, iterate through permutations of Colors, etc.
    // This is still large. Let's try to solve it by iterating permutations of one attribute
    // and checking constraints, or use a more direct CSP approach.
    
    // A simpler approach for this specific puzzle size is to iterate through all permutations
    // of the 5 attributes for the 5 houses.
    // We can represent the state as 5 arrays of size 5.
    // We iterate through permutations of Nationalities.
    // For each, we iterate through permutations of Colors.
    // For each, we iterate through permutations of Pets.
    // For each, we iterate through permutations of Drinks.
    // For each, we iterate through permutations of Hobbies.
    // Check constraints.
    
    // To optimize, we can fix Nationality to [0,1,2,3,4] (Englishman, Spaniard, Ukrainian, Norwegian, Japanese)
    // and permute the others. But constraints link them.
    
    // Let's just do nested loops with next_permutation.
    // 5! = 120. 120^5 is too big.
    // We need to prune.
    
    // Let's try to assign houses 0-4.
    // Constraint 10: Norwegian lives in first house (index 0).
    // So nat[0] must be Norwegian (index 3 in our enum).
    // Constraint 9: Middle house (index 2) drinks Milk (index 2 in Drink enum).
    // So drink[2] must be Milk.
    
    // Let's iterate permutations for Nationalities, but fix index 0 to Norwegian.
    // Actually, let's just iterate all permutations for each attribute and check constraints.
    // But we can prune based on fixed constraints.
    
    // Let's define the values as integers 0-4.
    // Nat: 0=English, 1=Spaniard, 2=Ukrainian, 3=Norwegian, 4=Japanese
    // Col: 0=Red, 1=Green, 2=Ivory, 3=Yellow, 4=Blue
    // Pet: 0=Dog, 1=Snail, 2=Fox, 3=Horse, 4=Zebra
    // Drink: 0=Coffee, 1=Tea, 2=Milk, 3=OrangeJuice, 4=Water
    // Hobby: 0=Dancing, 1=Painting, 2=Reading, 3=Football, 4=Chess
    
    // We will iterate through permutations of Nationalities.
    // For each, we check if Norwegian is at house 0. If not, skip.
    // Then iterate permutations of Colors.
    // For each, check constraints involving colors.
    // Then iterate permutations of Pets.
    // Then Drinks.
    // Then Hobbies.
    
    // This is still potentially large, but with pruning it should be fast enough for a single run.
    
    // Let's implement a recursive backtracking or just nested loops with pruning.
    // Nested loops with next_permutation is easier to write.
    
    // We'll use vectors for permutations.
    std::vector<int> nat_perm = {0, 1, 2, 3, 4};
    std::vector<int> col_perm = {0, 1, 2, 3, 4};
    std::vector<int> pet_perm = {0, 1, 2, 3, 4};
    std::vector<int> drink_perm = {0, 1, 2, 3, 4};
    std::vector<int> hobby_perm = {0, 1, 2, 3, 4};
    
    // We need to map house index to attribute value.
    // Let's assume the permutation vector represents the value at house i.
    // So nat_perm[i] is the nationality of house i.
    
    do {
        // Constraint 10: Norwegian lives in first house.
        if (nat_perm[0] != Norwegian) continue;
        
        // Constraint 2: Englishman lives in red house.
        // We need to find house where nat is Englishman, check if col is Red.
        // But we don't have col yet. We'll check inside the color loop.
        
        do {
            // Constraint 6: Green house is immediately to the right of Ivory house.
            // Find house with Green, check if house-1 has Ivory.
            int green_house = -1;
            int ivory_house = -1;
            for (int i = 0; i < 5; ++i) {
                if (col_perm[i] == Green) green_house = i;
                if (col_perm[i] == Ivory) ivory_house = i;
            }
            if (green_house != ivory_house + 1) continue;
            
            // Constraint 15: Norwegian lives next to blue house.
            // Norwegian is at house 0. So house 1 must be Blue.
            if (col_perm[1] != Blue) continue;
            
            // Constraint 4: Person in green house drinks coffee.
            // We'll check in drink loop.
            
            // Constraint 8: Person in yellow house is a painter.
            // We'll check in hobby loop.
            
            // Constraint 2: Englishman lives in red house.
            // We'll check in hobby/pet/etc loops? No, just check if house with Englishman has Red.
            int eng_house = -1;
            for (int i = 0; i < 5; ++i) {
                if (nat_perm[i] == Englishman) eng_house = i;
            }
            if (col_perm[eng_house] != Red) continue;
            
            do {
                // Constraint 3: Spaniard owns the dog.
                int span_house = -1;
                for (int i = 0; i < 5; ++i) {
                    if (nat_perm[i] == Spaniard) span_house = i;
                }
                if (pet_perm[span_house] != Dog) continue;
                
                // Constraint 7: Snail owner likes dancing.
                // Check in hobby loop.
                
                // Constraint 11: Reading lives next to Fox.
                // Check in hobby loop.
                
                // Constraint 12: Painter's house next to Horse.
                // Check in hobby loop.
                
                do {
                    // Constraint 9: Middle house drinks milk.
                    if (drink_perm[2] != Milk) continue;
                    
                    // Constraint 4: Green house drinks coffee.
                    if (drink_perm[green_house] != Coffee) continue;
                    
                    // Constraint 5: Ukrainian drinks tea.
                    int ukr_house = -1;
                    for (int i = 0; i < 5; ++i) {
                        if (nat_perm[i] == Ukrainian) ukr_house = i;
                    }
                    if (drink_perm[ukr_house] != Tea) continue;
                    
                    // Constraint 13: Football player drinks orange juice.
                    // Check in hobby loop.
                    
                    do {
                        // Constraint 14: Japanese plays chess.
                        int jap_house = -1;
                        for (int i = 0; i < 5; ++i) {
                            if (nat_perm[i] == Japanese) jap_house = i;
                        }
                        if (hobby_perm[jap_house] != Chess) continue;
                        
                        // Constraint 7: Snail owner likes dancing.
                        int snail_house = -1;
                        for (int i = 0; i < 5; ++i) {
                            if (pet_perm[i] == Snail) snail_house = i;
                        }
                        if (hobby_perm[snail_house] != Dancing) continue;
                        
                        // Constraint 8: Yellow house is painter.
                        int yellow_house = -1;
                        for (int i = 0; i < 5; ++i) {
                            if (col_perm[i] == Yellow) yellow_house = i;
                        }
                        if (hobby_perm[yellow_house] != Painting) continue;
                        
                        // Constraint 11: Reading next to Fox.
                        int reading_house = -1;
                        int fox_house = -1;
                        for (int i = 0; i < 5; ++i) {
                            if (hobby_perm[i] == Reading) reading_house = i;
                            if (pet_perm[i] == Fox) fox_house = i;
                        }
                        if (!adjacent(reading_house, fox_house)) continue;
                        
                        // Constraint 12: Painter next to Horse.
                        int painter_house = -1;
                        int horse_house = -1;
                        for (int i = 0; i < 5; ++i) {
                            if (hobby_perm[i] == Painting) painter_house = i;
                            if (pet_perm[i] == Horse) horse_house = i;
                        }
                        if (!adjacent(painter_house, horse_house)) continue;
                        
                        // Constraint 13: Football player drinks orange juice.
                        int football_house = -1;
                        for (int i = 0; i < 5; ++i) {
                            if (hobby_perm[i] == Football) football_house = i;
                        }
                        if (drink_perm[football_house] != OrangeJuice) continue;
                        
                        // All constraints satisfied.
                        // Find who drinks water and who owns zebra.
                        int water_house = -1;
                        int zebra_house = -1;
                        for (int i = 0; i < 5; ++i) {
                            if (drink_perm[i] == Water) water_house = i;
                            if (pet_perm[i] == Zebra) zebra_house = i;
                        }
                        
                        Solution sol;
                        sol.drinksWater = getNationalityName(nat_perm[water_house]);
                        sol.ownsZebra = getNationalityName(nat_perm[zebra_house]);
                        return sol;
                        
                    } while (std::next_permutation(hobby_perm.begin(), hobby_perm.end()));
                } while (std::next_permutation(drink_perm.begin(), drink_perm.end()));
            } while (std::next_permutation(pet_perm.begin(), pet_perm.end()));
        } while (std::next_permutation(col_perm.begin(), col_perm.end()));
    } while (std::next_permutation(nat_perm.begin(), nat_perm.end()));
    
    return {};
}

}  // namespace zebra_puzzle
