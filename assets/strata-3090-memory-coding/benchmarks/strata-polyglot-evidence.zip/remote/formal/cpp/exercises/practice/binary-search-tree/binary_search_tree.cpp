#include "binary_search_tree.h"

namespace binary_search_tree {

// Implementation is mostly in header due to templates.
// If any non-template helper functions were needed, they would go here.

}  // namespace binary_search_tree
