#if !defined(BINARY_SEARCH_TREE_H)
#define BINARY_SEARCH_TREE_H

#include <memory>
#include <vector>
#include <functional>
#include <stack>

namespace binary_search_tree {

template <typename T>
class binary_tree {
public:
    binary_tree() : data_(T()), left_(nullptr), right_(nullptr) {}
    binary_tree(const T& val) : data_(val), left_(nullptr), right_(nullptr) {}

    ~binary_tree() {
        delete left_;
        delete right_;
    }

    void insert(const T& val) {
        if (left_ == nullptr && right_ == nullptr) {
            data_ = val;
            return;
        }

        if (val < data_) {
            if (left_ == nullptr) {
                left_ = new binary_tree<T>(val);
            } else {
                left_->insert(val);
            }
        } else {
            if (right_ == nullptr) {
                right_ = new binary_tree<T>(val);
            } else {
                right_->insert(val);
            }
        }
    }

    const T& data() const {
        return data_;
    }

    const binary_tree<T>* left() const {
        return left_;
    }

    const binary_tree<T>* right() const {
        return right_;
    }

    // Iterator support for range-based for loop (in-order traversal)
    class iterator {
    public:
        iterator(const binary_tree<T>* root) : stack_() {
            if (root) {
                const binary_tree<T>* curr = root;
                while (curr) {
                    stack_.push(curr);
                    curr = curr->left_;
                }
            }
        }

        bool operator==(const iterator& other) const {
            return stack_.empty() && other.stack_.empty();
        }

        bool operator!=(const iterator& other) const {
            return !(*this == other);
        }

        const T& operator*() const {
            return stack_.top()->data_;
        }

        iterator& operator++() {
            const binary_tree<T>* curr = stack_.top();
            stack_.pop();
            
            if (curr->right_) {
                curr = curr->right_;
                while (curr) {
                    stack_.push(curr);
                    curr = curr->left_;
                }
            }
            return *this;
        }

    private:
        std::stack<const binary_tree<T>*> stack_;
    };

    iterator begin() const {
        return iterator(this);
    }

    iterator end() const {
        return iterator(nullptr);
    }

private:
    T data_;
    binary_tree<T>* left_;
    binary_tree<T>* right_;
};

}  // namespace binary_search_tree

#endif // BINARY_SEARCH_TREE_H
