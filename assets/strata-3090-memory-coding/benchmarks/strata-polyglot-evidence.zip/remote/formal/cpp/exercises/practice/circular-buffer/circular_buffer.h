#if !defined(CIRCULAR_BUFFER_H)
#define CIRCULAR_BUFFER_H

#include <vector>
#include <stdexcept>
#include <cstddef>

namespace circular_buffer {

template <typename T>
class circular_buffer {
public:
    circular_buffer(std::size_t capacity) : capacity_(capacity), buffer_(capacity), head_(0), tail_(0), size_(0) {}

    T read() {
        if (size_ == 0) {
            throw std::domain_error("Buffer is empty");
        }
        T value = buffer_[head_];
        head_ = (head_ + 1) % capacity_;
        size_--;
        return value;
    }

    void write(T value) {
        if (size_ == capacity_) {
            throw std::domain_error("Buffer is full");
        }
        buffer_[tail_] = value;
        tail_ = (tail_ + 1) % capacity_;
        size_++;
    }

    void overwrite(T value) {
        if (size_ == capacity_) {
            buffer_[head_] = value;
            head_ = (head_ + 1) % capacity_;
        } else {
            write(value);
        }
    }

    void clear() {
        head_ = 0;
        tail_ = 0;
        size_ = 0;
    }

private:
    std::size_t capacity_;
    std::vector<T> buffer_;
    std::size_t head_;
    std::size_t tail_;
    std::size_t size_;
};

}  // namespace circular_buffer

#endif // CIRCULAR_BUFFER_H
