#include "clock.h"
#include <string>
#include <iomanip>
#include <sstream>

namespace date_independent {

clock::clock(int hours, int minutes) {
    total_minutes_ = (hours * 60 + minutes) % (24 * 60);
    if (total_minutes_ < 0) {
        total_minutes_ += 24 * 60;
    }
}

clock clock::at(int hours, int minutes) {
    return clock(hours, minutes);
}

clock clock::plus(int minutes) const {
    return clock(0, total_minutes_ + minutes);
}

std::string clock::to_string() const {
    int hours = total_minutes_ / 60;
    int mins = total_minutes_ % 60;

    std::ostringstream oss;
    oss << std::setfill('0') << std::setw(2) << hours << ":" << std::setfill('0') << std::setw(2) << mins;
    return oss.str();
}

bool clock::operator==(const clock& other) const {
    return total_minutes_ == other.total_minutes_;
}

}  // namespace date_independent
