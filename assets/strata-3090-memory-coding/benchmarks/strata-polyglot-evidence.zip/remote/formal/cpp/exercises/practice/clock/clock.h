#if !defined(CLOCK_H)
#define CLOCK_H

#include <string>

namespace date_independent {

class clock {
public:
    clock(int hours, int minutes);
    static clock at(int hours, int minutes);
    clock plus(int minutes) const;
    std::string to_string() const;
    bool operator==(const clock& other) const;

private:
    int total_minutes_;
};

}  // namespace date_independent

#endif // CLOCK_H
