#include "complex_numbers.h"
#include <cmath>
#include <stdexcept>

namespace complex_numbers {

Complex::Complex(double real, double imag) : real_part(real), imag_part(imag) {}

double Complex::real() const {
    return real_part;
}

double Complex::imag() const {
    return imag_part;
}

Complex Complex::conj() const {
    return Complex(real_part, -imag_part);
}

double Complex::abs() const {
    return std::sqrt(real_part * real_part + imag_part * imag_part);
}

Complex Complex::exp() const {
    double exp_real = std::exp(real_part);
    double cos_imag = std::cos(imag_part);
    double sin_imag = std::sin(imag_part);
    return Complex(exp_real * cos_imag, exp_real * sin_imag);
}

Complex Complex::add(const Complex& other) const {
    return Complex(real_part + other.real_part, imag_part + other.imag_part);
}

Complex Complex::sub(const Complex& other) const {
    return Complex(real_part - other.real_part, imag_part - other.imag_part);
}

Complex Complex::mul(const Complex& other) const {
    double new_real = real_part * other.real_part - imag_part * other.imag_part;
    double new_imag = imag_part * other.real_part + real_part * other.imag_part;
    return Complex(new_real, new_imag);
}

Complex Complex::div(const Complex& other) const {
    double denom = other.real_part * other.real_part + other.imag_part * other.imag_part;
    if (denom == 0) {
        throw std::domain_error("Division by zero");
    }
    double new_real = (real_part * other.real_part + imag_part * other.imag_part) / denom;
    double new_imag = (imag_part * other.real_part - real_part * other.imag_part) / denom;
    return Complex(new_real, new_imag);
}

Complex Complex::operator+(const Complex& other) const {
    return add(other);
}

Complex Complex::operator-(const Complex& other) const {
    return sub(other);
}

Complex Complex::operator*(const Complex& other) const {
    return mul(other);
}

Complex Complex::operator/(const Complex& other) const {
    return div(other);
}

Complex Complex::operator+(double scalar) const {
    return Complex(real_part + scalar, imag_part);
}

Complex Complex::operator-(double scalar) const {
    return Complex(real_part - scalar, imag_part);
}

Complex Complex::operator*(double scalar) const {
    return Complex(real_part * scalar, imag_part * scalar);
}

Complex Complex::operator/(double scalar) const {
    if (scalar == 0) {
        throw std::domain_error("Division by zero");
    }
    return Complex(real_part / scalar, imag_part / scalar);
}

// Implementations for double op Complex
Complex operator+(double scalar, const Complex& c) {
    return c + scalar;
}

Complex operator-(double scalar, const Complex& c) {
    return Complex(scalar - c.real(), -c.imag());
}

Complex operator*(double scalar, const Complex& c) {
    return c * scalar;
}

Complex operator/(double scalar, const Complex& c) {
    return Complex(scalar, 0).div(c);
}

}  // namespace complex_numbers
