#if !defined(COMPLEX_NUMBERS_H)
#define COMPLEX_NUMBERS_H

#include <cmath>

namespace complex_numbers {

class Complex {
private:
    double real_part;
    double imag_part;

public:
    Complex(double real, double imag);

    double real() const;
    double imag() const;

    Complex conj() const;
    double abs() const;
    Complex exp() const;

    Complex add(const Complex& other) const;
    Complex sub(const Complex& other) const;
    Complex mul(const Complex& other) const;
    Complex div(const Complex& other) const;

    Complex operator+(const Complex& other) const;
    Complex operator-(const Complex& other) const;
    Complex operator*(const Complex& other) const;
    Complex operator/(const Complex& other) const;

    Complex operator+(double scalar) const;
    Complex operator-(double scalar) const;
    Complex operator*(double scalar) const;
    Complex operator/(double scalar) const;
};

// Free functions for double op Complex
Complex operator+(double scalar, const Complex& c);
Complex operator-(double scalar, const Complex& c);
Complex operator*(double scalar, const Complex& c);
Complex operator/(double scalar, const Complex& c);

}  // namespace complex_numbers

#endif  // COMPLEX_NUMBERS_H
