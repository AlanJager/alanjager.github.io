cols_ = static_cast<int>(std::ceil(std::sqrt(len)));
rows_ = static_cast<int>(std::floor(std::sqrt(len)));

if (rows_ * cols_ < len) {
    rows_++;
}
