#include "crypto_square.h"
#include <string>
#include <cmath>
#include <cctype>
#include <vector>

namespace crypto_square {

cipher::cipher(const std::string& text) {
    for (char c : text) {
        unsigned char uc = static_cast<unsigned char>(c);
        if (std::isalnum(uc)) {
            normalized_text_ += static_cast<char>(std::tolower(uc));
        }
    }

    int len = normalized_text_.size();
    if (len == 0) {
        rows_ = 0;
        cols_ = 0;
        return;
    }

    cols_ = static_cast<int>(std::ceil(std::sqrt(len)));
    rows_ = static_cast<int>(std::floor(std::sqrt(len)));

    if (rows_ * cols_ < len) {
        rows_++;
    }
}

std::string cipher::normalized_cipher_text() const {
    if (normalized_text_.empty()) {
        return "";
    }

    std::vector<std::string> chunks;
    for (int col = 0; col < cols_; ++col) {
        std::string chunk;
        for (int row = 0; row < rows_; ++row) {
            int index = row * cols_ + col;
            if (index < static_cast<int>(normalized_text_.size())) {
                chunk += normalized_text_[index];
            } else {
                chunk += ' ';
            }
        }
        chunks.push_back(chunk);
    }

    std::string result;
    for (size_t i = 0; i < chunks.size(); ++i) {
        if (i > 0) {
            result += ' ';
        }
        result += chunks[i];
    }

    return result;
}

}  // namespace crypto_square
