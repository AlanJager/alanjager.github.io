#include "gigasecond.h"

namespace gigasecond {

std::tm advance(const std::tm& time) {
    const long long gigasecond_seconds = 1000000000LL;
    
    // Convert tm to time_t
    std::tm local_time = time;
    time_t t = std::mktime(&local_time);
    
    // Add gigasecond
    t += gigasecond_seconds;
    
    // Convert back to tm
    std::tm result = *std::localtime(&t);
    
    return result;
}

}  // namespace gigasecond
