#if !defined(GIGASECOND_H)
#define GIGASECOND_H

#include <ctime>

namespace gigasecond {

std::tm advance(const std::tm& time);

}  // namespace gigasecond

#endif // GIGASECOND_H
