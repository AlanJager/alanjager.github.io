#include "grade_school.h"

namespace grade_school {

void school::add(const std::string& name, int grade) {
    roster[grade].insert(name);
}

std::vector<std::string> school::students() const {
    std::vector<std::string> result;
    for (const auto& entry : roster) {
        for (const auto& name : entry.second) {
            result.push_back(name);
        }
    }
    return result;
}

std::vector<std::string> school::grade(int grade) const {
    std::vector<std::string> result;
    auto it = roster.find(grade);
    if (it != roster.end()) {
        for (const auto& name : it->second) {
            result.push_back(name);
        }
    }
    return result;
}

}  // namespace grade_school
