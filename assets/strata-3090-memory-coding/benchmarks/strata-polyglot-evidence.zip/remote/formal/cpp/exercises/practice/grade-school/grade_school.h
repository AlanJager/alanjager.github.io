#if !defined(GRADE_SCHOOL_H)
#define GRADE_SCHOOL_H

#include <map>
#include <set>
#include <string>
#include <vector>

namespace grade_school {

class school {
public:
    void add(const std::string& name, int grade);
    std::vector<std::string> students() const;
    std::vector<std::string> grade(int grade) const;

    std::map<int, std::set<std::string>> roster;
};

}  // namespace grade_school

#endif // GRADE_SCHOOL_H
