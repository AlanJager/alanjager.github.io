#include "kindergarten_garden.h"
#include <string>
#include <vector>
#include <map>

namespace kindergarten_garden {

std::vector<Plants> plants(const std::string& diagram, const std::string& student) {
    // Split diagram into two rows
    size_t newline_pos = diagram.find('\n');
    std::string row1 = diagram.substr(0, newline_pos);
    std::string row2 = diagram.substr(newline_pos + 1);

    // List of students in alphabetical order
    static const std::vector<std::string> students = {
        "Alice", "Bob", "Charlie", "David", "Eve", "Fred",
        "Ginny", "Harriet", "Ileana", "Joseph", "Kincaid", "Larry"
    };

    // Find student index
    int student_index = -1;
    for (size_t i = 0; i < students.size(); ++i) {
        if (students[i] == student) {
            student_index = static_cast<int>(i);
            break;
        }
    }

    if (student_index == -1) {
        return {};
    }

    // Map plant codes to enum values
    static const std::map<char, Plants> plant_map = {
        {'G', Plants::grass},
        {'C', Plants::clover},
        {'R', Plants::radishes},
        {'V', Plants::violets}
    };

    // Each student gets 2 cups from each row
    // The cups are assigned alphabetically, so student i gets cups at positions 2*i and 2*i+1
    int start_pos = student_index * 2;
    
    std::vector<Plants> result;
    
    // Add plants from row 1
    result.push_back(plant_map.at(row1[start_pos]));
    result.push_back(plant_map.at(row1[start_pos + 1]));
    
    // Add plants from row 2
    result.push_back(plant_map.at(row2[start_pos]));
    result.push_back(plant_map.at(row2[start_pos + 1]));
    
    return result;
}

}  // namespace kindergarten_garden
