#include "linked_list.h"

namespace linked_list {

template <typename T>
List<T>::List() : head(nullptr), tail(nullptr), size(0) {}

template <typename T>
List<T>::~List() {
    Node* current = head;
    while (current != nullptr) {
        Node* next = current->next;
        delete current;
        current = next;
    }
}

template <typename T>
void List<T>::push(T val) {
    Node* new_node = new Node(val, tail, nullptr);
    if (tail) {
        tail->next = new_node;
    } else {
        head = new_node;
    }
    tail = new_node;
    size++;
}

template <typename T>
T List<T>::pop() {
    if (size == 0) {
        throw std::runtime_error("List is empty");
    }
    T val = tail->data;
    Node* old_tail = tail;
    tail = tail->prev;
    if (tail) {
        tail->next = nullptr;
    } else {
        head = nullptr;
    }
    delete old_tail;
    size--;
    return val;
}

template <typename T>
T List<T>::shift() {
    if (size == 0) {
        throw std::runtime_error("List is empty");
    }
    T val = head->data;
    Node* old_head = head;
    head = head->next;
    if (head) {
        head->prev = nullptr;
    } else {
        tail = nullptr;
    }
    delete old_head;
    size--;
    return val;
}

template <typename T>
void List<T>::unshift(T val) {
    Node* new_node = new Node(val, nullptr, head);
    if (head) {
        head->prev = new_node;
    } else {
        tail = new_node;
    }
    head = new_node;
    size++;
}

template <typename T>
int List<T>::count() const {
    return size;
}

template <typename T>
bool List<T>::erase(T val) {
    Node* current = head;
    while (current != nullptr) {
        if (current->data == val) {
            if (current == head) {
                head = current->next;
                if (head) {
                    head->prev = nullptr;
                } else {
                    tail = nullptr;
                }
            } else if (current == tail) {
                tail = current->prev;
                if (tail) {
                    tail->next = nullptr;
                } else {
                    head = nullptr;
                }
            } else {
                current->prev->next = current->next;
                current->next->prev = current->prev;
            }
            delete current;
            size--;
            return true;
        }
        current = current->next;
    }
    return false;
}

// Explicit instantiation for common types
template class List<int>;

}  // namespace linked_list
