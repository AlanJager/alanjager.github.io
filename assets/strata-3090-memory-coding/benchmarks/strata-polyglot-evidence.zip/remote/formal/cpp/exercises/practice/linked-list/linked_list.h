#pragma once

#include <stdexcept>

namespace linked_list {

template <typename T>
class List {
private:
    struct Node {
        T data;
        Node* prev;
        Node* next;

        Node(T val, Node* p, Node* n) : data(val), prev(p), next(n) {}
    };

    Node* head;
    Node* tail;
    int size;

public:
    List();
    ~List();

    void push(T val);
    T pop();
    T shift();
    void unshift(T val);
    int count() const;
    bool erase(T val);
};

}  // namespace linked_list
