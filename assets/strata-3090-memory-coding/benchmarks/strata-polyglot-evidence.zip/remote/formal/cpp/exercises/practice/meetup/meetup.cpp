#include "meetup.h"
#include <ctime>
#include <cmath>

namespace meetup {

std::tm meetup_day(int year, Month month, Week week, Day day) {
    std::tm tm = {};
    tm.tm_year = year - 1900;
    tm.tm_mon = static_cast<int>(month);
    tm.tm_mday = 1;
    tm.tm_isdst = -1;

    // Normalize the time structure to get correct weekday for the 1st of the month
    std::mktime(&tm);

    int target_weekday = static_cast<int>(day);
    int current_weekday = tm.tm_wday;

    // Adjust tm_wday to match our enum (Monday=0, ..., Sunday=6)
    // std::tm uses Sunday=0, Monday=1, ..., Saturday=6
    // Our enum uses Monday=0, ..., Sunday=6
    // So we need to map:
    // tm_wday 0 (Sun) -> 6
    // tm_wday 1 (Mon) -> 0
    // ...
    // tm_wday 6 (Sat) -> 5
    
    int mapped_current_weekday = (current_weekday + 6) % 7;
    int mapped_target_weekday = static_cast<int>(day);

    int days_to_add = 0;

    if (week == Week::Teenth) {
        // Start from the 13th
        tm.tm_mday = 13;
        std::mktime(&tm);
        int wday = (tm.tm_wday + 6) % 7;
        if (wday == mapped_target_weekday) {
            return tm;
        }
        // Find the first day in 13-19 that matches
        for (int d = 13; d <= 19; ++d) {
            tm.tm_mday = d;
            std::mktime(&tm);
            int w = (tm.tm_wday + 6) % 7;
            if (w == mapped_target_weekday) {
                return tm;
            }
        }
    } else if (week == Week::Last) {
        // Start from the last day of the month
        // Determine last day of month
        int last_day;
        switch (month) {
            case Month::January: last_day = 31; break;
            case Month::February: last_day = (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0)) ? 29 : 28; break;
            case Month::March: last_day = 31; break;
            case Month::April: last_day = 30; break;
            case Month::May: last_day = 31; break;
            case Month::June: last_day = 30; break;
            case Month::July: last_day = 31; break;
            case Month::August: last_day = 31; break;
            case Month::September: last_day = 30; break;
            case Month::October: last_day = 31; break;
            case Month::November: last_day = 30; break;
            case Month::December: last_day = 31; break;
            default: last_day = 31;
        }
        
        tm.tm_mday = last_day;
        std::mktime(&tm);
        int wday = (tm.tm_wday + 6) % 7;
        
        // Go backwards until we find the target weekday
        while (wday != mapped_target_weekday) {
            tm.tm_mday--;
            std::mktime(&tm);
            wday = (tm.tm_wday + 6) % 7;
        }
        return tm;
    } else {
        // First, Second, Third, Fourth
        int n = static_cast<int>(week) + 1; // First=0 -> 1, Second=1 -> 2, etc.
        
        // Find the first occurrence of the target weekday in the month
        // We already have tm set to the 1st of the month
        int wday = (tm.tm_wday + 6) % 7;
        
        // Calculate days to add to get to the first target weekday
        int diff = (mapped_target_weekday - wday + 7) % 7;
        tm.tm_mday += diff;
        
        // Add weeks
        tm.tm_mday += (n - 1) * 7;
        
        std::mktime(&tm);
    }

    return tm;
}

}  // namespace meetup
