#if !defined(MEETUP_H)
#define MEETUP_H

#include <ctime>

namespace meetup {

enum class Day {
    Monday,
    Tuesday,
    Wednesday,
    Thursday,
    Friday,
    Saturday,
    Sunday
};

enum class Week {
    First,
    Second,
    Third,
    Fourth,
    Last,
    Teenth
};

enum class Month {
    January,
    February,
    March,
    April,
    May,
    June,
    July,
    August,
    September,
    October,
    November,
    December
};

std::tm meetup_day(int year, Month month, Week week, Day day);

}  // namespace meetup

#endif // MEETUP_H
