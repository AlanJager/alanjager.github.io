from pathlib import Path
import json,csv
R=Path(__file__).resolve().parent;D=R/'remote'
s=json.loads((R/'summary.json').read_text());v=json.loads((R/'validation.json').read_text());rows=json.loads((R/'results.json').read_text())
assert v['passed'] and s['tasks']==225
def mins(sec):return f'{sec/60:.2f} 分钟'
names={'cpp':'C++','go':'Go','java':'Java','javascript':'JavaScript','python':'Python','rust':'Rust'}
language='\n'.join(f"| {names[k]} | {d['n']} | {d['first_pass']}（{100*d['first_pass']/d['n']:.1f}%） | {d['final_pass']}（{100*d['final_pass']/d['n']:.1f}%） | {d['e2e']['median']:.1f} 秒 | {d['e2e']['p95']:.1f} 秒 |" for k,d in s['by_language'].items())
st=s['stats'];et=s['engine_totals'];b=s['by_call_kind']
outcome='\n'.join(f"| {label} | {d['n']} | {d['e2e']['median']:.1f} 秒 | {d['e2e']['p95']:.1f} 秒 |" for k,label in [('first_success','首次测试通过'),('repair_success','反馈后修复成功'),('failed','最终未通过')] for d in [s['by_outcome'][k]] if d['n'])
failed='\n'.join(f"| `{r['task_id']}` | {r['e2e_s']:.1f} | {r['test_attempts']} | {r['cutoff_calls']} | {r['format_errors']} | {r['test_timeouts']} |" for r in rows if not r['final_pass'])
text=f'''# 原始记录：3090 跑 Aider Polyglot 完整 225 题

> 本报告保留初轮原始结果，其中 C++ 头文件被默认 lint 按 C 解析，产生额外错误反馈。全部 26 道 C++ 题已安排修正复测；最终结果请看 [修正后的汇总报告](FINAL-REPORT.md)。

RTX 3090 / 64GiB 上，Strata 运行 Qwen3.8-Flash-Next-GSQ-RCO IQ2_XS，完成了 Aider Polyglot 全部 225 题。首次运行测试通过 **{s['first_pass']}/225（{s['first_percent']:.2f}%）**，允许一次测试反馈后最终通过 **{s['final_pass']}/225（{s['final_percent']:.2f}%）**。完整串行评测耗时 **{mins(s['suite']['suite_wall_s'])}**；单题端到端中位数 **{st['e2e_s']['median']:.1f} 秒**，P95 **{st['e2e_s']['p95']:.1f} 秒**。

测试流程是“读需求与已有源文件 → 输出修改后的完整文件 → 编译测试 → 根据报错修复一次”。Aider 默认 lint 和格式纠错仍启用，首次测试前可能有额外模型调用。通过要求是该题全部验收测试通过。初始上下文包含题目说明和可编辑源文件，验收测试作为执行后的反馈；本轮没有让模型主动检索仓库或读取其他文件。

![分语言成绩和总时间分解](benchmark-results.png)

## 六种语言分别完成了多少

| 语言 | 题数 | 首次测试通过 | 一次反馈后最终通过 | 单题 E2E 中位数 | P95 |
| --- | ---: | ---: | ---: | ---: | ---: |
{language}

测试反馈额外挽回 **{s['final_pass']-s['first_pass']} 题**，最终还有 **{225-s['final_pass']} 题**未通过。逐题结果、所有模型输出和编译测试日志均保留，失败题包含在分母与耗时统计中。

## 时间花在哪里

| 指标 | 本轮实测 | 计量范围 |
| --- | ---: | --- |
| 完整 225 题墙钟 | {mins(s['suite']['suite_wall_s'])} | 从正式套件启动到最后一题完成，含任务间开销 |
| Aider 编辑平均时间 | {st['aider_edit_s']['mean']:.1f} 秒/题 | coder.run，含本轮同步摘要，排除编译测试 |
| 全部模型调用 | {mins(st['api_s']['sum'])} | 代码、格式纠错及对话摘要 |
| 其中代码与格式纠错 | {mins(b['edit_or_reflection']['wall_s'])} | {b['edit_or_reflection']['calls']} 次调用 |
| 其中对话摘要 | {mins(b['summary']['wall_s'])} | {b['summary']['calls']} 次调用 |
| 编译和测试 | {mins(st['test_s']['sum'])} | 容器启动、编译及测试执行 |
| 任务内客户端其他 | {s['task_other_s']:.1f} 秒 | 文件处理、应用修改、lint、清理等剩余时间 |
| 最长单题 E2E | {st['e2e_s']['max']:.1f} 秒 | 包含生成、摘要与测试 |
| 单题 E2E 中位数 / P95 | {st['e2e_s']['median']:.1f} / {st['e2e_s']['p95']:.1f} 秒 | 完整处理过程，包含失败题 |
| 模型加载 | {s['engine_environment']['load_s']:.1f} 秒 | 独立于正式套件时间 |

在累计任务E2E中，模型API调用占 **{100*st['api_s']['sum']/st['e2e_s']['sum']:.1f}%**，编译测试占 **{100*st['test_s']['sum']/st['e2e_s']['sum']:.1f}%**。模型调用包括代码生成、内部纠错与对话摘要。

按任务结果分组，等待时间如下：

| 结果 | 题数 | E2E 中位数 | P95 |
| --- | ---: | ---: | ---: |
{outcome}

![各题完整等待时间](task-latency.png)

所有模型调用都串行完成。为便于归属每题时间，Aider 的后台摘要在本轮改为等待完成并提交后再继续；运行时记录方法名与脚本哈希，并检查每题 API 时间加测试时间不超过 E2E。这个改动会影响工作流耗时和摘要生效时点，复测需使用相同协议。

本轮使用非流式 Aider 请求，记录的是完整 API 耗时；客户端 TTFT 未采集。按服务返回的 usage，累计处理输入 **{int(st['prompt_tokens']['sum']):,} token**、输出 **{int(st['completion_tokens']['sum']):,} token**，包含摘要和纠错调用。成功调用的最大输入 **{s['max_api_prompt_tokens']:,} token**、最大输出 **{s['max_api_completion_tokens']:,} token**。引擎日志解析到 **{et['engine_requests']}/{int(st['api_calls']['sum'])} 次**完成记录，累计 prefill **{et['prefill_ms']/1000:.1f} 秒**、decode **{et['decode_ms']/1000:.1f} 秒**；这些是模型内部阶段时间，口径与用户等待时间不同。

## 运行质量与资源观测

| 观测 | 数量 |
| --- | ---: |
| 输出达到 length 上限的调用 / 涉及题目 | {s['finish_counts'].get('length',0)} / {s['cutoff_tasks']} |
| 发生格式解析错误的题目 | {s['format_error_tasks']} |
| Aider token 预算耗尽记录涉及题目（含输出上限） | {s['aider_token_exhausted_tasks']} |
| 引擎拒绝上下文超限的调用 / 题目 | {s['context_reject_calls']} / {len(s['context_reject_ids'])} |
| API 错误题目 | {s['api_error_tasks']} |
| 测试超时题目 | {s['test_timeout_tasks']} |
| 任务级异常题目 | {s['exception_tasks']} |
| 请求区间引擎累计磁盘读取 | {st['read_bytes']['sum']/1024/1024:.3f} MiB |
| 请求区间引擎累计 major fault | {int(st['major_faults']['sum'])} |

涉及截断的题目中有 {s['cutoff_final_pass_tasks']} 题最终通过测试：Aider可能已经应用了有效修改，后续解释或纠错调用才达到输出上限。评分依据最终文件的验收结果，截断另行记录。

磁盘读量来自引擎进程 `/proc/PID/io` 在每次 API 调用前后的差值；major fault 来自同进程计数。它们用于观察模型请求期的权重读取，不包含整机编译与依赖缓存读写。资源采样另保留系统内存、GPU 利用率/功耗和块设备计数的共同时间轴。

32K总上下文需同时容纳输入和输出预留。固定8192输出上限时，单次输入可用空间为24576 token；过长的编译错误或历史会触发明确拒绝。超限任务保留在225题分母中，属于本轮上下文与反馈处理策略的限制。被拒绝的请求没有成功返回usage，未计入处理token总量。

具体失败示例见 [失败分析](FAILURES.md)，完整失败名单列在文末。

## 用来判断个人编码场景

这套结果覆盖小型源文件编辑、多语言编译和一次报错修复。完成率回答能否通过验收；单题 E2E 回答要等多久；首次与最终通过率之差回答一次反馈能挽回多少任务。把这三个指标和日常项目任务放在一起，更容易判断是否适合作为个人编码助手。

此前 HumanEval+ 的 156/164（95.12%）对应 Python 函数生成。本轮包含文件编辑协议、工具链与测试反馈，两组结果分别保留。真实项目的跨文件检索、依赖升级、长对话、工具调用和持续多轮修改，还需要项目级任务补充验证。

对比另一张显卡时，固定同一模型、量化、Aider 版本和题序，观察完成率与 E2E。对比公共 API 时，同时记录模型版本、推理模式、预算、网络延迟和实际费用。[复测协议](REPLAY.md)与[对比表](comparison.csv)已准备；当前没有公共 API 实测或费用数据。[历史榜单参考](PUBLIC-REFERENCES.md)另列测试日期、编辑格式和计时口径。

## 配置与复现

- 硬件：RTX 3090 24GiB、Xeon Gold 5318Y 16 vCPU、系统可见约 63.3GiB 内存。
- 模型：Qwen3.8-Flash-Next-GSQ-RCO IQ2_XS。Strata 0.1.43，提交 `7695859aa13afb248bdb4d36f9b2e95707db079d`。
- 引擎：PLE RAM、pcie_frac=1、prefill=2048 / CPU share=0、尾部专家跳过=0、7 workers、18GiB 专家缓存、32K/int8 KV、MTP=4；关闭 prompt 与 conversation 缓存。
- 采样：temperature=0、top_p=0.95、seed=20261015、reasoning_effort=none、单次输出上限8192。
- 编辑：whole；最多两次测试尝试；保留 Aider 默认 lint、格式修正与摘要，摘要串行等待，历史摘要阈值2048 token，摘要使用同一模型。
- 题序：225 个路径排序后按 seed20261015 打乱；同一套顺序保存在 order.json。
- 测试：无网络、非 root、无 GPU 的 Docker 环境；4 CPU / 6GiB，每次测试180秒，每题600秒。
- 环境自检：官方参考程序 225/225 通过。Aider 与题库的跟踪文件与固定提交归档一致。正式结果的验收文件和构建配置已按官方启用测试的转换规则核对。

本轮[官方 Aider 源码](https://github.com/Aider-AI/aider/blob/5dc9490bb35f9729ef2c95d00a19ccd30c26339c/benchmark/benchmark.py)、[Polyglot 题库](https://github.com/Aider-AI/polyglot-benchmark/tree/7e0611e77b54e2dea774cdc0aa00cf9f7ed6144f)。

## 注意

这是单轮、单请求并发实测。依赖缓存已经预热，专家缓存随题序自然变化；未测多人服务。与公共榜单比较时，需核对编辑格式、模型、推理模式、版本、预算以及摘要调度。工具链、CPU 配额和测试超时也会影响任务结果及时间。

初次接入预检和一批采用旧计时逻辑的记录保留在 pilot-before-serial-summary，用于排查摘要跨题问题；它们不进入本轮正式统计。最终正式 225 题没有按成绩筛选或重做。API 元数据中的零价格是本地计费占位值，未测电费和硬件摊销。

## 完整失败名单

| 任务 | E2E 秒 | 测试尝试 | 截断调用 | 格式错误 | 测试超时 |
| --- | ---: | ---: | ---: | ---: | ---: |
{failed}
'''
(R/'REPORT.md').write_text(text)
fields=['configuration','model','benchmark','edit_format','summary_schedule','tasks','first_pass','final_pass','first_percent','final_percent','suite_s','task_median_s','task_p95_s','api_total_s','tests_total_s','cutoff_tasks','task_exception_count','actual_cost','notes']
base=dict(zip(fields,['RTX3090-64GiB-PLEram-pcie1-tail0','Qwen3.8-Flash-Next-GSQ-RCO IQ2_XS','Aider Polyglot 7e0611e / Aider 5dc9490','whole','serial',225,s['first_pass'],s['final_pass'],s['first_percent'],s['final_percent'],s['suite']['suite_wall_s'],st['e2e_s']['median'],st['e2e_s']['p95'],st['api_s']['sum'],st['test_s']['sum'],s['cutoff_tasks'],s['exception_tasks'],'未测','single run; temp0; max8192; reasoning none; tools4CPU/6GiB']))
with (R/'comparison.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerow(base)
 for label in ['候选硬件待测','公共API待测']:w.writerow({'configuration':label,'benchmark':base['benchmark'],'edit_format':'whole','summary_schedule':'serial','tasks':225,'notes':'保持相同协议，实测后填写'})
print('REPORT.md and comparison.csv written')
