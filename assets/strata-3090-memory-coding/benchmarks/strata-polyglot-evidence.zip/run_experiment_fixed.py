from pathlib import Path
import os,json,hashlib,time,threading,subprocess,fcntl,signal
import support as s
import harness as h
R=Path(__file__).resolve().parent;REPO=s.REPO

def phase(base,name):
 out=R/(name+'-engine');out.mkdir(exist_ok=False);c=json.loads(json.dumps(base));c.update(port=8081,log=str(out/'engine.log'),open_browser=False)
 for flag,value in {'--ple-io':'ram','--pcie-frac':'1','--prompt-cache':'0','--conversation-cache-mib':'0'}.items():
  if flag in c['args']:c['args'][c['args'].index(flag)+1]=value
  else:c['args'] += [flag,value]
 s.save(out/'config.json',c);env=os.environ.copy()
 for k in list(env):
  if k.startswith('STRATA_PREFILL_'):env.pop(k)
 env.update(STRATA_ROUTE_TAIL_SKIP='0',STRATA_PREFILL_CPU_SHARE='0')
 p=None;sampler=None;stop=threading.Event();f=(out/'server.out').open('w')
 try:
  t=time.perf_counter();p=subprocess.Popen([str(REPO/'.venv/bin/python'),str(REPO/'serve/server.py'),'--engine','strata','--config',str(out/'config.json'),'--port','8081'],cwd=REPO,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
  health=s.loaded(p,8081);pid=h.child(p.pid);assert pid;log=(out/'engine.log').read_text();assert 'PLE table locked in RAM' in log and '13432 slots, 18.00 GiB' in log
  s.save(out/'environment.json',{'health':health,'pid':pid,'load_s':time.perf_counter()-t,'memory':s.meminfo(),'cmdline':Path('/proc',str(pid),'cmdline').read_text().replace('\0',' '),'engine_sha256':hashlib.sha256((REPO/'engine/strata').read_bytes()).hexdigest(),'expert_profile_sha256':hashlib.sha256((REPO/'data/expert-profile.bin').read_bytes()).hexdigest()})
  sampler=threading.Thread(target=h.sample,args=(out/'resources.jsonl',pid,stop),daemon=True);sampler.start()
  h.request({'id':'warmup','max_tokens':16},[{'role':'user','content':'只回答：就绪'}],out,pid,out/'engine.log')
  se=os.environ.copy();se.update(PYTHONPATH=str(R/'vendor'),STRATA_BENCH_PID=str(pid),STRATA_BENCH_LOG=str(out/'engine.log'),PYTHONUNBUFFERED='1',PYTHONHASHSEED='20261015')
  with (R/(name+'-suite.log')).open('w') as sf:
   subprocess.run(['/usr/bin/python3',str(R/'run_suite_fixed.py'),name],cwd=R,env=se,stdout=sf,stderr=subprocess.STDOUT,check=True,timeout=8*3600)
  assert (R/name/'completed.json').exists()
 finally:
  stop.set()
  if sampler:sampler.join(5)
  h.stop_server(p);f.close()

def main():
 def terminate(n,f):raise SystemExit(128+n)
 signal.signal(signal.SIGTERM,terminate)
 lock=(R/'run.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert 62<s.meminfo()['MemTotal']/1024**3<66
 assert hashlib.sha256((REPO/'engine/strata').read_bytes()).hexdigest()==s.ENGINE_SHA
 # Formal test starts only after every reference program passes in the actual sandbox.
 refs=[json.loads(p.read_text()) for p in (R/'reference').glob('*/exercises/practice/*/.reference.json')]
 assert len(refs)==225 and all(x['passed'] for x in refs),('reference selftest incomplete',len(refs),sum(x['passed'] for x in refs))
 base=json.loads((REPO/'strata-iq2_xs.json').read_text());s.save(R/'preflight.json',{'memory':s.meminfo(),'base':base,'utc':h.stamp(),'cpu':subprocess.check_output(['lscpu'],text=True),'gpu':subprocess.check_output(['nvidia-smi','--query-gpu=name,memory.total,driver_version','--format=csv,noheader'],text=True)})
 restore=s.stop_existing();assert restore
 try:
  phase(base,'smoke')
  smoke=json.loads((R/'smoke/results.json').read_text());assert len(smoke)==5 and all(x['api_calls']>0 and 'error' not in x for x in smoke),'smoke workflow exception'
  # A code failure is a valid smoke outcome; protocol and environment are the gate.
  phase(base,'formal');s.save(R/'completed.json',{'utc':h.stamp(),'tasks':225,'smoke':5})
 finally:
  f=(R/'restored-server.out').open('a');p=subprocess.Popen([str(REPO/'start-optimized-3090.sh')],cwd=REPO,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);v=s.loaded(p,8080);pid=h.child(p.pid);(REPO/'optimized-service.pid').write_text(str(p.pid)+'\n');h.URL='http://127.0.0.1:8080';rec=h.request({'id':'restoration-smoke','max_tokens':32},[{'role':'user','content':'只回答：服务已恢复'}],R,pid,Path(base['log']));assert rec['sse_done'] and rec['finish_reason']=='stop';s.save(R/'restored.json',{'health':v,'pid':pid,'utc':h.stamp()});print('Daily service restored',flush=True)
if __name__=='__main__':main()
