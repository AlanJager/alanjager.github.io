from pathlib import Path
import os,sys,json,time,shutil,signal,traceback,hashlib,subprocess,inspect,threading
R=Path(__file__).resolve().parent
os.environ['PYTHONPATH']=str(R/'vendor')
os.environ.update(OPENAI_API_BASE='http://127.0.0.1:8081/v1',OPENAI_API_KEY='local-no-key',AIDER_ANALYTICS_DISABLE='true',LITELLM_LOCAL_MODEL_COST_MAP='True',TOKENIZERS_PARALLELISM='false')
sys.path[:0]=[str(R/'aider-src/benchmark'),str(R/'aider-src'),str(R/'vendor')]
import benchmark as b
from aider import models
from aider.coders.base_coder import Coder
from aider.io import InputOutput
from aider import linter as lint_module
original_filename_to_lang = lint_module.filename_to_lang
def cpp_header_language(fname):
 return 'cpp' if str(fname).endswith('.h') else original_filename_to_lang(fname)
lint_module.filename_to_lang = cpp_header_language
from test_runner import run_tests
import harness as h
CURRENT=None;API_NO=0
modelname='openai/qwen3.8-flash-next-iq2_xs'
metadata={'max_tokens':32768,'max_input_tokens':32768,'max_output_tokens':8192,'input_cost_per_token':0,'output_cost_per_token':0,'litellm_provider':'openai','mode':'chat'}
models.model_info_manager.local_model_metadata[modelname]=metadata
models.litellm.register_model({modelname:metadata})
models.MODEL_SETTINGS.append(models.ModelSettings(name=modelname,edit_format='whole',use_repo_map=False,weak_model_name=None,extra_params={'max_tokens':8192,'top_p':0.95,'seed':20261015,'extra_body':{'reasoning_effort':'none'},'timeout':300},use_temperature=0))
models.RETRY_TIMEOUT=1
models.request_timeout=300
b.run_unit_tests=run_tests
# Single-request protocol: drain background conversation summaries before returning.
original_summarize_start=Coder.summarize_start
def serialized_summary(self):
 original_summarize_start(self)
 self.summarize_end()
Coder.summarize_start=serialized_summary
original_send=models.Model.send_completion

def traced_send(self,messages,functions,stream,temperature=None):
 global API_NO
 assert self.name==modelname,'unexpected model';assert not stream
 n=API_NO;API_NO+=1;log=Path(os.environ['STRATA_BENCH_LOG']) if os.environ.get('STRATA_BENCH_LOG') else None;offset=log.stat().st_size if log else 0;t=time.perf_counter();rec={'model':self.name,'messages':messages,'stream':stream,'temperature':temperature,'extra_params':self.extra_params,'started':h.stamp(),'start_mono':t,'thread':threading.current_thread().name}
 rec['before']=h.procstat(int(os.environ['STRATA_BENCH_PID'])) if os.environ.get('STRATA_BENCH_PID') else {}
 try:
  x=original_send(self,messages,functions,stream,temperature);rec['response']=x[1].model_dump();return x
 except BaseException as e:rec['error']=repr(e);raise
 finally:
  rec['end_mono']=time.perf_counter();rec['wall_s']=rec['end_mono']-t
  if log:(CURRENT/f'.api-{n:03}.engine.log').write_bytes(log.read_bytes()[offset:])
  rec['after']=h.procstat(int(os.environ['STRATA_BENCH_PID'])) if os.environ.get('STRATA_BENCH_PID') else {}; (CURRENT/f'.api-{n:03}.json').write_text(json.dumps(rec,ensure_ascii=False,indent=2,default=str))
models.Model.send_completion=traced_send
origwrite=InputOutput.write_text

def safe_write(self,filename,content):
 p=Path(filename).resolve()
 if CURRENT is not None and not p.is_relative_to(CURRENT.resolve()):raise ValueError('write outside task workspace rejected')
 return origwrite(self,filename,content)
InputOutput.write_text=safe_write
class TaskDeadline(BaseException):pass
def alarm(signum,frame):raise TaskDeadline('600 second task deadline')
signal.signal(signal.SIGALRM,alarm)

def main():
 global CURRENT,API_NO
 phase=sys.argv[1];assert phase in ['cpp-control'];out=R/phase;out.mkdir(exist_ok=False)
 assert Coder.summarize_start.__name__=='serialized_summary'
 (out/'runtime.json').write_text(json.dumps({'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'header_lint_language':'cpp','summary_method':Coder.summarize_start.__name__,'summary_source':inspect.getsource(Coder.summarize_start),'pid':os.getpid(),'started':h.stamp()},indent=2))
 order=json.loads((R/'cpp-control-order.json').read_text())[phase];begin=time.perf_counter();records=[]
 for i,rel in enumerate(order):
  dst=out/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copytree(R/'dataset'/rel,dst);CURRENT=dst;API_NO=0
  for base,dirs,files in os.walk(dst):
   os.chmod(base,0o777)
   for fn in files:os.chmod(Path(base)/fn,0o777 if (Path(base)/fn).stat().st_mode & 0o111 else 0o666)
  t=time.perf_counter();rec={'id':rel,'started':h.stamp()};signal.alarm(600)
  try:
   with (dst/'.runner.log').open('w') as log:
    from contextlib import redirect_stdout,redirect_stderr
    with redirect_stdout(log),redirect_stderr(log):
     result=b.run_test_real(R/'dataset',dst,modelname,'whole',2,False,False,False,'5dc9490bb35f9729ef2c95d00a19ccd30c26339c',None,None,None)
   rec['official']=result
  except BaseException as e:
   if isinstance(e,(KeyboardInterrupt,SystemExit)):raise
   rec['error']=traceback.format_exc()
  finally:signal.alarm(0)
  rec['e2e_s']=time.perf_counter()-t;rec['api_calls']=API_NO;rec['finished']=h.stamp();rec['first_pass']=bool(rec.get('official',{}).get('tests_outcomes',[False])[0]);rec['final_pass']=any(rec.get('official',{}).get('tests_outcomes',[]))
  tests=[json.loads(p.read_text()) for p in dst.glob('.test-*.json')];rec['test_s']=sum(x.get('wall_s',0) for x in tests)
  ap=[json.loads(p.read_text()) for p in sorted(dst.glob('.api-*.json'))]
  rec['api_time_s']=sum(a['wall_s'] for a in ap);rec['timing_serial_valid']=rec['api_time_s']+rec['test_s']<=rec['e2e_s']+.1
  (dst/'.task.json').write_text(json.dumps(rec,indent=2))
  assert rec['timing_serial_valid'],('overlapping accounting',rel,rec)
  assert len(ap)==rec['api_calls'],('unfinished callback',rel)
  records.append(rec)
  progress={'done':i+1,'total':len(order),'first_pass':sum(x['first_pass'] for x in records),'final_pass':sum(x['final_pass'] for x in records),'elapsed_s':time.perf_counter()-begin,'last':{k:rec[k] for k in ['id','e2e_s','first_pass','final_pass','api_calls']},'exceptions':sum('error' in x for x in records)}
  (out/'progress.json').write_text(json.dumps(progress,indent=2));print(json.dumps(progress),flush=True)
 (out/'results.json').write_text(json.dumps(records,indent=2));(out/'completed.json').write_text(json.dumps({'tasks':len(records),'suite_wall_s':time.perf_counter()-begin,'utc':h.stamp()},indent=2))
if __name__=='__main__':main()
