from pathlib import Path
import subprocess,os,json,time,uuid
R=Path(__file__).resolve().parent
IMAGE='strata-polyglot-sandbox:20261015'
def cmd(work,command,network=False):
 work=Path(work).resolve(); name='polyglot-'+uuid.uuid4().hex[:12]
 args=['docker','run','--rm','--name',name,'--network','bridge' if network else 'none','--read-only','--cap-drop','ALL','--security-opt','no-new-privileges','--user','65534:65534','--cpus','4','--memory','6g','--memory-swap','6g','--pids-limit','256','--tmpfs','/tmp:rw,exec,nosuid,nodev,size=2g,mode=1777','--workdir',str(work)]
 mounts=[('/usr','/usr','ro'),('/lib','/lib','ro'),('/lib64','/lib64','ro'),('/etc/ld.so.cache','/etc/ld.so.cache','ro'),(R/'tools','/toolchains','ro'),(R/'vendor','/vendor','ro'),(R/'aider-src','/aider','ro'),(R/'npm-install','/npm-install','ro'),(R/'cache','/cache','rw'),(work,work,'rw')]
 for a,b,c in mounts:args+=['-v',f'{a}:{b}:{c}']
 env={'PATH':'/toolchains/node/bin:/toolchains/go/bin:/toolchains/rust/bin:/toolchains/jdk/bin:/vendor/bin:/usr/bin:/bin','PYTHONPATH':'/vendor','PYTHONDONTWRITEBYTECODE':'1','HOME':'/tmp','XDG_CACHE_HOME':'/tmp/cache','GOROOT':'/toolchains/go','GOCACHE':'/cache/go-build','GOPATH':'/cache/go','GOTOOLCHAIN':'local','GOPROXY':'off','CARGO_TARGET_X86_64_UNKNOWN_LINUX_GNU_LINKER':'/usr/bin/gcc','CARGO_HOME':'/cache/cargo','CARGO_NET_OFFLINE':'true','JAVA_HOME':'/toolchains/jdk','GRADLE_USER_HOME':'/cache/gradle','GRADLE_OPTS':'-Dorg.gradle.daemon=false -Dorg.gradle.workers.max=2','CMAKE_PREFIX_PATH':'/toolchains/sysroot/usr','CPLUS_INCLUDE_PATH':'/toolchains/sysroot/usr/include','LIBRARY_PATH':'/toolchains/sysroot/usr/lib/x86_64-linux-gnu','LD_LIBRARY_PATH':'/toolchains/sysroot/usr/lib/x86_64-linux-gnu','CI':'true','OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1','TZ':'UTC','LANG':'C.UTF-8'}
 for k,v in env.items():args+=['-e',f'{k}={v}']
 return args+[IMAGE]+command,name

def run(work,command,timeout=180):
 args,name=cmd(work,command); t=time.perf_counter()
 try:
  r=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=timeout,encoding='utf-8',errors='replace')
 except subprocess.TimeoutExpired:
  subprocess.run(['docker','rm','-f',name],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL);raise
 return r,time.perf_counter()-t
