#!/bin/bash
set -eu
cd /experiment
mkdir -p tools/node tools/go tools/jdk tools/rust-dist tools/rust tools/sysroot cache/cargo cache/gradle npm-install rootfs/{etc,usr,lib,lib64,tmp,work,toolchains,cache,vendor,aider,npm-install}
tar -xJf node.tar.xz --strip-components=1 -C tools/node
tar -xzf go.tar.gz --strip-components=1 -C tools/go
tar -xzf jdk.tar.gz --strip-components=1 -C tools/jdk
tar -xJf rust.tar.xz --strip-components=1 -C tools/rust-dist
tools/rust-dist/install.sh --prefix="$PWD/tools/rust" --components=rustc,cargo,rust-std-x86_64-unknown-linux-gnu --disable-ldconfig
python3 -m zipfile -e gradle.zip tools
for f in debs/*.deb; do dpkg-deb -x "$f" tools/sysroot; done
ln -sf usr/bin rootfs/bin
ln -sf usr/sbin rootfs/sbin
printf 'bench:x:65534:65534:bench:/tmp:/bin/sh\n' >rootfs/etc/passwd
printf 'bench:x:65534:\n' >rootfs/etc/group
tar -C rootfs -cf - . | docker import - strata-polyglot-sandbox:20261015
export PATH="$PWD/tools/node/bin:$PATH"
cd npm-install
npm init -y
npm install --registry=https://registry.npmmirror.com jest@29.7.0 @babel/core@7.25.2 @exercism/babel-preset-javascript@0.2.1 @exercism/eslint-config-javascript@0.6.0 @types/jest@29.5.12 @types/node@20.12.12 babel-jest@29.6.4 core-js@3.37.1 eslint@8.49.0
