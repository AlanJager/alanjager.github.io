import json,time,urllib.request,subprocess,signal,os
from pathlib import Path
import harness as h
ROOT=Path(__file__).resolve().parent
REPO=Path('/engine')
ENGINE_SHA='6cc0dda09c0327810d590c4e15d610e8a7a8f3ab05fcfc7376da77b18054e42e'
def save(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2))

def meminfo():return {k:int(v.strip().split()[0])*1024 for k,v in (s.split(':') for s in Path('/proc/meminfo').read_text().splitlines()) if k in ['MemTotal','MemAvailable','Mlocked','SwapTotal']}

def health(port):
 with urllib.request.urlopen(f'http://127.0.0.1:{port}/health',timeout=3) as r:return json.load(r)

def loaded(p,port):
 for _ in range(450):
  if p.poll() is not None:raise RuntimeError('service exited '+str(p.returncode))
  try:
   v=health(port)
   if v.get('loaded'):return v
  except Exception:pass
  time.sleep(2)
 raise RuntimeError('model load timeout')

def stop_existing():
 pid=None
 for line in subprocess.check_output(['ps','-eo','pid,args'],text=True).splitlines():
  if str(REPO/'serve/server.py') in line and '--port 8080' in line:
   if pid is not None:raise RuntimeError('multiple original services')
   pid=int(line.strip().split()[0])
 if pid:
  with urllib.request.urlopen('http://127.0.0.1:8080/slots',timeout=5) as r:assert not any(x.get('is_processing') for x in json.load(r)), 'original service busy'
  cp=h.child(pid);save(ROOT/'original-process.json',{'pid':pid,'engine_pid':cp,'command':Path('/proc',str(pid),'cmdline').read_text().replace('\0',' ')})
  for n in [pid,cp]:
   if n:
    try:os.kill(n,signal.SIGTERM)
    except ProcessLookupError:pass
  for _ in range(30):
   if not cp or not Path('/proc',str(cp)).exists():break
   time.sleep(1)
  else:raise RuntimeError('original engine did not stop')
 return pid is not None
