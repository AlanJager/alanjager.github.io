from pathlib import Path
import json,subprocess,shutil,re,time
import sandbox
R=Path(__file__).resolve().parent
COMMANDS={'.py':['python3','-m','pytest'],'.rs':['cargo','test','--','--include-ignored'],'.go':['go','test','./...'],'.js':['/bin/bash','/aider/benchmark/npm-test.sh'],'.cpp':['/bin/bash','/aider/benchmark/cpp-test.sh'],'.java':['/toolchains/gradle-8.7/bin/gradle','--offline','--no-daemon','--console=plain','test']}
def run_tests(original,testdir,history,testfiles):
 testdir=Path(testdir);rel=Path(*testdir.parts[-4:]);commands=[COMMANDS[Path(x).suffix] for x in testfiles if Path(x).suffix in COMMANDS];assert commands
 for fn in testfiles:
  src=Path(original)/rel/fn;dst=testdir/fn
  if src.exists():dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy(src,dst)
  if fn.endswith('.java') and dst.exists():dst.write_text(re.sub(r'@Disabled\([^)]*\)\s*\n','',dst.read_text()))
 idx=len(list(testdir.glob('.test-*.json')));start=time.time()
 try:
  result,sec=sandbox.run(testdir,commands[0]);text=result.stdout;code=result.returncode
 except subprocess.TimeoutExpired as e:
  (testdir/f'.test-{idx:02}.json').write_text(json.dumps({'command':commands[0],'wall_s':time.time()-start,'timeout':True}));raise
 text=re.sub(r'\bin \d+\.\d+s\b','',text).replace(str(testdir),testdir.name)
 (testdir/f'.test-{idx:02}.json').write_text(json.dumps({'command':commands[0],'wall_s':sec,'returncode':code,'timeout':False}));(testdir/f'.test-{idx:02}.log').write_text(text)
 with Path(history).open('a') as f:f.write(f'```\n{text}\n```\n')
 if code:return text or f'Tests exited with code {code}'
