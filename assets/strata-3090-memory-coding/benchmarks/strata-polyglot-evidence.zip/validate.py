from pathlib import Path
import json,hashlib,collections
R=Path(__file__).resolve().parent;D=R/'remote'
read=lambda p:json.loads(p.read_text())
manifest=read(D/'input-manifest.json');audit=read(D/'source-audit.json')
assert audit['changed_tracked_files']==[]
for name in ['run_suite.py','run_experiment.py','order.json','PLAN.md']:
 assert hashlib.sha256((D/name).read_bytes()).hexdigest()==manifest[name],name
for name,sha in audit['archives'].items():
 assert hashlib.sha256((R/name).read_bytes()).hexdigest()==sha,name
order=read(D/'order.json')['formal'];assert len(order)==225 and len(set(order))==225
formal=read(D/'formal/completed.json');assert formal['tasks']==225
assert read(D/'completed.json')['tasks']==225
assert read(D/'exit.json')['code']==0
runtime=read(D/'formal/runtime.json');assert runtime['source_sha256']==manifest['run_suite.py']
assert runtime['summary_method']=='serialized_summary'
refs=read(D/'reference-all.json')
assert len(refs)==225 and all(x['passed'] for x in refs)
assert read(R/'test-integrity.json')['passed'] and read(R/'test-integrity.json')['tasks']==225
allcalls=[];checks=[]
for rel in order:
 p=D/'formal'/rel;d=read(p/'.task.json')
 assert d['id']==rel and d['timing_serial_valid'],rel
 calls=[read(x) for x in sorted(p.glob('.api-*.json'))]
 assert len(calls)==d['api_calls'],rel
 assert abs(sum(x['wall_s'] for x in calls)-d['api_time_s'])<.001,rel
 assert d['api_time_s']+d['test_s']<=d['e2e_s']+.1,rel
 allcalls.extend(calls);checks.append({'id':rel,'first':d['first_pass'],'final':d['final_pass'],'timing':True})
allcalls.sort(key=lambda x:x['start_mono'])
assert all(a['end_mono']<=b['start_mono']+.001 for a,b in zip(allcalls,allcalls[1:])), 'overlapping calls'
assert read(D/'restored.json')['health']['loaded']
out={'passed':True,'tasks':len(checks),'calls':len(allcalls),'source_matches_runtime':True,'timing_serial_valid':True,'request_overlap':False,'first_pass':sum(x['first'] for x in checks),'final_pass':sum(x['final'] for x in checks),'reference_summary':refs,'restored':read(D/'restored.json')}
(R/'validation.json').write_text(json.dumps(out,indent=2));print(json.dumps({k:v for k,v in out.items() if k not in ['reference_summary','restored']}))
