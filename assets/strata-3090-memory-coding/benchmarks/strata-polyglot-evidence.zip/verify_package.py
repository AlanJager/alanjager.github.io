from pathlib import Path
import zipfile,json,hashlib,sys
path=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).with_name('strata-polyglot-evidence.zip')
with zipfile.ZipFile(path) as z:
 inventory=json.loads(z.read('inventory.json'));byname={r['path']:r for r in inventory}
 assert len(byname)==len(inventory)
 for row in inventory:
  assert hashlib.sha256(z.read(row['path'])).hexdigest()==row['package_sha256'],row['path']
 for phase,manifest_name,script in [('formal','input-manifest.json','run_suite.py'),('cpp-control','cpp-control-input-manifest.json','run_suite_cpp.py')]:
  manifest=json.loads(z.read('remote/'+manifest_name));runtime=json.loads(z.read('remote/'+phase+'/runtime.json'))
  assert runtime['source_sha256']==manifest[script]==byname[script]['original_sha256'],phase
 assert json.loads(z.read('validation.json'))['passed']
 assert json.loads(z.read('cpp-control-summary.json'))['validated']
 assert json.loads(z.read('closeout.json'))['slots_idle']
print(json.dumps({'verified':True,'inventory_files':len(inventory),'package_bytes':path.stat().st_size}))
