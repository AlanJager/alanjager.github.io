# Strata 3090 / 64GiB 内存、固定分工与代码修复

固定引擎0.1.43；源码7695859aa13afb248bdb4d36f9b2e95707db079d；引擎SHA256 6cc0dda09c0327810d590c4e15d610e8a7a8f3ab05fcfc7376da77b18054e42e。

capacity：三组各36请求，共108（含人工待评分对话），每组2次独立启动；自动CPU/PCIe分工。fixed：前一轮56请求，0/0.5/1筛选及1024/2048预算；0.5的请求历史较长。matched：新增48请求，0.5与1各3次独立启动，每次相同短预热后两轮相同任务；主要比较依据。

各目录results为逐请求提取，recordings保留实际请求、响应、SSE事件、日志和评分。预热在原记录中单列，不计入以上请求数。诊断采集不混入性能样本；其限制记录在fixed中。examples为前一轮冻结选择的一成一败修复原文，出处见provenance.json。

## 口径

TTFT是首个输出内容延迟，E2E到SSE DONE，decode用引擎字段。前缀缓存关闭。请求期read_bytes与major fault读进程计数。PLE表26.82GiB；CUDA锁页专家补集另16.17GiB。Mlocked只对应本次PLE表，不能视为两者合计。容量组均值与matched中位数分开。

## 复核与复现

1. 可直接读取results.csv、原始*.json与*.grade.json复核，summary中matched含中位数/范围和分轮数据。matched/analyze_matched.py读取同目录remote；将matched/recordings复制或链接为remote后可重算。
2. 真机复测需要Linux、相同模型与引擎、足够主机内存以及独占GPU。此包不含模型。用自己的路径替换/opt/strata-demo；检查服务配置、端口8080/8081和恢复脚本。原脚本会停止空闲的8080服务并在finally中恢复，必须先确认实际服务部署。
3. 将matched中的run_matched.py、support.py、harness.py、cases.json放到同一个新目录。脚本拒绝重复结果目录，保留所有失败。将grade_code.py放到support.code_grade指定的临时路径；root或namespace权限用于unshare -n、setpriv nobody评分。
4. 冻结计划见PLAN.md。固定PLE RAM、18GiB/13432槽、prefill2048/CPU share0、tail0、7workers、MTP4/minP0.5、32K/int8KV。启动顺序0.5/1/1/0.5/0.5/1；每次两轮merge/log/repairA/repairB。每份输入哈希在results中。
5. Python绘图需要matplotlib，中文字体可替换plot_article.py中的font路径。图片数据来自结果与容量记录，无AI生成数据。

公开副本中的内部IP和安装路径已替换。原始证据独立保留。SHA256SUMS.txt校验本包脱敏后文件，input-sha256.json记录原执行输入的哈希，两者用途不同。
