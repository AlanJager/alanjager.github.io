from pathlib import Path
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
R=Path(__file__).resolve().parent
font=str(next(Path('/System/Library/AssetsV2/com_apple_MobileAsset_Font7').glob('*/AssetData/PingFang.ttc')))
font_manager.fontManager.addfont(font)
plt.rcParams.update({'font.family':font_manager.FontProperties(fname=font).get_name(),'font.size':11,'axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'#fcfbf8','axes.facecolor':'#fcfbf8','savefig.facecolor':'#fcfbf8','axes.unicode_minus':False})
colors=['#89979b','#5c97a2','#146d65'];ink='#26343a'
def save(fig,name):
 fig.savefig(R/(name+'.png'),dpi=180,bbox_inches='tight');fig.savefig(R/(name+'.svg'),bbox_inches='tight');plt.close(fig)
fig,axs=plt.subplots(2,1,figsize=(10,5.0),gridspec_kw={'height_ratios':[1.5,1]},layout='constrained')
ax=axs[0];parts=[26.8222189,16.17,63.305-16.2-26.8222189-16.17,16.2];labels=['PLE 全表\n26.82GiB','CPU/PCIe 专家补集\n16.17GiB','预算差额\n约 4.1GiB','MemAvailable\n约 16.2GiB'];cs=['#146d65','#5c97a2','#a7b0ae','#e0e5dd'];left=0
for val,l,c in zip(parts,labels,cs):
 ax.barh(0,val,left=left,color=c,height=.5,edgecolor='white');ax.text(left+val/2,0,l,ha='center',va='center',fontsize=10 if val>6 else 8,color='white' if c in cs[:2] else ink);left+=val
ax.set_xlim(0,64);ax.set_ylim(-.5,.5);ax.set_yticks([]);ax.set_xlabel('主机内存 / GiB');ax.set_title('主机：系统可见 63.3GiB，PLE + 专家补集约 43GiB',loc='left',fontweight='bold',pad=14)
ax=axs[1];ax.barh(0,18,color='#146d65',height=.5);ax.barh(0,6,left=18,color='#dce4e3',height=.5);ax.text(9,0,'GPU 专家缓存 18GiB\n13432 槽',ha='center',va='center',color='white');ax.text(21,0,'其余容量\n其他模型数据 / KV / MTP\n工作缓冲及余量',ha='center',va='center',fontsize=8)
ax.set_xlim(0,24);ax.set_ylim(-.5,.5);ax.set_yticks([]);ax.set_xlabel('显存 / GiB');ax.set_title('GPU：24GiB，独立于上面的主机内存',loc='left',fontweight='bold',pad=12)
fig.suptitle('64GiB RAM 模式的容量预算',x=.02,ha='left',fontsize=17,fontweight='bold');fig.supxlabel('预算示意：MemAvailable 为系统估计可用量，差额包含其他占用及统计口径差异',fontsize=9);save(fig,'memory-budget')
fig,axs=plt.subplots(1,3,figsize=(12,4.0),layout='constrained');names=['32GiB\nmmap','64GiB\nmmap','64GiB\nRAM']
for ax,vals,title,unit in zip(axs,[[30,27.2,110.7],[218.54,209.22,0],[3.35,3.73,3.74]],['修复：decode 吞吐','修复：请求期读盘','4K 提取：TTFT'],['token/s','MB','秒']):
 bars=ax.bar(names,vals,color=colors,width=.6);ax.bar_label(bars,fmt='%.2f' if unit!='token/s' else '%.1f',padding=4);ax.set_ylim(0,max(vals)*1.25);ax.set_ylabel(unit);ax.set_title(title,fontweight='bold');ax.grid(axis='y',alpha=.15);ax.set_axisbelow(True)
fig.suptitle('容量对照：每项 4 次请求的均值',x=.02,ha='left',fontsize=17,fontweight='bold');fig.supxlabel('自动 CPU/PCIe 分工；修复上限 1024 token；保留 OS 文件缓存',fontsize=10);save(fig,'capacity-comparison')
rowsfile=R.parent/'strata-matched-split-20261015/results.json'
if rowsfile.exists():
 rows=json.loads(rowsfile.read_text());fig,axs=plt.subplots(2,2,figsize=(11,7),layout='constrained')
 for ax,task,title in zip(axs.flat,['code_merge','code_log','repair_a','repair_b'],['区间合并','日志汇总','退避修复 A','退避修复 B']):
  for frac,color in [(0.5,colors[1]),(1,colors[2])]:
   for n in range(1,4):
    rr=sorted([r for r in rows if r['group']==('half-' if frac==.5 else 'gpu-')+str(n) and r['task']==task],key=lambda r:r['round'])
    if len(rr)==2:
     offset=(n-2)*.045+(-.09 if frac==.5 else .09)
     ax.plot([1+offset,2+offset],[r['decode_tps'] for r in rr],color=color,alpha=.65,marker='o',linewidth=1.5,label=f'pcie_frac={frac:g}' if n==1 else None)
  ax.set_xticks([1,2],['首轮','第二轮']);ax.set_xlim(.7,2.3);ax.set_ylabel('decode token/s');ax.set_title(title,fontweight='bold');ax.set_ylim(bottom=0);ax.grid(axis='y',alpha=.15);ax.legend(frameon=False,fontsize=9)
 fig.suptitle('相同输入顺序下，三次独立启动的两轮结果',x=.02,ha='left',fontsize=17,fontweight='bold');fig.supxlabel('每条线连接同一次启动的两个请求；PLE RAM / tail=0 / 自适应专家缓存开启',fontsize=10);save(fig,'matched-rounds')
