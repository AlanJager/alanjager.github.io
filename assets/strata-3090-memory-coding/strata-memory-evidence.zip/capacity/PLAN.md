# 3090 内存、调度与质量联合实验

2026-10-15 执行前冻结。用户同意先完成32GiB基线，再由用户从虚拟化平台扩到64GiB；基线完成后通知。原三篇与原始记录保持不动。

## 主问题与三个容量组

1. 32GiB / `--ple-io mmap`。
2. 64GiB / `--ple-io mmap`。
3. 64GiB / `--ple-io ram`；启动日志确认全表驻留成功，失败则保留失败结果。

固定Strata 0.1.43二进制SHA-256 `6cc0dda09c0327810d590c4e15d610e8a7a8f3ab05fcfc7376da77b18054e42e`、原IQ2_XS、3090、16vCPU、prefill2048、7workers、aux auto、MTP4/minP0.5、32K/int8KV、tail0。保留expert-cache auto并核验每组18GiB/13432槽，CPU分担默认自动。关闭prompt/conversation缓存，区分输入重算与权重/文件页缓存。

每容量组2次独立启动，每次1条短预热+2轮相同8题，合计32主请求。原7题包括中文容量两轮对话、工单JSON、合并区间、指数退避、日志聚合、4392-token变更记录；追加原17352-token记录。相同顺序重复。启动后的第一轮标first，第二轮标repeat；OS页缓存不清空，不将first称作冷缓存或完全新题。

指数退避若真实测试失败，将实际失败摘要回传一次，修复请求另计；首次成功不制造虚假错误。所有失败、截断与长尾保留。沿用67/14/10功能测试，大次数零base边界测试本轮预先纳入。对话人工复核，字段提取严格逐字段校验。生成代码在无网络、nobody、AST白名单、CPU/地址空间受限进程运行。

输出TTFT、prefill/decode吞吐、到DONE完整耗时、token数、首次/修复通过、read_bytes、major fault、CPU累计时间、GPU与RAM同时间轴采样。各任务每阶段仅2次，不将小样本p95解释为稳定尾延迟；先给原始点与范围。后续扩充独立任务后再给分位数。

## 32GiB诊断轮

性能轮结束后独立重启，采日志代码与17K输入。tracefs使用本实验独立instance，按engine线程过滤filemap页缓存插入和用户缺页事件，按设备过滤块请求issue/complete。保存文件dev/inode/size、maps、事件格式与丢失计数。按inode归属页缓存插入；该计数不等同物理读盘字节，block事件本身不含文件身份。无证据时不把两者强行逐笔配对。

采样诊断与无trace性能轮分开；不安装系统包、不改驱动、不执行全局drop_caches。Nsight Systems已存在，64GiB数据等待下降后再做CUDA/CPU时间线，避免本轮装载数据淹没诊断目的。

## 后续调度与质量

在64GiB容量对照后，选择驻留成功且稳定的同一配置：固定1024块、CPU share0，只改STRATA_PREFILL_STREAM_MIN测试staged/stream；随后小范围worker/PCIe调度比较。质量扩展题集在运行前冻结，tail0与default按正反序比较。其他量化另列可选扩展，不下载新模型。

## 运行与恢复

仅停止已核对路径且空闲的8080实例；实验服务8081。每组记录实际内存、配置、二进制hash、加载时间。完成或异常后恢复start-optimized-3090.sh，核验health、实际参数与短请求；恢复前清理本实验进程和traceinstance。原始数据另存，公开稿后续脱敏。

完成32GiB后先同步结果到本地，再通知用户可以扩容。用户扩容保持GPU/CPU/磁盘不变，扩容后重新核对硬件与引擎身份再执行后两组。
