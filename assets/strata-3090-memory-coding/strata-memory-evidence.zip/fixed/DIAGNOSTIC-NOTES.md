# 独立诊断执行记录

性能组 half-A、cpu-only、gpu-only、half-B 共56请求按原计划完成；以下调整只影响独立诊断。

1. `diagnostic-failed-auto/`：Nsight增加少量CUDA显存占用，自动专家缓存从13432槽降为13423槽，严格配置检查停止运行，尚未发送计分诊断请求。
2. `diagnostic-half/`：显式指定12796个最大blob的缓存预算，并将预留显存从700调整为680MiB；实际缓存恢复13432槽、18.00GiB。修复与4K请求完成，17K在14336-token进度后停滞超过两分钟，GPU空闲，进程一个线程持续占用CPU，其余主要等待futex。手动终止采集与外层清理重叠，最终未保留可导出的Nsight报告。保留请求、资源采样、线程状态和日志。该现象只在此次带CUDA/OS runtime/CPU回溯采集的诊断中出现；具体原因未定位。
3. `diagnostic-minimal/`：仅采CUDA、NVTX、CPU上下文切换，关闭OS runtime和CPU调用栈采样；任务限定为repair_a2048与4K输入。继续使用与性能组一致的13432槽。修复974-token响应自然结束，耗时17.515秒；4K在第二块第31层停滞，引擎看门狗记录60秒无进展后以-6退出。日志记录专家池24/24任务完成、7/7线程休眠、磁盘等待线程0/24，剩余可用RAM14856MiB。4K响应HTTP200、SSE结束但带server_error且没有正文，计为诊断失败。

最后保留了4.8MB的`timeline.nsys-rep`并成功导出SQLite。采集审计发现：Nsight 2024.6使用CUPTI12.8，明确警告当前CUDA13.0驱动接口不受支持，并警告CUDA事件可能未完整收集。NVTX覆盖完整修复请求（0.064–17.579秒），69170条GPU kernel事件却仅覆盖到3.217秒。因此该报告只保留为不完整的诊断证据，不生成完整请求的GPU空闲/等待占比图。兼容性警告与prefill停滞的因果关系未定位。

最后服务恢复记录为`restored-final.json`，已核验loaded与短生成。性能数据56请求全部保留。

诊断进程树里的无网络评分子进程继承了Nsight注入，两个修复评分最初报`Failed to connect to Agent`。在采集结束后，用普通SSH环境和相同v2沙箱重评原始输出，两份均15/15通过；原评分保留在`grading-under-profiler/`，修订见`diagnostic-regrade.json`。诊断质量仍独立列出，不加入56请求的性能/质量汇总。

所有诊断吞吐量独立保存，不并入性能均值。17K的常规性能请求8/8完成并正确提取五字段，独立诊断的停滞单独记录。

`grade_code.py` 的v2修改与上述诊断调整无关。`grader-process-diagnostics.json` 是对原始生成代码的隔离复跑，CPU限制与原评分一致。
