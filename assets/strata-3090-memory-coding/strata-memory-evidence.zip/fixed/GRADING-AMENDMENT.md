# 评分环境修正

half-A第1轮repair_a2048代码使用except OverflowError，v1沙箱未提供该标准异常名，导致NameError。补充OverflowError及其数值异常基类ArithmeticError、ZeroDivisionError；这些是Python标准异常类，不引入I/O或执行能力。测试用例、期望值、资源限制保持不变。

v1源文件保留grade_code-v1.py。所有已生成结果统一用v2重评分，原grade文件移存各组grading-v1/；生成内容、请求计时不重写。之后生成的评分直接标记grader_revision。修正用于消除评测环境误判，不作模型质量提升证据。
