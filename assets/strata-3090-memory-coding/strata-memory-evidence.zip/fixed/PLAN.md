# 固定专家分工与2048-token修复实验

执行前冻结，2026-10-15。用户授权固定CPU/PCIe分工、将修复输出上限提高到2048，并定位PLE常驻后的剩余瓶颈。

固定64GiB、3090、原Strata0.1.43二进制、IQ2_XS、PLE RAM、18GiB/13432专家槽、7workers、aux auto、tail0、prefill2048、32K/int8 KV、MTP4/minP0.5。显式pcie-frac关闭decode自动调节；STRATA_PREFILL_CPU_SHARE=0固定prefill分工，避免短输入/尾块的CPU自动策略变化。prompt/conversation缓存均关闭。

性能配置顺序：0.5-A → 0 → 1 → 0.5-B。0/1为边界筛选，各一次启动、两轮；0.5重复两次独立启动检查波动。比例作用于未驻留显存的候选专家，受整数取整、源页可用与暂存槽限制；显存命中专家继续在GPU计算。每组两轮：repair_a2048、repair_b2048、合并代码、日志代码、4392/17352-token提取。0.5组增加a/b各1024对照，第一轮1024→2048，第二轮2048→1024。共56性能请求。

repair_a/b直接保存上一轮RAM组第一/第二轮的完整messages，均包含真实失败代码与真实OverflowError；a曾截断，b曾完整通过，选择在本轮执行前完成。所有组输入逐字相同，temperature0、seed20261013、reasoning none。只更改max_tokens来比较输出预算，保留实际文本变化与所有失败。沿用15/67/10项代码测试及长输入五字段检查，生成代码在无网络、nobody、AST白名单、CPU/内存受限进程执行。

独立诊断：使用固定0.5、PLE RAM另启Nsight进程树，模型loaded并预热后再开始采集。请求repair_a2048、4K、17K；客户端NVTX标记请求区间与首字，采CUDA graph node、CUDA API、OS runtime、CPU采样/调度。诊断速度单列，使用kernel/复制区间并集与重叠而非累计时间相加。先用小CUDA程序验证工具可采集，不改引擎二进制/驱动/系统配置。

各组核验实际参数、RAM锁页、专家槽，记录read_bytes/major fault、逐线程CPU、GPU/RAM采样、TTFT/完整耗时/token数/finish_reason/功能测试。0/1端点样本用于筛选，未宣布全局最优。按计划恢复日常mmap服务，health和短生成核验。原始记录另存，公开发布另行处理。
