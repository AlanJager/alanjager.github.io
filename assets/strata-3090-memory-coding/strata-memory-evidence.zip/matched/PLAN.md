# 同请求历史的0.5/1复测

2026-10-15执行前冻结。目标：补齐合并篇中0.5与1分工的同条件比较，并将已有容量与代码案例整理为文章预览。用户已授权继续；不发布。

六次独立启动顺序为0.5、1、1、0.5、0.5、1，两组各三次。每次统一短预热，随后两轮按code_merge、code_log、repair_a、repair_b执行，合计48计分请求。合并上限1024、日志1200、两份修复均2048；所有配置保持相同的请求顺序、输入messages及预算，预算对照另用上轮结果。

固定原64GiB/3090、同一0.1.43二进制和IQ2_XS数据、PLE RAM、18GiB/13432槽、prefill2048、prefill CPU share0、7workers、aux auto、tail0、MTP4/minP0.5、32K/int8KV。prompt/conversation缓存关闭，temperature0、seed20261013、reasoning none。保留自适应专家交换；每次从同一静态expert-profile初始化，记录文件哈希。模型输出变化仍可能带来路由与热度变化。

记录每请求TTFT/E2E、输入输出token、decode吞吐、MTP接受率、VRAM/CPU/PCIe实际路由、read_bytes/major fault、CPU时间和2秒资源采样。沿用修正版沙箱及原15/67/10测试，保留所有错误和截断；不重试失败以替换样本。

按启动分别列两轮结果，再报告每任务每配置6次的中位数、范围和通过数；启动为独立重复单位。不计算p99、不根据一个极值选配置。无Nsight采集、无驱动/模型变更、无OS缓存清理。结束后恢复原日常mmap/auto服务，核验loaded、短生成和idle。
