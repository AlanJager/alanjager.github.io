from pathlib import Path
import json,re,hashlib,csv,statistics,collections
R=Path(__file__).resolve().parent;D=R/'remote';rows=[];incomplete=[]
for group in sorted(D.iterdir()) if D.exists() else []:
 if not group.is_dir() or not (group/'plan.json').exists():continue
 plan=json.loads((group/'plan.json').read_text())
 for p in sorted(group.glob('*.json')):
  if not (p.name.startswith('r1--') or p.name.startswith('r2--') or p.name.startswith('diag--')) or p.name.endswith(('.grade.json','.threads.json')):continue
  d=json.loads(p.read_text())
  if not p.with_suffix('.grade.json').exists() or not d.get('usage') or d.get('ttft') is None:
   assert plan['diagnostic'],('Incomplete performance request',p)
   incomplete.append({'record':str(p.relative_to(D)),'error':d.get('error'),'e2e_s':d.get('e2e'),'finish':d.get('finish_reason'),'sse_done':d.get('sse_done')});continue
  g=json.loads(p.with_suffix('.grade.json').read_text());t=d.get('timings',{});a=d['after'];b=d['before'];complete=d.get('finish_reason')=='stop' and d['sse_done'] and not d['error']
  cid=d['id'].split('--')[1]
  reuse=re.search(r'prompt (\d+) tokens = (\d+) reused',d['engine_log'])
  row={'group':group.name,'frac':plan['frac'],'diagnostic':plan.get('diagnostic',False),'id':d['id'],'task':cid,'limit':d['request']['max_tokens'],'input_sha256':hashlib.sha256(json.dumps(d['request']['messages'],ensure_ascii=False,sort_keys=True).encode()).hexdigest(),'ttft_s':d['ttft'],'e2e_s':d['e2e'],'output_tokens':d['usage']['completion_tokens'],'decode_tps':t.get('predicted_per_second'),'prefill_tps':t.get('prompt_per_second'),'draft_accept_ratio':t.get('draft_n_accepted',0)/t['draft_n'] if t.get('draft_n') else None,'read_MB':(a['io']['read_bytes']-b['io']['read_bytes'])/1e6,'major_faults':a['major_faults']-b['major_faults'],'cpu_core_seconds':(a['cpu_ticks']-b['cpu_ticks'])/100,'complete':complete,'finish':d.get('finish_reason'),'passed':bool(complete and g.get('all_passed')),'tests_passed':g.get('passed'),'tests_total':g.get('total'),'reasoning_characters':len(d['reasoning']),'reused_tokens':int(reuse[2]) if reuse else None,'record':str(p.relative_to(D))}
  m=re.search(r'decode expert cache hit rate: [0-9.]+% \((\d+) hits / (\d+) lookups\)(?:; (\d+) more read by the GPU .*?all (\d+) routed\))?',d['engine_log'])
  if m:
   hits,lookups=int(m[1]),int(m[2]);pcie=int(m[3] or 0);total=int(m[4] or lookups)
   row.update(vram_hits=hits,pcie_routed=pcie,cpu_routed=lookups-hits,total_routed=total,vram_fraction=hits/total if total else None,pcie_fraction_of_misses=pcie/(total-hits) if total>hits else None)
  rows.append(row)
(R/'results.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
(R/'incomplete-diagnostic-requests.json').write_text(json.dumps(incomplete,ensure_ascii=False,indent=2))
if rows:
 with (R/'results.csv').open('w') as f:w=csv.DictWriter(f,fieldnames=list(dict.fromkeys(k for r in rows for k in r)));w.writeheader();w.writerows(rows)
summary=[]
for key in sorted(set((r['frac'],r['task'],r['limit']) for r in rows if not r['diagnostic'])):
 rr=[r for r in rows if not r['diagnostic'] and (r['frac'],r['task'],r['limit'])==key];s=dict(zip(['frac','task','limit'],key));s.update(n=len(rr),complete=sum(r['complete'] for r in rr),passed=sum(r['passed'] for r in rr),input_identities=len(set(r['input_sha256'] for r in rr)))
 for k in ['ttft_s','e2e_s','decode_tps','prefill_tps','read_MB','major_faults','cpu_core_seconds','output_tokens','draft_accept_ratio']:
  v=[r[k] for r in rr if r[k] is not None];s[k]={'mean':statistics.mean(v),'min':min(v),'max':max(v)} if v else None
 summary.append(s)
(R/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
lines=['# 固定分工性能汇总','','| PCIe候选比例 | 任务 | 上限 | n | TTFT均值/s | 完整耗时均值/s | decode均值 token/s | 读盘MB均值 | 完整通过 |','|---|---|---:|---:|---:|---:|---:|---:|---:|']
for s in summary:lines.append(f"| {s['frac']} | {s['task']} | {s['limit']} | {s['n']} | {s['ttft_s']['mean']:.2f} | {s['e2e_s']['mean']:.2f} | {s['decode_tps']['mean']:.1f} | {s['read_MB']['mean']:.2f} | {s['passed']}/{s['n']} |")
(R/'SUMMARY.md').write_text('\n'.join(lines)+'\n')
print(json.dumps({'performance':sum(not x['diagnostic'] for x in rows),'diagnostic':sum(x['diagnostic'] for x in rows),'passed':sum(x['passed'] for x in rows)}))
for s in summary:
 if s['task'].startswith('repair'):print(s['frac'],s['task'],s['limit'],s['passed'],s['n'],'tps',round(s['decode_tps']['mean'],1),'seconds',round(s['e2e_s']['mean'],2))

for r in rows:
 r['round']=int(r['id'][1]);r['cpu_equiv_cores']=r['cpu_core_seconds']/r['e2e_s']
 r['output_sha256']=hashlib.sha256((D/r['record']).with_suffix('.txt').read_bytes()).hexdigest()
for s in summary:
 rr=[r for r in rows if (r['frac'],r['task'],r['limit'])==(s['frac'],s['task'],s['limit'])]
 for k in ['ttft_s','e2e_s','decode_tps','cpu_equiv_cores','vram_fraction','pcie_fraction_of_misses','draft_accept_ratio','output_tokens']:
  vv=[r[k] for r in rr if r.get(k) is not None]
  s[k]={'median':statistics.median(vv),'min':min(vv),'max':max(vv),'mean':statistics.mean(vv)}
 s['rounds']={str(i):{'decode_median':statistics.median([r['decode_tps'] for r in rr if r['round']==i]),'e2e_median':statistics.median([r['e2e_s'] for r in rr if r['round']==i])} for i in [1,2]}
(R/'results.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
(R/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
with (R/'results.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(dict.fromkeys(k for r in rows for k in r)));w.writeheader();w.writerows(rows)
