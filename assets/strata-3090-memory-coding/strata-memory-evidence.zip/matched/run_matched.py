#!/usr/bin/env python3
from pathlib import Path
import os,json,hashlib,time,threading,subprocess,fcntl,signal
import support as s
import harness as h
R=Path(__file__).resolve().parent;REPO=s.REPO;N='/usr/local/cuda/bin/nsys'
def save(p,x):s.save(p,x)
def cpu_threads(pid):
 d={}
 for p in Path('/proc',str(pid),'task').iterdir():
  try:
   st=(p/'stat').read_text().rsplit(') ',1)[1].split();d[p.name]={'ticks':int(st[11])+int(st[12]),'cpu':int(st[36]),'comm':(p/'comm').read_text().strip()}
  except OSError:pass
 return d
def env():
 e=os.environ.copy()
 for k in list(e):
  if k.startswith('STRATA_PREFILL_'):e.pop(k)
 e.update(STRATA_ROUTE_TAIL_SKIP='0',STRATA_PREFILL_CPU_SHARE='0');return e
def config(base,out,frac):
 c=json.loads(json.dumps(base));c.update(port=8081,log=str(out/'engine.log'),open_browser=False)
 for flag,value in {'--ple-io':'ram','--pcie-frac':str(frac),'--prompt-cache':'0','--conversation-cache-mib':'0'}.items():
  if flag in c['args']:c['args'][c['args'].index(flag)+1]=value
  else:c['args'] += [flag,value]
 save(out/'config.json',c);return c
def validate(p,out,t):
 v=s.loaded(p,8081);pid=h.child(p.pid);assert pid
 log=(out/'engine.log').read_text();assert 'PLE table locked in RAM' in log and '13432 slots, 18.00 GiB' in log
 e={'health':v,'pid':pid,'load_seconds':time.monotonic()-t,'memory':s.meminfo(),'cmdline':Path('/proc',str(pid),'cmdline').read_text().replace('\0',' '),'strata_env':[x for x in Path('/proc',str(pid),'environ').read_text().split('\0') if x.startswith('STRATA_')],'expert_profile_sha256':hashlib.sha256((REPO/'data/expert-profile.bin').read_bytes()).hexdigest(),'engine_sha256':hashlib.sha256((REPO/'engine/strata').read_bytes()).hexdigest()};assert e['engine_sha256']==s.ENGINE_SHA;assert e['memory']['Mlocked']>26*1024**3
 save(out/'environment.json',e);return pid
def request(c,out,pid):
 before=cpu_threads(pid);rec=h.request(c,c['messages'],out,pid,out/'engine.log');after=cpu_threads(pid)
 save(out/(c['id']+'.threads.json'),{'before':before,'after':after});g=s.grade(rec);save(out/(c['id']+'.grade.json'),g)
 assert rec.get('sse_done') and rec.get('http_status')==200 and not rec.get('error'),c['id']
 import re
 m=re.search(r'prompt (\d+) tokens = (\d+) reused',rec['engine_log']);assert m and int(m[2])==0
 print(json.dumps({'id':c['id'],'grade':g.get('all_passed'),'finish':rec.get('finish_reason'),'read_MB':(rec['after']['io']['read_bytes']-rec['before']['io']['read_bytes'])/1e6}),flush=True);return rec
def performance(base,name,frac,cases):
 out=R/name;out.mkdir();config(base,out,frac);save(out/'plan.json',{'name':name,'frac':frac,'diagnostic':False,'rounds':2})
 f=(out/'server.out').open('w');p=None;stop=threading.Event();sampler=None
 try:
  t=time.monotonic();p=subprocess.Popen([str(REPO/'.venv/bin/python'),str(REPO/'serve/server.py'),'--engine','strata','--config',str(out/'config.json'),'--port','8081'],cwd=REPO,env=env(),stdout=f,stderr=subprocess.STDOUT,start_new_session=True);print(name+' loading',flush=True);pid=validate(p,out,t)
  sampler=threading.Thread(target=h.sample,args=(out/'resources.jsonl',pid,stop),daemon=True);sampler.start();h.request({'id':'warmup','max_tokens':16},[{'role':'user','content':'只回答：就绪'}],out,pid,out/'engine.log')
  for ri in [1,2]:
   order=[]
   for c in cases:
    limits=[c['max_tokens']]
    for limit in limits:order.append(dict(c,id=f'r{ri}--{c["id"]}--{limit}',max_tokens=limit))
   for c in order:request(c,out,pid)
  assert 'strata serve: PCIe share:' not in (out/'engine.log').read_text(),'automatic fraction changed'
  save(out/'completed.json',{'status':'complete','utc':h.stamp()})
 finally:
  stop.set()
  if sampler:sampler.join(5)
  h.stop_server(p);f.close()
def main():
 def terminate(signum,frame):raise SystemExit(128+signum)
 signal.signal(signal.SIGTERM,terminate)
 lock=(R/'run.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);assert 62<s.meminfo()['MemTotal']/1024**3<66
 assert hashlib.sha256((REPO/'engine/strata').read_bytes()).hexdigest()==s.ENGINE_SHA
 base=json.loads((REPO/'strata-iq2_xs.json').read_text());cases=json.loads((R/'cases.json').read_text())['cases'];save(R/'preflight.json',{'memory':s.meminfo(),'base':base,'utc':h.stamp(),'lscpu':subprocess.check_output(['lscpu'],text=True),'gpu':subprocess.check_output(['nvidia-smi','--query-gpu=name,memory.total,driver_version','--format=csv,noheader'],text=True),'profile_sha256':hashlib.sha256((REPO/'data/expert-profile.bin').read_bytes()).hexdigest()});restore=s.stop_existing();assert restore,'expected idle daily service'
 try:
  for name,frac in [('half-1',.5),('gpu-1',1),('gpu-2',1),('half-2',.5),('half-3',.5),('gpu-3',1)]:performance(base,name,frac,cases)
  save(R/'completed.json',{'utc':h.stamp(),'performance_requests':48})
 finally:
  f=(R/'restored-server.out').open('a');p=subprocess.Popen([str(REPO/'start-optimized-3090.sh')],cwd=REPO,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);v=s.loaded(p,8080);pid=h.child(p.pid);(REPO/'optimized-service.pid').write_text(str(p.pid)+'\n');h.URL='http://127.0.0.1:8080';rec=h.request({'id':'restoration-smoke','max_tokens':32},[{'role':'user','content':'只回答：服务已恢复'}],R,pid,Path(base['log']));assert rec['sse_done'] and rec['finish_reason']=='stop';save(R/'restored.json',{'health':v,'pid':pid,'utc':h.stamp(),'cmdline':Path('/proc',str(pid),'cmdline').read_text().replace('\0',' ')});print('Daily service restored and verified',flush=True)
if __name__=='__main__':main()
