#!/usr/bin/env python3
import argparse,datetime,fcntl,hashlib,json,os,re,signal,subprocess,threading,time,urllib.request
from pathlib import Path
import harness as h
ROOT=Path(__file__).resolve().parent
REPO=Path('/opt/strata-demo/Strata')
ENGINE_SHA='6cc0dda09c0327810d590c4e15d610e8a7a8f3ab05fcfc7376da77b18054e42e'
EXPECTED={'cancelled_id':'R017','cancelled_owner':'林青','cancel_reason':'容量评估未通过','approved_id':'R089','rollback_threshold':'错误率超过2%'}
def save(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2))
def meminfo():return {k:int(v.strip().split()[0])*1024 for k,v in (s.split(':') for s in Path('/proc/meminfo').read_text().splitlines()) if k in ['MemTotal','MemAvailable','Mlocked','SwapTotal']}
def health(port):
 with urllib.request.urlopen(f'http://127.0.0.1:{port}/health',timeout=3) as r:return json.load(r)
def loaded(p,port):
 for _ in range(450):
  if p.poll() is not None:raise RuntimeError('service exited '+str(p.returncode))
  try:
   v=health(port)
   if v.get('loaded'):return v
  except Exception:pass
  time.sleep(2)
 raise RuntimeError('model load timeout')
def code_grade(rec):
 cmd=['unshare','-n','setpriv','--reuid=65534','--regid=65534','--clear-groups','python3','-I','/tmp/strata-matched-grade-20261015.py','-','--exploratory']
 try:
  r=subprocess.run(cmd,input=json.dumps(rec),capture_output=True,text=True,timeout=12)
  return json.loads(r.stdout) if r.returncode==0 else {'all_passed':False,'grader_error':r.stderr[-2500:],'grader_returncode':r.returncode}
 except Exception as e:return {'all_passed':False,'grader_error':repr(e)}
def grade(rec):
 cid=rec.get('case_id',rec['id'])
 if cid in ['code_merge','code_retry','code_log']:return code_grade(rec)
 if cid.startswith('long_read'):
  try:
   value=json.loads(re.sub(r'^```(?:json)?\s*|\s*```$','',rec['content'].strip()));n=sum(value.get(k)==v for k,v in EXPECTED.items());return {'passed':n,'total':5,'all_passed':value==EXPECTED,'parsed':value}
  except Exception as e:return {'all_passed':False,'grader_error':repr(e)}
 return {'manual_review_required':True}
def mappings(pid,out):
 for item in ['maps','smaps_rollup']:
  try:(out/item).write_text((Path('/proc')/str(pid)/item).read_text())
  except OSError:pass
 files={}
 for line in (Path('/proc')/str(pid)/'maps').read_text().splitlines():
  parts=line.split(None,5)
  if len(parts)==6 and parts[-1].startswith('/'):
   p=Path(parts[-1]);
   try:
    s=p.stat();files[str(p)]={'inode':s.st_ino,'dev_major':os.major(s.st_dev),'dev_minor':os.minor(s.st_dev),'size':s.st_size}
   except OSError:pass
 save(out/'mapped-files.json',files)
class FileTrace:
 def __init__(self,pid,out):self.pid=pid;self.out=out;self.path=Path('/sys/kernel/tracing/instances')/('strata_mem_'+str(os.getpid()));self.active=False
 def start(self):
  self.path.mkdir();(self.path/'tracing_on').write_text('0');(self.path/'buffer_size_kb').write_text('8192');(self.path/'trace_clock').write_text('mono')
  tasks=[int(x.name) for x in (Path('/proc')/str(self.pid)/'task').iterdir()];fil=' || '.join('common_pid == '+str(x) for x in tasks)
  events=['filemap/mm_filemap_add_to_page_cache','exceptions/page_fault_user','block/block_rq_issue','block/block_rq_complete']
  for name in events:
   p=self.path/'events'/name
   if not p.exists():continue
   if name.startswith(('filemap/','exceptions/')):(p/'filter').write_text(fil)
   else:
    s=REPO.stat();major,minor=os.major(s.st_dev),os.minor(s.st_dev)
    sysdev=Path(f'/sys/dev/block/{major}:{minor}').resolve()
    if (sysdev/'partition').exists():major,minor=map(int,(sysdev.parent/'dev').read_text().strip().split(':'))
    dev=(major<<20)|minor;(p/'filter').write_text('dev == '+str(dev))
   (self.out/(name.replace('/','-')+'.format')).write_text((p/'format').read_text());(p/'enable').write_text('1')
  save(self.out/'trace-clock.json',{'time':time.time(),'monotonic':time.monotonic(),'tids':tasks,'scope':'filemap/fault current engine tids; block whole target device'})
  (self.path/'tracing_on').write_text('1');self.active=True
 def stop(self):
  if not self.path.exists():return
  (self.path/'tracing_on').write_text('0')
  (self.out/'kernel-trace.txt').write_text((self.path/'trace').read_text());stats={}
  for p in (self.path/'per_cpu').glob('cpu*/stats'):stats[p.parent.name]=p.read_text()
  save(self.out/'trace-buffer-stats.json',stats);(self.path/'events/enable').write_text('0');self.path.rmdir();self.active=False
def stop_existing():
 pid=None
 for line in subprocess.check_output(['ps','-eo','pid,args'],text=True).splitlines():
  if str(REPO/'serve/server.py') in line and '--port 8080' in line:
   if pid is not None:raise RuntimeError('multiple original services')
   pid=int(line.strip().split()[0])
 if pid:
  with urllib.request.urlopen('http://127.0.0.1:8080/slots',timeout=5) as r:assert not any(x.get('is_processing') for x in json.load(r)), 'original service busy'
  cp=h.child(pid);save(ROOT/'original-process.json',{'pid':pid,'engine_pid':cp,'command':Path('/proc',str(pid),'cmdline').read_text().replace('\0',' ')})
  for n in [pid,cp]:
   if n:
    try:os.kill(n,signal.SIGTERM)
    except ProcessLookupError:pass
  for _ in range(30):
   if not cp or not Path('/proc',str(cp)).exists():break
   time.sleep(1)
  else:raise RuntimeError('original engine did not stop')
 return pid is not None
def run_group(arm,block,mode,base,cases,diagnostic=False):
 name=f'{arm}-'+('diagnostic' if diagnostic else f'block{block}');out=ROOT/name;out.mkdir();cfg=json.loads(json.dumps(base));cfg['port']=8081;cfg['log']=str(out/'engine.log');cfg['open_browser']=False
 for flag,value in {'--ple-io':mode,'--prompt-cache':'0','--conversation-cache-mib':'0'}.items():
  if flag in cfg['args']:cfg['args'][cfg['args'].index(flag)+1]=value
  else:cfg['args'] += [flag,value]
 save(out/'config.json',cfg);env=os.environ.copy()
 for k in list(env):
  if k.startswith('STRATA_PREFILL_'):env.pop(k)
 env['STRATA_ROUTE_TAIL_SKIP']='0';save(out/'plan.json',{'arm':arm,'block':block,'ple_io':mode,'diagnostic':diagnostic,'rounds':1 if diagnostic else 2,'cases':[x['id'] for x in cases],'tail':0})
 f=(out/'server.out').open('w');p=None;stop=threading.Event();sampler=None;trace=None
 try:
  started=time.monotonic();p=subprocess.Popen([str(REPO/'.venv/bin/python'),str(REPO/'serve/server.py'),'--engine','strata','--config',str(out/'config.json'),'--port','8081'],cwd=REPO,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
  print(json.dumps({'group':name,'status':'loading'}),flush=True);v=loaded(p,8081);pid=h.child(p.pid);assert pid
  environment={'health':v,'engine_pid':pid,'memory':meminfo(),'load_seconds':time.monotonic()-started,'engine_sha256':hashlib.sha256((REPO/'engine/strata').read_bytes()).hexdigest(),'args':Path('/proc',str(pid),'cmdline').read_text().replace('\0',' '),'clock_ticks':os.sysconf('SC_CLK_TCK'),'utc':h.stamp()};assert environment['engine_sha256']==ENGINE_SHA
  save(out/'environment.json',environment);mappings(pid,out)
  log=(out/'engine.log').read_text();assert '13432' in log or '13,432' in log, 'expert slot capacity changed'
  if mode=='ram':assert 'PLE table locked in RAM' in log, 'PLE RAM lock not confirmed'
  sampler=threading.Thread(target=h.sample,args=(out/'resources.jsonl',pid,stop),daemon=True);sampler.start()
  warm={'id':'warmup','prompt':'只回答：就绪','max_tokens':16};h.request(warm,[{'role':'user','content':warm['prompt']}],out,pid,out/'engine.log')
  if diagnostic:trace=FileTrace(pid,out);trace.start()
  for ri in range(1 if diagnostic else 2):
   sessions={}
   for original in cases:
    case=dict(original,case_id=original['id'],id=f'r{ri+1}--'+original['id']);key=case.get('session');msgs=sessions.get(key,[])+[{'role':'user','content':case['prompt']}]
    rec=h.request(case,msgs,out,pid,out/'engine.log');g=grade(rec);save(out/(case['id']+'.grade.json'),g)
    if key:sessions[key]=msgs+[{'role':'assistant','content':rec['content']}]
    if rec['error'] or not rec['sse_done']:raise RuntimeError('transport failure: '+case['id'])
    reuse=re.search(r'prompt (\d+) tokens = (\d+) reused',rec['engine_log']);assert reuse and int(reuse.group(2))==0, 'prompt reuse detected'
    print(json.dumps({'group':name,'case':case['id'],'grade':g.get('all_passed'),'read_mb':(rec['after']['io']['read_bytes']-rec['before']['io']['read_bytes'])/1e6,'ttft':rec['ttft'],'e2e':rec['e2e']},ensure_ascii=False),flush=True)
    if original['id']=='code_retry' and not g.get('all_passed'):
     fail=[x for x in g.get('tests',[]) if not x['passed']];feedback='以下是你的代码实际运行的失败结果，请修复，保持原函数签名与题目规则，只输出Python代码块：\n'+json.dumps(fail or {'grader_error':g.get('grader_error')},ensure_ascii=False)[:1800]
     fix=dict(case,id=f'r{ri+1}--code_retry_fix');rr=h.request(fix,msgs+[{'role':'assistant','content':rec['content']},{'role':'user','content':feedback}],out,pid,out/'engine.log');save(out/(fix['id']+'.grade.json'),grade(rr))
  save(out/'completed.json',{'utc':h.stamp(),'status':'complete'})
 finally:
  if trace:trace.stop()
  stop.set()
  if sampler:sampler.join(5)
  h.stop_server(p);f.close()
def main():
 a=argparse.ArgumentParser();a.add_argument('--arm',required=True,choices=['32g-mmap','64g-mmap','64g-ram']);a.add_argument('--diagnostic',action='store_true');args=a.parse_args();lock=(ROOT/'run.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 mem=meminfo();expected=32 if args.arm.startswith('32') else 64;assert expected-2<mem['MemTotal']/1024**3<expected+2,mem
 assert hashlib.sha256((REPO/'engine/strata').read_bytes()).hexdigest()==ENGINE_SHA
 base=json.loads((REPO/'strata-iq2_xs.json').read_text());save(ROOT/(args.arm+'-preflight.json'),{'memory':mem,'original_config':base,'utc':h.stamp(),'gpu':subprocess.check_output(['nvidia-smi','--query-gpu=name,memory.total,driver_version','--format=csv,noheader'],text=True),'lscpu':subprocess.check_output(['lscpu'],text=True)})
 cases=json.loads((ROOT/'cases.json').read_text())['cases'];restorable=stop_existing();p=None
 try:
  for b in [1,2]:run_group(args.arm,b,'ram' if args.arm.endswith('-ram') else 'mmap',base,cases)
  if args.diagnostic:run_group(args.arm,0,'mmap',base,[c for c in cases if c['id'] in ['code_log','long_read_16k']],True)
  save(ROOT/(args.arm+'-completed.json'),{'status':'complete','utc':h.stamp()})
 finally:
  if restorable:
   f=(ROOT/(args.arm+'-restored-server.out')).open('a');p=subprocess.Popen([str(REPO/'start-optimized-3090.sh')],cwd=REPO,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);v=loaded(p,8080);pid=h.child(p.pid);(REPO/'optimized-service.pid').write_text(str(p.pid)+'\n');h.URL='http://127.0.0.1:8080';case={'id':args.arm+'-restoration-smoke','max_tokens':32};rec=h.request(case,[{'role':'user','content':'只回答：服务已恢复'}],ROOT,pid,Path(base['log']));assert rec['sse_done'] and rec.get('finish_reason')=='stop';save(ROOT/(args.arm+'-restored.json'),{'health':v,'server_pid':p.pid,'engine_pid':pid,'utc':h.stamp(),'cmdline':Path('/proc',str(pid),'cmdline').read_text().replace('\0',' '),'strata_env':[x for x in Path('/proc',str(pid),'environ').read_text().split('\0') if x.startswith('STRATA_')]});print('Original optimized service restored and smoke verified',flush=True)
if __name__=='__main__':main()
