from pathlib import Path
import json,hashlib,collections
R=Path(__file__).resolve().parent;D=R/'remote';rows=json.loads((R/'results.json').read_text());assert len(rows)==48,len(rows)
expected=['half-1','gpu-1','gpu-2','half-2','half-3','gpu-3'];profiles=set();engines=set();detail=[]
cases=json.loads((R/'cases.json').read_text())['cases'];h=lambda x:hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True).encode()).hexdigest()
for name in expected:
 rr=[r for r in rows if r['group']==name];assert len(rr)==8
 directory=D/name;e=json.loads((directory/'environment.json').read_text());profiles.add(e['expert_profile_sha256']);engines.add(e['engine_sha256']);assert e['health']['loaded'];assert e['memory']['Mlocked']==28800139264
 config=json.loads((directory/'config.json').read_text());args=config['args'];assert args[args.index('--pcie-frac')+1] in ['0.5','1','1.0']
 assert args[args.index('--ple-io')+1]=='ram';assert args[args.index('--prefill')+1]=='2048';assert args[args.index('--pool-workers')+1]=='7';assert args[args.index('--prompt-cache')+1]=='0';assert args[args.index('--conversation-cache-mib')+1]=='0'
 assert 'STRATA_ROUTE_TAIL_SKIP=0' in e['strata_env'];assert 'STRATA_PREFILL_CPU_SHARE=0' in e['strata_env']
 log=(directory/'engine.log').read_text();assert 'PLE table locked in RAM' in log;assert '13432 of 13432 slots' in log
 times=[]
 for n in [1,2]:
  for c in cases:
   key=f"r{n}--{c['id']}--{c['max_tokens']}";record=json.loads((directory/(key+'.json')).read_text());row=next(r for r in rr if r['id']==key)
   assert h(record['request']['messages'])==h(c['messages']);assert record['request']['max_tokens']==c['max_tokens'];assert record['http_status']==200;assert record['sse_done'];assert record['error'] is None;assert row['reused_tokens']==0;assert row['read_MB']==0;assert row['major_faults']==0
   assert record['request']['temperature']==0;assert record['request']['seed']==20261013;assert record['request']['reasoning_effort']=='none';times.append(record['time'])
 assert times==sorted(times)
 detail.append({'group':name,'frac':rr[0]['frac'],'requests':len(rr),'load_seconds':e['load_seconds'],'available_GiB':e['memory']['MemAvailable']/2**30,'passed':sum(r['passed'] for r in rr),'natural_stop':sum(r['complete'] for r in rr)})
assert len(profiles)==1;assert len(engines)==1
assert all(len({r['input_sha256'] for r in rows if r['task']==c['id']})==1 for c in cases)
assert len({r['output_sha256'] for r in rows if r['task']=='code_merge'})==1
out={'requests':48,'independent_starts_per_config':3,'same_messages_by_task':True,'same_order_and_budget':True,'same_profile_sha256':next(iter(profiles)),'same_engine_sha256':next(iter(engines)),'all_http200_done':True,'all_zero_read_and_majorfault':True,'all_zero_prefix_reuse':True,'merge_output_identical':True,'groups':detail,'finish_counts':dict(collections.Counter(r['finish'] for r in rows)),'cpu_ticks_per_second':100}
(R/'validation.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print(json.dumps(out,ensure_ascii=False,indent=2))
