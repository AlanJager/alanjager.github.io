# RTX 3090 Prefill 对照（2026-10-14）

本目录为独立新增实验，原 10 月 13 日数据保留不动。

固定同一 4392-token 变更记录、Qwen3.8-Flash-Next IQ2_XS、7 workers、aux auto、MTP 4 / minP 0.5、32K / int8 KV、尾部跳过关闭。请求温度0、seed20261013、reasoning none，输出上限384 token。

- A：256，默认自动 CPU 分担（不设置 STRATA_PREFILL_CPU_SHARE）。
- B：256，STRATA_PREFILL_CPU_SHARE=0。
- C：1024，STRATA_PREFILL_CPU_SHARE=0。
- D：2048，STRATA_PREFILL_CPU_SHARE=0。
- 执行顺序 A B C D D C B A，各进程完整预热2次、正式测量3次；共24个正式请求和16个预热。
- 所有组均设置 --prompt-cache 0 / --conversation-cache-mib 0；日志逐条检查4392 read和0 reused。

CPU分担开关针对prefill，decode继续使用自己的CPU/GPU策略。A保持默认auto，允许引擎逐层试探；关闭组将这部分专家工作交给GPU。B到C同时包含分块和流式搬运切换；C到D完整块使用同一流式路径，末尾小块仍为staged，但CPU分担统一关闭。

## 文件

- PLAN.md / matrix.json：执行前冻结的方案。
- run_matrix.py：远端执行脚本，最后恢复原 optimized launcher。
- cases.json / cases.sha256：原任务与摘要。
- remote/：原始请求、SSE、日志、配置和资源采样。
- analyze.py：校验五字段、提取TTFT和吞吐、进程I/O、CPU累计时间。
- results.csv / results.json / summary.json：逐请求与按配置汇总。
- plot.py / prefill-ablation.png：图表源与结果。

TTFT是请求发出到首个非空content；引擎prefill时间来自日志并涵盖其prompt阶段。CPU累计时间是整个请求的所有线程之和，含prefill和decode，不能视为CPU专家独占时间。RAM blob lookup为相邻请求之间累计RAM专家访问计数之差，含两阶段；它不是唯一专家数量，也不是PCIe字节计数。

模型重载不计请求，完整输入预热单列，不执行全局drop_caches。相同输入的重复是有状态服务中的连续请求，专家自适应交换保持默认；同时报告正序/反序区块及单次点。

## 补充观测

首轮四组完成后，给全部反序区块补充 `nvidia-smi dmon -s t -d 1 -o DT` 的 PCIe 活动采样，保存在 `pcie-reverse.log`。远端时间为 UTC+08:00；请求 JSON 的 time 为 Unix 秒。它属于低频设备速率采样，保留原记录供观察活动，未用于计算专家搬运总字节量。正式计时与判分方案保持不变。
