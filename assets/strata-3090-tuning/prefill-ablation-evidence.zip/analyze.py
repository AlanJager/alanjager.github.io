from pathlib import Path
import json,re,csv,statistics,hashlib
P=Path(__file__).parent
expected={'cancelled_id':'R017','cancelled_owner':'林青','cancel_reason':'容量评估未通过','approved_id':'R089','rollback_threshold':'错误率超过2%'}
rows=[]
for g in sorted((P/'remote').glob('*')):
 if not (g/'plan.json').exists():continue
 plan=json.loads((g/'plan.json').read_text())
 previous_ram=None
 records=[]
 for ff in g.glob('*.json'):
  candidate=json.loads(ff.read_text())
  if 'e2e' in candidate:records.append((ff,candidate))
 for f,r in sorted(records,key=lambda x:x[1]['time']):
  r=json.loads(f.read_text())
  if 'e2e' not in r:continue
  m=re.search(r'prompt (\d+) tokens = (\d+) reused \+ (\d+) read in ([\d.]+) ms \(([\d.]+) tok/s\), (\d+) generated in ([\d.]+) ms \(([\d.]+) tok/s\)',r['engine_log'])
  content=r['content'].strip();bare=True
  if content.startswith('```'):
   bare=False;content=re.sub(r'^```(?:json)?\s*|\s*```$','',content)
  try:answer=json.loads(content)
  except Exception:answer={}
  passed=sum(answer.get(k)==v for k,v in expected.items())
  before,after=r['before'],r['after']
  row={'group':g.name,'chunk':plan['args']['--prefill'],'share':plan['share'],'phase':'warmup' if r['id'].startswith('warmup') else 'measured','id':r['id'],'ttft_s':r['ttft'],'e2e_s':r['e2e'],'io_MB':(after['io']['read_bytes']-before['io']['read_bytes'])/1e6,'major_faults':after['major_faults']-before['major_faults'],'cpu_seconds':(after['cpu_ticks']-before['cpu_ticks'])/100,'fields_correct':passed,'bare_json':bare,'finish':r.get('finish_reason'),'sse_done':r['sse_done'],'error':r['error'],'content_sha256':hashlib.sha256(r['content'].encode()).hexdigest()}
  ram=re.search(r'since the start RAM (\d+) blobs',r['engine_log'])
  if ram:
   count=int(ram.group(1));row['ram_blob_lookups']=count-previous_ram if previous_ram is not None else None;previous_ram=count
  if m:row.update(dict(zip(['prompt_tokens','reused_tokens','read_tokens','prefill_ms','prefill_tps','output_tokens','decode_ms','decode_tps'],map(float,m.groups()))))
  rows.append(row)
(P/'results.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
if rows:
 keys=list(dict.fromkeys(k for r in rows for k in r))
 with (P/'results.csv').open('w') as f:
  w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(rows)
summary=[]
for chunk,share in [(256,'auto'),(256,'off'),(1024,'off'),(2048,'off')]:
 rr=[r for r in rows if r['phase']=='measured' and r['chunk']==chunk and r['share']==share]
 if not rr:continue
 x={'chunk':chunk,'share':share,'n':len(rr),'fields_all_correct':sum(r['fields_correct']==5 for r in rr),'zero_reuse':all(r.get('reused_tokens')==0 and r.get('read_tokens')==4392 for r in rr)}
 for k in ['ttft_s','prefill_ms','prefill_tps','io_MB','cpu_seconds','e2e_s']:
  vv=[r[k] for r in rr if k in r];x[k]={'mean':statistics.mean(vv),'median':statistics.median(vv),'min':min(vv),'max':max(vv)}
 x['blocks']=[{'group':g,'ttft_mean':statistics.mean(r['ttft_s'] for r in rr if r['group']==g),'io_MB_max':max(r['io_MB'] for r in rr if r['group']==g)} for g in sorted(set(r['group'] for r in rr))]
 summary.append(x)
(P/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
print(json.dumps(summary,ensure_ascii=False,indent=2))
