import subprocess,time
from pathlib import Path
root=Path('/opt/strata-demo/prefill-ablation-20261014')
f=(root/'pcie-reverse.log').open('w')
p=subprocess.Popen(['nvidia-smi','dmon','-s','t','-d','1','-o','DT'],stdout=f,stderr=subprocess.STDOUT)
try:
 while Path('/proc/1936928').exists():time.sleep(5)
finally:
 p.terminate();p.wait();f.close()
