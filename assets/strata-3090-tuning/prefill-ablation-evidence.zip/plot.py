from pathlib import Path
import json,statistics
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
P=Path(__file__).parent
rows=[r for r in json.loads((P/'results.json').read_text()) if r['phase']=='measured']
plt.rcParams.update({'font.family':'Arial Unicode MS','font.size':11,'axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'#fcfbf8','axes.facecolor':'#fcfbf8'})
groups=[(256,'auto'),(256,'off'),(1024,'off'),(2048,'off')]
labels=['256\n自动分担','256\n关闭分担','1024\n关闭分担','2048\n关闭分担']
fig,axs=plt.subplots(1,2,figsize=(12,5.6),gridspec_kw={'width_ratios':[1.5,1]})
for ax,key,title in [(axs[0],'ttft_s','TTFT（秒）'),(axs[1],'cpu_seconds','请求期间 CPU 累计运行时间（秒）')]:
 for i,(chunk,share) in enumerate(groups):
  rr=[r for r in rows if (r['chunk'],r['share'])==(chunk,share)]
  if not rr:continue
  avg=statistics.mean(r[key] for r in rr)
  ax.bar(i,avg,color=['#cd9562','#5b9094','#3b7583','#225763'][i],width=.55,alpha=.8,zorder=2)
  for j,r in enumerate(rr):ax.scatter(i+(j-2.5)*.055,r[key],color='#27353a',marker='o' if int(r['group'][:2])<5 else 'x',s=23,zorder=3)
  ax.text(i,max(r[key] for r in rr)+max(r[key] for r in rows)*.035,f'均值 {avg:.2f}',ha='center',fontweight='bold',fontsize=10)
 ax.set_xticks(range(4),labels);ax.set_title(title,loc='left',fontsize=12,pad=20);ax.grid(axis='y',alpha=.18,zorder=0);ax.set_ylim(0,max(r[key] for r in rows)*1.2)
fig.suptitle('固定 4K 输入：CPU 分担开关与 Prefill 分块对照',x=.06,ha='left',fontsize=17,fontweight='bold')
fig.text(.06,.02,'RTX 3090 / 32GB · 4392 输入 token · 每组 6 次 · 柱为均值，点为单次；圆点正序，叉号反序\n7 workers / MTP 4 / 尾部跳过关闭；各进程完整预热 2 次，前缀复用 0。CPU 时间为所有线程之和，可超过墙钟时间。',fontsize=10,color='#586970')
fig.subplots_adjust(left=.06,right=.98,bottom=.24,top=.8,wspace=.26)
fig.savefig(P/'prefill-ablation.png',dpi=170)
