#!/usr/bin/env python3
import os,sys,json,time,signal,subprocess,hashlib,threading,re,urllib.request,datetime,fcntl
from pathlib import Path
ROOT=Path('/opt/strata-demo/prefill-ablation-20261014');REPO=ROOT.parent/'Strata';URL='http://127.0.0.1:8081'
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2))
def stamp():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def snap(endpoint,timeout=5):
 try:
  with urllib.request.urlopen(URL+endpoint,timeout=timeout) as r:return json.load(r)
 except Exception as e:return {'error':repr(e)}
def procstat(pid):
 try:
  p=Path('/proc')/str(pid);st=(p/'stat').read_text().rsplit(') ',1)[1].split()
  return {'pid':pid,'cpu_ticks':int(st[11])+int(st[12]),'major_faults':int(st[9]),'rss_bytes':int(st[21])*4096,'io':{k:int(v) for k,v in (x.split(':') for x in (p/'io').read_text().splitlines())}}
 except Exception:return {}
def child(pid):
 try:return int((Path('/proc')/str(pid)/'task'/str(pid)/'children').read_text().split()[0])
 except Exception:return None
def sample(out,pid,stop):
 with out.open('w') as f:
  while not stop.is_set():
   r={'utc':stamp(),'time':time.time(),'proc':procstat(pid)}
   r['meminfo']={k:int(v.strip().split()[0])*1024 for k,v in (x.split(':') for x in Path('/proc/meminfo').read_text().splitlines()) if k in ['MemAvailable','MemFree','Cached','Mlocked','SwapFree']}
   r['diskstats']=[x.split() for x in Path('/proc/diskstats').read_text().splitlines() if x.split()[2]=='vda']
   r['cpu_stat']=Path('/proc/stat').read_text().splitlines()[0]
   try:r['gpu']=subprocess.check_output(['nvidia-smi','--query-gpu=utilization.gpu,memory.used,power.draw,temperature.gpu,clocks.sm,clocks.mem,pcie.link.gen.current,pcie.link.width.current','--format=csv,noheader,nounits'],text=True,timeout=3).strip()
   except Exception as e:r['gpu_error']=repr(e)
   f.write(json.dumps(r)+'\n');f.flush();stop.wait(2)
def request(case,msgs,out,pid,log):
 payload={'model':'qwen3.8-flash-next-iq2_xs','messages':msgs,'temperature':0,'seed':20261013,'reasoning_effort':'none','max_tokens':case['max_tokens'],'stream':True,'stream_options':{'include_usage':True}}
 payload.update({'strata_tune':case['tune']} if case.get('tune') else {})
 rec={'id':case['id'],'case_id':case.get('case_id',case['id']),'request':payload,'utc':stamp(),'time':time.time(),'content':'','reasoning':'','events':[],'sse_done':False,'error':None,'before':procstat(pid),'ttft':None}
 offset=log.stat().st_size if log.exists() else 0;t=time.perf_counter()
 try:
  q=urllib.request.Request(URL+'/v1/chat/completions',data=json.dumps(payload).encode(),headers={'Content-Type':'application/json'})
  with urllib.request.urlopen(q,timeout=600) as r:
   rec['http_status']=r.status
   for line in r:
    if not line.startswith(b'data:'):continue
    raw=line[5:].strip()
    if raw==b'[DONE]':rec['sse_done']=True;break
    event=json.loads(raw);elapsed=time.perf_counter()-t;rec['events'].append({'seconds':elapsed,'data':event})
    if 'error' in event:rec['error']=event['error']
    for c in event.get('choices',[]):
     d=c.get('delta') or {};s=d.get('content') or '';rec['content']+=s;rec['reasoning']+=d.get('reasoning_content') or d.get('reasoning') or ''
     if s and rec['ttft'] is None:rec['ttft']=elapsed
     if c.get('finish_reason'):rec['finish_reason']=c['finish_reason']
    for k in ['usage','timings']:
     if k in event:rec[k]=event[k]
 except Exception as e:rec['error']=repr(e)
 rec['e2e']=time.perf_counter()-t;rec['after']=procstat(pid);time.sleep(.15)
 rec['engine_log']=log.read_bytes()[offset:].decode(errors='replace') if log.exists() else ''
 (out/(case['id']+'.engine.log')).write_text(rec['engine_log']);save(out/(case['id']+'.json'),rec);(out/(case['id']+'.txt')).write_text(rec['content'])
 summary={k:rec.get(k) for k in ['id','finish_reason','ttft','e2e','error','usage','timings']};print(json.dumps(summary,ensure_ascii=False),flush=True)
 return rec

def stop_server(p):
 if p and p.poll() is None:
  os.killpg(p.pid,signal.SIGTERM)
  try:p.wait(timeout=20)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()

def main():
 ROOT.mkdir(exist_ok=True);lock=(ROOT/'run.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 plans=json.loads((ROOT/sys.argv[1]).read_text());cases=json.loads((ROOT/'cases.json').read_text())['cases'];base=json.loads((REPO/'strata-iq2_xs.json').read_text());save(ROOT/'original-config.json',base)
 # Stop only the saved original server while it is idle.
 for line in subprocess.check_output(['ps','-eo','pid,args'],text=True).splitlines():
  if 'serve/server.py' in line and '--port 8080' in line and str(REPO) in line:
   pid=int(line.strip().split()[0]);cp=child(pid)
   try:
    with urllib.request.urlopen('http://127.0.0.1:8080/slots',timeout=5) as r:assert not any(x.get('is_processing') for x in json.load(r))
   except urllib.error.URLError:
    assert (ROOT/'restored-server.pid').exists() and int((ROOT/'restored-server.pid').read_text())==pid, 'unknown service not ready'
   save(ROOT/'original-process.json',{'pid':pid,'child':cp,'command':line});os.kill(pid,signal.SIGTERM)
   if cp:
    try:os.kill(cp,signal.SIGTERM)
    except ProcessLookupError:pass
   time.sleep(3)
 p=None
 try:
  for plan in plans:
   d=ROOT/plan['id'];d.mkdir(exist_ok=False);cfg=json.loads(json.dumps(base));cfg['port']=8081;cfg['log']=str(d/'engine.log');cfg['open_browser']=False
   for flag,value in plan.get('args',{}).items():
    if flag in cfg['args']:
     i=cfg['args'].index(flag);cfg['args'][i+1]=str(value)
    else:cfg['args']+=[flag,str(value)]
   cfg['args']+=plan.get('flags',[]);save(d/'config.json',cfg);env=os.environ.copy();env.pop('STRATA_ROUTE_TAIL_SKIP',None)
   if plan.get('tail')=='off':env['STRATA_ROUTE_TAIL_SKIP']='0'
   env.pop('STRATA_PREFILL_CPU_SHARE',None);env.pop('STRATA_PREFILL_CPU_SHARE_MAX',None);env.pop('STRATA_PREFILL_STREAM_MIN',None)
   if plan['share']=='off':env['STRATA_PREFILL_CPU_SHARE']='0'
   save(d/'plan.json',plan);f=(d/'server.out').open('w');loadtime=time.monotonic()
   p=subprocess.Popen([str(REPO/'.venv/bin/python'),str(REPO/'serve/server.py'),'--engine','strata','--config',str(d/'config.json'),'--port','8081'],cwd=REPO,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
   print(json.dumps({'group':plan['id'],'status':'loading','pid':p.pid}),flush=True)
   for _ in range(300):
    health=snap('/health')
    if health.get('loaded'):break
    if p.poll() is not None:raise RuntimeError('server exited '+plan['id'])
    time.sleep(2)
   else:raise RuntimeError('load timeout')
   pid=child(p.pid);save(d/'environment.json',{'health':health,'engine_pid':pid,'load_seconds':time.monotonic()-loadtime,'engine_sha256':hashlib.sha256((REPO/'engine/strata').read_bytes()).hexdigest(),'prefill_cpu_share':env.get('STRATA_PREFILL_CPU_SHARE'),'tail_env':env.get('STRATA_ROUTE_TAIL_SKIP'),'utc':stamp()})
   stop=threading.Event();th=threading.Thread(target=sample,args=(d/'resources.jsonl',pid,stop),daemon=True);th.start();sessions={}
   try:
    original=next(c for c in cases if c['id']=='long_read')
    for wi in range(2):
     warm=dict(original,id=f'warmup-{wi+1}')
     request(warm,[{'role':'user','content':warm['prompt']}],d,pid,d/'engine.log')
    for rep in range(plan.get('suite_repeats',1)):
     sessions={}
     for original in (json.loads((ROOT/plan['cases_file']).read_text())['cases'] if plan.get('cases_file') else cases):
      if plan.get('cases') and original['id'] not in plan['cases']:continue
      case=dict(original);case['case_id']=original['id']
      if plan.get('suite_repeats',1)>1:case['id']=f'r{rep+1}--'+case['id']
      key=case.get('session');msgs=sessions.get(key,[]) + [{'role':'user','content':case['prompt']}]
      rec=request(case,msgs,d,pid,d/'engine.log')
      if key:sessions[key]=msgs+[{'role':'assistant','content':rec['content']}]
      if rec['error'] or not rec['sse_done']:raise RuntimeError('request failed '+case['id'])
      assert re.search(r'prompt 4392 tokens = 0 reused \+ 4392 read',rec['engine_log']), 'unexpected prefix reuse or prompt length'
      assert rec.get('finish_reason')=='stop', 'truncated response'
      if plan.get('repair') and original['id']=='code_retry':
       fix={'id':f'r{rep+1}--code_retry_fix','case_id':'code_retry','max_tokens':1024}
       feedback='边界测试 retry_delays(10000,0.5,4) 触发 OverflowError: int too large to convert to float。请修复，保持原题函数签名和所有边界规则，只输出python代码块。'
       request(fix,msgs+[{'role':'assistant','content':rec['content']},{'role':'user','content':feedback}],d,pid,d/'engine.log')
    if plan.get('runtime_sweep'):
     import runtime_sweep
     runtime_sweep.run(d,pid,d/'engine.log')
    save(d/'completed.json',{'utc':stamp(),'status':'complete'})
   finally:stop.set();th.join(timeout=5);stop_server(p);p=None;f.close()
 finally:
  stop_server(p)
  f=(ROOT/'restored-server.out').open('a');p=subprocess.Popen([str(REPO/'start-optimized-3090.sh')],cwd=REPO,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);(ROOT/'restored-server.pid').write_text(str(p.pid));print('Restoring optimized service PID '+str(p.pid),flush=True)
  for _ in range(300):
   try:
    with urllib.request.urlopen('http://127.0.0.1:8080/health',timeout=3) as r: h=json.load(r)
    if h.get('loaded'):break
   except Exception:pass
   time.sleep(2)
  else:raise RuntimeError('restore load timeout')
  ep=child(p.pid);save(ROOT/'restoration.json',{'health':h,'pid':p.pid,'engine_pid':ep,'engine_env':[x for x in (Path('/proc')/str(ep)/'environ').read_text().split('\0') if x.startswith('STRATA_')] if ep else [],'utc':stamp()})
  print('Optimized service loaded',flush=True)
if __name__=='__main__':main()
