from pathlib import Path
import json,hashlib,re
P=Path(__file__).parent;R=P/'remote'
rows=json.loads((P/'results.json').read_text());measured=[r for r in rows if r['phase']=='measured'];warm=[r for r in rows if r['phase']=='warmup']
assert len(measured)==24 and len(warm)==16,(len(measured),len(warm))
assert all(r['fields_correct']==5 and r['finish']=='stop' and r['sse_done'] and r['error'] is None for r in measured)
assert all(r['prompt_tokens']==4392 and r['read_tokens']==4392 and r['reused_tokens']==0 for r in measured)
sha='6cc0dda09c0327810d590c4e15d610e8a7a8f3ab05fcfc7376da77b18054e42e'
configs=[]
for g in sorted(R.glob('0[1-8]-*')):
 assert (g/'completed.json').exists(),g
 e=json.loads((g/'environment.json').read_text());plan=json.loads((g/'plan.json').read_text());cfg=json.loads((g/'config.json').read_text())
 assert e['engine_sha256']==sha and e['tail_env']=='0'
 assert e['prefill_cpu_share']==('0' if plan['share']=='off' else None)
 args=cfg['args'];i=args.index('--prefill');args=args.copy();args[i+1]='CHUNK';configs.append(args)
 text=(g/'engine.log').read_text();assert 'expert cache 13432 slots, 18.00 GiB of VRAM' in text
 if plan['share']=='auto':assert 'CPU share is ON by default' in text
 else:assert 'CPU share is ON by default' not in text
assert len(configs)==8 and all(c==configs[0] for c in configs)
assert hashlib.sha256((R/'cases.json').read_bytes()).digest()==hashlib.sha256((P/'cases.json').read_bytes()).digest()
result={'scored':len(measured),'warmup':len(warm),'all_fields_correct':True,'zero_prefix_reuse':True,'all_4392_read':True,'max_request_read_bytes':max(r['io_MB']*1e6 for r in measured),'fixed_binary_and_args':True,'completed_groups':8}
(P/'validation.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
