# Strata / RTX 3090 证据包

本文数据来自固定版本 0.1.43，源码 7695859aa13afb248bdb4d36f9b2e95707db079d。

- summary.csv/json：10月13日逐请求结果；计分请求139条，另有16条短预热。
- prefill-ablation.csv / prefill-ablation-evidence.zip：10月14日隔离对照，24个正式请求和16次完整输入预热；各配置6次，全部五字段正确、0前缀复用、请求read_bytes增量0。合计163个正式请求。
- OBSERVABILITY.md / bottleneck-observations.csv/json：从已有记录提取的分层观测方法、请求指标与八次启动PCIe校准；tools/extract_observations.py为提取脚本。没有新增性能测试。
- recordings：按组保留配置、计划、响应正文、SSE、日志、资源采样、单元测试结果。
- *.grade.json：事先固定的功能测试；*.exploratory.json：看过修复代码后补充的零值测试，分开保存。
- manual-review.json：助手按 rubric 逐条复核对话和工单；并非独立盲评或多人评分。
- 长记录的 task_passed 检查五字段内容；bare_json 另记是否带 Markdown 围栏。
- 工单原因表达存在质量问题；三个 repair 请求为 length。速度表需结合这些评分使用。

路径已替换成 /opt/strata-demo；记录的 PID 和时间用于关联采样。实际原始记录另存，未覆盖。

## 复现步骤

1. 准备相同版本、IQ2_XS 模型和环境。模型及权重不在本包内。
2. 将 cases.json、各 matrix.json、long16k-cases.json 及 tools 中脚本放在同一个测试目录。按自己的安装目录修改 run_matrix.py 的 ROOT、REPO；检查配置模型路径、专家 profile 和端口。
3. 在独占测试机中逐组执行 `python3 -u run_matrix.py baseline-matrix.json` 等。脚本会停止指定的原 8080 服务，用 8081 跑实验，然后恢复原配置；先确认目标服务和路径。每组目录必须不存在，以保护旧证据。
4. 将 grade_code.py 放在 grade_all.py 指定的临时路径。Linux 上使用 unshare -n + setpriv nobody 执行评分，依赖 root 或适当的 namespace 权限。候选代码执行有 AST、CPU、内存限制。
5. 追加探索性测试：给 grade_code.py 传 `--exploratory`；它增加 attempts=10000、base=0、cap=4 检查。不要把这一项改算为原来的冻结评分。
6. analyze.py 默认读取其旁边的 remote 目录，输出 summary；绘图脚本依赖 matplotlib。为单独分析包内记录，可把 recordings 放到 remote，或修改路径。

运行前核对单请求、32K、KV int8、温度0和输出上限。模型加载不计入请求；保留预热和请求顺序，额外报告页缓存、实际 I/O 与生成长度。对话追问的输入包含各组上一轮回答。
