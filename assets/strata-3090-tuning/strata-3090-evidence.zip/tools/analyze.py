#!/usr/bin/env python3
import json,csv,statistics,re,hashlib
from pathlib import Path
p=Path(__file__).parent;root=p/'remote';rows=[]
for g in sorted(root.iterdir()):
 if not g.is_dir() or not (g/'plan.json').exists():continue
 resources=[]
 if (g/'resources.jsonl').exists():
  for line in (g/'resources.jsonl').read_text().splitlines():
   try:resources.append(json.loads(line))
   except ValueError:pass
 files=[]
 for f in g.glob('*.json'):
  try:d=json.loads(f.read_text())
  except ValueError:continue
  if 'e2e' in d:files.append((d.get('time',0),f,d))
 last_tail=0
 for _,f,d in sorted(files):
  tm=d.get('timings',{});b=d['before'];a=d['after'];log=d.get('engine_log','');tail=re.findall(r'route tail skip: (\d+) missed experts skipped',log);ntail=int(tail[-1]) if tail else last_tail
  r={'group':g.name,'id':d['id'],'case_id':d.get('case_id',d['id'].split('-')[-1]),'complete':d.get('http_status')==200 and d.get('sse_done') and d.get('finish_reason')=='stop' and not d.get('error'),'finish_reason':d.get('finish_reason'),'ttft_s':d.get('ttft'),'e2e_s':d['e2e'],'input_tokens':d.get('usage',{}).get('prompt_tokens'),'output_tokens':tm.get('predicted_n'),'reused_tokens':tm.get('cache_n'),'prefill_tps':tm.get('prompt_per_second'),'decode_tps':tm.get('predicted_per_second'),'decode_s':tm.get('predicted_ms',0)/1000,'draft_accepted':tm.get('draft_n_accepted'),'draft_offered':tm.get('draft_n'),'acceptance':tm.get('draft_n_accepted',0)/max(1,tm.get('draft_n',0)),'tail_skipped_experts':ntail-last_tail,'read_mb':(a.get('io',{}).get('read_bytes',0)-b.get('io',{}).get('read_bytes',0))/1e6,'major_faults':a.get('major_faults',0)-b.get('major_faults',0),'cpu_core_equiv':(a.get('cpu_ticks',0)-b.get('cpu_ticks',0))/100/d['e2e'],'output_sha256':hashlib.sha256(d['content'].encode()).hexdigest()};last_tail=ntail
  s=[x for x in resources if d['time']<=x['time']<=d['time']+d['e2e']];gpu=[]
  for x in s:
   try:gpu.append([float(v.strip()) for v in x['gpu'].split(',')])
   except Exception:pass
  if gpu:r.update(gpu_util_mean=statistics.mean(x[0] for x in gpu),gpu_power_mean_w=statistics.mean(x[2] for x in gpu),gpu_temperature_max=max(x[3] for x in gpu),gpu_vram_peak_mib=max(x[1] for x in gpu),ram_available_min_gib=min(x['meminfo']['MemAvailable'] for x in s)/1024**3)
  if (g/(d['id']+'.grade.json')).exists():
   try:gr=json.loads((g/(d['id']+'.grade.json')).read_text());r.update(tests_passed=gr.get('passed'),tests_total=gr.get('total'),tests_all_passed=gr.get('all_passed'),task_passed=bool(gr.get('all_passed') and r['complete']))
   except ValueError:pass
  if d.get('case_id',d['id']).startswith('long_read'):
   try:
    text=re.sub(r'^```(?:json)?\s*|\s*```$','',d['content'].strip());r['bare_json']=text==d['content'].strip();j=json.loads(text);r['task_passed']=r['complete'] and j=={'cancelled_id':'R017','cancelled_owner':'林青','cancel_reason':'容量评估未通过','approved_id':'R089','rollback_threshold':'错误率超过2%'};r['parsed']=j
   except ValueError:r['task_passed']=False
  rows.append(r)
(p/'summary.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2));keys=sorted(set(k for r in rows for k in r if k!='parsed'))
with (p/'summary.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=keys,extrasaction='ignore');w.writeheader();w.writerows(rows)
for r in rows:
 if r['id']!='warmup':print(f"{r['group']:20s} {r['id']:20s} total={r['e2e_s']:6.1f}s decode={r['decode_tps']} pass={r.get('task_passed')} IO={r['read_mb']:.0f}MB")
