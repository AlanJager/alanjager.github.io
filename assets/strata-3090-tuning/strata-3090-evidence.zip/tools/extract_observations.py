from pathlib import Path
import json,csv,re,statistics
P=Path(__file__).resolve().parent
if P.name=='tools':P=P.parent
Q=P.parent/'strata-prefill-ablation-20261014'
if not Q.exists():Q=P/'prefill-ablation'
R=P/'remote' if (P/'remote').exists() else P/'recordings'
QR=Q/'remote' if (Q/'remote').exists() else Q/'recordings'
rows=json.loads((P/'summary.json').read_text())
selected=[r for r in rows if (r['group']=='confirm-candidate-off' and r['id'] in ['r2--code_retry_fix','r2--code_log','r1--long_read']) or (r['group'] in ['off-a','off-b'] and r['id']=='code_merge') or r['decode_tps']==149.7]
for r in selected:
 r['recording_archive']='strata-3090-evidence.zip'
 r['recording']='recordings/'+r['group']+'/'+r['id']+'.json'
 log=(R/r['group']/(r['id']+'.engine.log')).read_text()
 hit=re.search(r'decode expert cache hit rate: ([\d.]+)%',log)
 blobs=re.search(r'(\d+) blob reads from the file',log)
 if hit:r['decode_expert_cache_hit_pct']=float(hit[1])
 if blobs:r['expert_blob_file_reads']=int(blobs[1])
cal=[]
for g in sorted(QR.glob('0[1-8]-*')):
 log=(g/'engine.log').read_text();match=re.search(r'PCIe probe: ([\d.]+) GB/s.*?-> pcie_frac ([\d.]+)',log)
 cal.append({'group':g.name,'recording_archive':'prefill-ablation-evidence.zip','startup_h2d_GB_s':float(match[1]),'initial_pcie_frac':float(match[2]),'recording':'recordings/'+g.name+'/engine.log'})
x={'provenance':'Re-extracted from existing 2026-10-13/14 recordings; no new benchmark.', 'selected_requests':selected,'prefill_ablation':json.loads((Q/'summary.json').read_text()),'startup_pcie_probes':cal,'methods':{'read_mb':'Delta /proc/PID/io read_bytes / 1e6 over request; includes prefill and decode, excludes model load','major_faults':'Delta /proc/PID/stat field 12 (majflt), process only, excluding child faults','cpu_seconds':'Delta process utime+stime divided by CLK_TCK=100 on tested Linux; all threads, both stages','gpu':'nvidia-smi util/memory/power/temp/clocks sampled every 2 seconds and filtered by request interval','ram_available':'Minimum /proc/meminfo MemAvailable among samples inside request interval','acceptance':'Sum draft_n_accepted / sum draft_n within the stated task set','startup_h2d':'Engine startup probe, best of four; initialization/calibration only','pcie_activity':'Reverse groups only, nvidia-smi dmon -s t -d 1 -o DT; local timestamps UTC+08:00; sampled rates, not total bytes'}}
(P/'bottleneck-observations.json').write_text(json.dumps(x,ensure_ascii=False,indent=2))
keys=['group','id','ttft_s','e2e_s','decode_tps','read_mb','major_faults','gpu_util_mean','gpu_power_mean_w','ram_available_min_gib','recording']
with (P/'bottleneck-observations.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=keys,extrasaction='ignore');w.writeheader();w.writerows(selected)
print('extracted',len(selected),'request records and',len(cal),'startup probes')
