import json,subprocess
from pathlib import Path
p=Path('/opt/strata-demo/ab-3090-20261013')
for g in p.iterdir():
 if not g.is_dir():continue
 for f in g.glob('*.json'):
  if f.name.endswith('.grade.json'): continue
  try:rec=json.loads(f.read_text())
  except Exception:continue
  if not isinstance(rec,dict):continue
  name=rec.get('case_id',str(rec.get('id','')).split('-')[-1])
  if name not in ['code_merge','code_retry','code_log'] or 'content' not in rec:continue
  out=f.with_suffix('.grade.json')
  if out.exists() and out.stat().st_size:continue
  r=subprocess.run(['unshare','-n','setpriv','--reuid=65534','--regid=65534','--clear-groups','python3','-I','/tmp/strata-grade-20261013.py','-'],input=f.read_text(),capture_output=True,text=True,timeout=12)
  if r.returncode:result={'id':name,'all_passed':False,'grader_error':r.stderr,'sandbox':'nobody, network namespace, AST allowlist, RLIMIT_CPU=5, RLIMIT_AS=384MiB'}
  else:result=json.loads(r.stdout)
  out.write_text(json.dumps(result,ensure_ascii=False,indent=2));print(g.name,f.stem,result.get('passed'),result.get('total'),result['all_passed'])
