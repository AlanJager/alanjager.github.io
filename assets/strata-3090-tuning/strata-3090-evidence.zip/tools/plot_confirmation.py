from pathlib import Path
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
p=Path(__file__).parent
s=json.loads((p/'summary.json').read_text())
plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Arial Unicode MS','DejaVu Sans'],'axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'#f7f8fa','axes.facecolor':'#f7f8fa','font.size':11})
groups=['confirm-original-off','tune-prefill1024','tune-prefill2048','tune-prefill4096','confirm-candidate-off']
labels=['256 / 原配置\n2 次','1024 / 单项筛选\n1 次','2048 / 单项筛选\n1 次','4096 / 单项筛选\n1 次','2048 / 候选配置\n2 次']
fig,ax=plt.subplots(figsize=(11,4.6));fig.suptitle('同一份 4392-token 输入：首次输出等待缩短到约 3.3 秒',fontsize=15,fontweight='bold')
for i,g in enumerate(groups):
 vals=[r['ttft_s'] for r in s if r['group']==g and r['case_id']=='long_read']
 ax.scatter([i]*len(vals),vals,color='#247b91',s=65,zorder=3)
 ax.text(i,max(vals)+.35,' / '.join(f'{v:.2f}' for v in vals),ha='center',fontsize=10)
ax.set_xticks(range(len(groups)),labels);ax.set_ylabel('首字时间（秒）');ax.set_ylim(0,11);ax.grid(axis='y',alpha=.2)
fig.text(.03,.02,'原配置与单项筛选：15 workers；候选：7 workers + aux-cpus auto。均关闭尾部跳过，全部提取正确。',fontsize=9)
fig.tight_layout(rect=[0,.07,1,.93]);fig.savefig(p/'prefill-comparison.png',dpi=170);plt.close(fig)

cases=['dialogue_capacity','dialogue_followup','code_merge','code_retry','code_log','long_read']
labels=['对话首轮','对话追问','区间合并','指数退避*','日志聚合','4K 提取']
fig,ax=plt.subplots(figsize=(11,5.2));fig.suptitle('相同候选配置：尾部跳过开关下的两次实际观测',fontsize=15,fontweight='bold')
for j,(g,name,col) in enumerate([('confirm-candidate-off','关闭','#247b91'),('confirm-candidate-default','默认','#dd9651')]):
 for i,c in enumerate(cases):
  vals=[r['decode_tps'] for r in s if r['group']==g and r['case_id']==c and not r['id'].endswith('_fix')]
  x=i+(j-.5)*.23
  ax.plot([x,x],[min(vals),max(vals)],color=col,lw=2)
  ax.scatter([x]*len(vals),vals,color=col,s=40,label=name if i==0 else None,zorder=3)
ax.set_xticks(range(len(cases)),labels);ax.set_ylabel('引擎 decode token/s');ax.set_ylim(0,140);ax.legend(frameon=False,ncol=2);ax.grid(axis='y',alpha=.2)
fig.text(.035,.025,'每点为一次请求；页缓存状态不同，输出长度与 I/O 量见明细。* 指数退避均未通过溢出测试。',fontsize=9)
fig.tight_layout(rect=[0,.065,1,.94]);fig.savefig(p/'tail-comparison.png',dpi=170);plt.close(fig)

fig,aa=plt.subplots(3,1,figsize=(12,7.5),sharex=True);fig.suptitle('候选配置关闭尾部跳过：代码修复与随后任务的资源变化',fontsize=15,fontweight='bold')
g='confirm-candidate-off';rr=[json.loads(x) for x in (p/'remote'/g/'resources.jsonl').read_text().splitlines()]
req=[json.loads((p/'remote'/g/(x+'.json')).read_text()) for x in ['r2--code_retry_fix','r2--code_log','r2--long_read']]
start=req[0]['time'];end=req[-1]['time']+req[-1]['e2e'];rr=[x for x in rr if start-2<=x['time']<=end+2 and x.get('proc')]
t=np.array([x['time']-start for x in rr]);io=np.array([x['proc']['io']['read_bytes'] for x in rr]);gpu=[float(x['gpu'].split(',')[0]) for x in rr];mem=[x['meminfo']['MemAvailable']/1024**3 for x in rr]
aa[0].plot(t,gpu,color='#247b91');aa[0].set_ylabel('GPU 利用率 %');aa[0].set_ylim(0,108)
aa[1].plot(t,mem,color='#748b54');aa[1].set_ylabel('MemAvailable GiB')
aa[2].plot(t[1:],np.diff(io)/np.diff(t)/1e6,color='#cc8844');aa[2].set_ylabel('进程读取 MB/s');aa[2].set_xlabel('第二轮代码修复开始后的秒数')
for d,name in zip(req,['代码修复 · 77.5 秒 · 输出截断','日志聚合 · 61.3 秒 · 测试通过','4K 提取']):
 x=d['time']-start
 for a in aa:a.axvline(x,ls='--',color='#abb2b9',lw=.8)
 aa[0].text(x+1,105,name,fontsize=9,va='top',rotation=90 if name=='4K 提取' else 0)
for a in aa:a.grid(alpha=.2)
fig.text(.035,.01,'2 秒采样；进程 read_bytes 差分。显示请求期间实际读取，采样点之间的瞬时变化未保留。',fontsize=9)
fig.tight_layout(rect=[0,.035,1,.94]);fig.savefig(p/'candidate-timeline.png',dpi=170);plt.close(fig)
print('confirmation charts generated')
