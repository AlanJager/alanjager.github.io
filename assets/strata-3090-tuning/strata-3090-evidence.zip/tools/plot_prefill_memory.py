from pathlib import Path
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
p=Path(__file__).parent
rows=json.loads((p/'prefill-memory.json').read_text())
plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Arial Unicode MS','DejaVu Sans'],'axes.spines.top':False,'axes.spines.right':False,'font.size':11,'figure.facecolor':'#f7f8fa','axes.facecolor':'#f7f8fa'})
fig,(ax,ram)=plt.subplots(1,2,figsize=(12,5.2),gridspec_kw={'width_ratios':[2.6,1]})
fig.suptitle('分块增大：prefill 临时借用更多专家缓存，decode 前回填',fontsize=16,fontweight='bold')
labels=[f"prefill {r['prefill_chunk']}" for r in rows]+['回填后 decode']
for i,r in enumerate(rows):
 keep=r['unborrowed_gib_approx'];loan=r['borrow_gib']
 ax.barh(i,keep,color='#287d90',height=.56,label='可保留专家权重' if i==0 else None)
 ax.barh(i,loan,left=keep,color='#dd9651',height=.56,label='借给 prefill 缓冲' if i==0 else None)
 ax.text(keep/2,i,f'{keep:.2f} GiB',va='center',ha='center',color='white',fontsize=10)
 ax.text(18.2,i,f'{loan:.2f} GiB',va='center',fontsize=10,color='#9b5c23')
ax.barh(4,18,color='#287d90',height=.56);ax.text(9,4,'18.00 GiB · 13,432 槽',ha='center',va='center',color='white')
ax.set_yticks(range(5),labels);ax.invert_yaxis();ax.set_xlim(0,20.5);ax.set_xticks([0,6,12,18]);ax.set_xlabel('18GiB 专家缓存区域内的用途（GiB）');ax.legend(loc='lower left',bbox_to_anchor=(0,-.34),frameon=False,ncol=2,fontsize=10);ax.grid(axis='x',alpha=.12);ax.set_axisbelow(True)
ram.barh(range(4),[r['resident_ram_gib'] for r in rows],color='#748b54',height=.56)
for i,r in enumerate(rows):ram.text(r['resident_ram_gib']+.15,i,f"{r['resident_ram_gib']:.2f}",va='center',fontsize=10)
ram.set_ylim(4.55,-.55);ram.set_xlim(0,20);ram.set_yticks([]);ram.set_xlabel('固定在 RAM 的专家（GiB）');ram.set_xticks([0,8,16]);ram.grid(axis='x',alpha=.12);ram.set_axisbelow(True)
fig.text(.035,.025,'启动日志按最大配置块规划；实际借用量可随请求变化。图只展开专家缓存区域；KV、MTP 等其他显存未分项绘制。',fontsize=9,color='#59636e')
fig.tight_layout(rect=[0,.09,1,.91]);fig.savefig(p/'prefill-memory.png',dpi=170);plt.close(fig)
