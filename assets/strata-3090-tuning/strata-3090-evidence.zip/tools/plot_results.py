from pathlib import Path
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
p=Path(__file__).parent;s=json.loads((p/'summary.json').read_text());plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Arial Unicode MS','PingFang SC','DejaVu Sans'],'axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'#f7f8fa','axes.facecolor':'#f7f8fa','font.size':10})
groups=['off-a','default-a','default-b','off-b'];labels=['关闭 A','默认 A','默认 B','关闭 B'];data=[[x for x in s if x['group']==g and x['id']!='warmup'] for g in groups];colors=['#247b91','#dd9651','#dd9651','#247b91']
fig,ax=plt.subplots(1,2,figsize=(11,4.3));fig.suptitle('运行顺序和页缓存，影响了整组任务的等待时间',fontweight='bold',fontsize=15)
for a,values,title,unit in [(ax[0],[sum(x['e2e_s'] for x in r) for r in data],'7 个请求总耗时','秒'),(ax[1],[sum(x['read_mb'] for x in r)/1000 for r in data],'请求期间实际磁盘读取','GB')]:
 bars=a.bar(labels,values,color=colors,width=.62);a.set_title(title);a.set_ylabel(unit);a.bar_label(bars,fmt='%.2f',padding=4);a.set_ylim(0,max(values)*1.2);a.grid(axis='y',alpha=.2);a.set_axisbelow(True)
fig.text(.04,.015,'Strata 0.1.43 / 3090 24GB / 32GB RAM / IQ2_XS；每组重新加载；页缓存随装载和请求变化。包含不同输出长度。',fontsize=9,color='#56616d');fig.tight_layout(rect=[0,.06,1,.91]);fig.savefig(p/'baseline-cache-effect.png',dpi=170);plt.close(fig)
# One complete first-run resource timeline; sampling every 2 seconds, request boundaries from wall clock.
g='off-a';resources=[json.loads(l) for l in (p/'remote'/g/'resources.jsonl').read_text().splitlines()];rr=[x for x in resources if x.get('proc')];start=min(x['time'] for x in rr);t=np.array([x['time']-start for x in rr]);mem=[x['meminfo']['MemAvailable']/1024**3 for x in rr];io=np.array([x['proc']['io']['read_bytes'] for x in rr]);rate=np.diff(io)/np.diff(t)/1e6;gpu=[float(x['gpu'].split(',')[0]) for x in rr];power=[float(x['gpu'].split(',')[2]) for x in rr]
fig,aa=plt.subplots(3,1,figsize=(12,7),sharex=True);fig.suptitle('首组关闭尾部跳过：GPU、可用内存与磁盘读取同一时间轴',fontsize=15,fontweight='bold');aa[0].plot(t,gpu,color='#247b91',lw=1.2);aa[0].set_ylabel('GPU 利用率 %');aa[0].set_ylim(0,105);aa[1].plot(t,mem,color='#748b54');aa[1].set_ylabel('MemAvailable GiB');aa[2].plot(t[1:],rate,color='#cc8844');aa[2].set_ylabel('进程读取 MB/s');aa[2].set_xlabel('预热开始后的秒数')
ids={'dialogue_capacity':'问答1','dialogue_followup':'问答2','incident_extract':'工单','code_merge':'合并','code_retry':'退避','code_log':'日志','long_read':'长文'}
for f in (p/'remote'/g).glob('*.json'):
 d=json.loads(f.read_text())
 if d.get('id') not in ids or 'time' not in d:continue
 x=d['time']-start
 for a in aa:a.axvline(x,color='#abb2b9',lw=.7,ls='--')
 aa[0].text(x+1,102,ids[d['id']],fontsize=8,rotation=90,va='top')
for a in aa:a.grid(alpha=.2)
fig.tight_layout(rect=[0,0,1,.95]);fig.savefig(p/'resource-timeline.png',dpi=170);plt.close(fig)
print('charts generated')
