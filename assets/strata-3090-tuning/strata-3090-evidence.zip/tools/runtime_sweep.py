#!/usr/bin/env python3
# Run only after the startup-tuning matrix; use isolated service on 8081.
import importlib.util,json,sys,time,threading
from pathlib import Path
p=Path('/opt/strata-demo/ab-3090-20261013');spec=importlib.util.spec_from_file_location('matrix',p/'run_matrix.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
# This file is a prepared extension; orchestrator hooks call run() with an already loaded server.
def run(out,pid,log):
 cases={x['id']:x for x in json.loads((p/'cases.json').read_text())['cases']};results=[]
 settings=[('pcie0',{'pcie_frac':0}),('pcie03',{'pcie_frac':.3}),('pcie06',{'pcie_frac':.6}),('pcie1',{'pcie_frac':1}),('mtp03',{'spec_min_p':.3}),('mtp07',{'spec_min_p':.7}),('aux1',{'aux_cpus':1})]
 for cycle,seq in enumerate([settings,list(reversed(settings))]):
  for name,tune in seq:
   for task in ['code_merge','incident_extract']:
    case=dict(cases[task]);case['id']=f'sweep-{cycle}-{name}-{task}';case['tune']=tune;case['case_id']=task
    rec=m.request(case,[{'role':'user','content':case['prompt']}],out,pid,log);results.append({'cycle':cycle,'setting':name,'task':task,'id':case['id'],'tune':tune})
 (out/'sweep-index.json').write_text(json.dumps(results,indent=2))
