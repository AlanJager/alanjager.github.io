from pathlib import Path
import json,subprocess
p=Path('/opt/strata-demo/ab-3090-20261013')
refs={
'code_merge':'''def merge_intervals(intervals):
    for a,b in intervals:
        if a>b: raise ValueError()
    out=[]
    for a,b in sorted(intervals):
        if out and a<=out[-1][1]: out[-1][1]=max(out[-1][1],b)
        else: out.append([a,b])
    return out''',
'code_retry':'''def retry_delays(attempts,base,cap):
    if isinstance(attempts,bool) or not isinstance(attempts,int): raise TypeError()
    if attempts<0 or base<0 or cap<0: raise ValueError()
    out=[];v=min(base,cap)
    for _ in range(attempts):
        out.append(v);v=min(v*2,cap)
    return out''',
'code_log':'''import json,math

def summarize(lines):
    groups={}
    for line in lines:
        try: d=json.loads(line)
        except Exception: continue
        if not isinstance(d,dict): continue
        s=d.get('service');st=d.get('status');v=d.get('latency_ms')
        if not isinstance(s,str) or not s or isinstance(st,bool) or not isinstance(st,int) or not 100<=st<=599 or isinstance(v,bool) or not isinstance(v,(int,float)) or v<0: continue
        groups.setdefault(s,[]).append((v,st>=500))
    return [dict(service=s,count=len(a),errors=sum(e for v,e in a),p95_ms=sorted(v for v,e in a)[math.ceil(.95*len(a))-1]) for s,a in sorted(groups.items())]'''}
checks=[]
for name,code in refs.items():
 r=subprocess.run(['unshare','-n','setpriv','--reuid=65534','--regid=65534','--clear-groups','python3','-I','/tmp/strata-grade-20261013.py','-'],input=json.dumps({'id':name,'content':code}),text=True,capture_output=True,timeout=12)
 assert r.returncode==0,r.stderr
 v=json.loads(r.stdout);assert v['all_passed'],v;checks.append({k:v[k] for k in ['id','passed','total','all_passed']})
(p/'grader-selfcheck.json').write_text(json.dumps(checks,indent=2));print(checks)
