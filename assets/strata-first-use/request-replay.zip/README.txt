Strata 上手请求复测

来源：2026-10-13 实际使用的 run_dialogue.py 和保存的用户题目。
公开副本通过可选的 --config 指定本机配置文件，移除了固定安装路径。

准备
1. 安装本文的模型与引擎，把配置 args 中的 --prefill 改为256。
2. 启动服务，确认 http://127.0.0.1:8080/health 返回 loaded=true。
3. 在运行 Strata 的机器执行下面命令。脚本只依赖 Python 标准库。

中文四轮
python3 run_dialogue.py --out replay-chinese --session chinese --plan dialogue-plan.json

鹈鹕四轮（原始生成、两次修改、短控制）
python3 run_dialogue.py --out replay-pelican --session pelican --plan pelican-plan.json

新会话修改（使用原实验首轮SVG作为输入）
python3 run_dialogue.py --out replay-fresh --session fresh --plan fresh-edit-plan.json

参数
--url 默认 http://127.0.0.1:8080。
--config 可选，本机配置文件；例如 --config strata-iq2_xs.json。
--prompt 单条用户消息；与 --plan 二选一。
--max-tokens 用于 --prompt 模式；plan模式使用每一轮自己的max_tokens。
所有请求为 temperature=0、reasoning_effort=none，逐轮执行。
每次完整实验使用新的 --out 目录；已有 session.json 的会话会追加历史。

输出
每轮 turn-NN.json：完整请求、SSE事件、正文、思考、首字与结束时间、usage、finish_reason和metrics。
每轮 turn-NN.txt：正文。
session.json：实际用户/助手历史、请求汇总及服务状态；提供--config时另存配置与哈希。
首字从请求开始计到第一段正文；总耗时计到流式请求结束。
HTTP错误、流式缺少结束标记或finish_reason非stop时保留数据并退出。
脚本保存模型生成内容，由读者另行检查代码或渲染SVG。
