#!/usr/bin/env python3
"""Sequential loopback chat; records full SSE and resends real assistant history."""
import argparse
import datetime
import hashlib
import json
import pathlib
import time
import urllib.request

p = argparse.ArgumentParser()
p.add_argument('--out', required=True)
p.add_argument('--session', required=True)
p.add_argument('--plan')
p.add_argument('--prompt')
p.add_argument('--max-tokens', type=int, default=4096)
p.add_argument('--url', default='http://127.0.0.1:8080')
p.add_argument('--config', help='Optional local Strata config file to record')
a = p.parse_args()
out = pathlib.Path(a.out) / a.session
out.mkdir(parents=True, exist_ok=True)

def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2))

def snap(endpoint):
    try:
        with urllib.request.urlopen(a.url + endpoint, timeout=30) as r:
            return json.load(r)
    except Exception as e:
        return {'error': repr(e)}

state_path = out / 'session.json'
if state_path.exists():
    state = json.loads(state_path.read_text())
else:
    config_path = pathlib.Path(a.config) if a.config else None
    config = config_path.read_bytes() if config_path and config_path.exists() else b''
    state = {'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
             'messages': [], 'turns': [], 'health_before': snap('/health'),
             'models': snap('/v1/models'), 'config_sha256': hashlib.sha256(config).hexdigest() if config else None,
             'config': json.loads(config) if config else None,
             'measurement': 'server-side loopback, normal engine, no MoE instrumentation; cache not cleared; model load excluded',
             'sample_scope': 'one sequential session per task; not benchmark/quantization comparison'}
    save(state_path, state)
if not state['health_before'].get('loaded'):
    raise SystemExit('Model must already be loaded')
turns = json.loads(pathlib.Path(a.plan).read_text())['turns'] if a.plan else [{'prompt': a.prompt, 'max_tokens': a.max_tokens}]
for turn in turns:
    number = len(state['turns']) + 1
    messages = state['messages'] + [{'role': 'user', 'content': turn['prompt']}]
    payload = {'model': state['health_before']['model'], 'messages': messages,
               'temperature': 0, 'reasoning_effort': 'none', 'max_tokens': turn['max_tokens'],
               'stream': True, 'stream_options': {'include_usage': True}}
    record = {'turn': number, 'request': payload, 'content': '', 'reasoning': '', 'events': [],
              'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'http_status': None, 'sse_done': False, 'finish_reason': None,
              'ttft_content_seconds': None, 'ttft_any_seconds': None, 'error': None}
    started = time.perf_counter()
    print(json.dumps({'session': a.session, 'turn': number, 'status': 'started'}, ensure_ascii=False), flush=True)
    try:
        req = urllib.request.Request(a.url + '/v1/chat/completions', data=json.dumps(payload).encode(), headers={'Content-Type': 'application/json'})
        with urllib.request.urlopen(req, timeout=1800) as r:
            record['http_status'] = r.status
            for line in r:
                if not line.startswith(b'data:'):
                    continue
                data = line[5:].strip()
                if data == b'[DONE]':
                    record['sse_done'] = True
                    break
                event = json.loads(data)
                elapsed = time.perf_counter() - started
                record['events'].append({'elapsed_seconds': elapsed, 'data': event})
                for choice in event.get('choices', []):
                    delta = choice.get('delta') or {}
                    content = delta.get('content') or ''
                    reasoning = delta.get('reasoning_content') or delta.get('reasoning') or ''
                    if (content or reasoning) and record['ttft_any_seconds'] is None:
                        record['ttft_any_seconds'] = elapsed
                    if content and record['ttft_content_seconds'] is None:
                        record['ttft_content_seconds'] = elapsed
                        print(json.dumps({'session': a.session, 'turn': number, 'first_content_seconds': elapsed}), flush=True)
                    record['content'] += content
                    record['reasoning'] += reasoning
                    if choice.get('finish_reason'):
                        record['finish_reason'] = choice['finish_reason']
                for field in ['usage', 'timings']:
                    if field in event:
                        record[field] = event[field]
    except Exception as e:
        record['error'] = {'type': type(e).__name__, 'detail': str(e)}
    record['e2e_seconds'] = time.perf_counter() - started
    record['metrics_after'] = snap('/metrics')
    save(out / f'turn-{number:02}.json', record)
    (out / f'turn-{number:02}.txt').write_text(record['content'])
    summary = {k: record.get(k) for k in ['turn', 'http_status', 'sse_done', 'finish_reason', 'ttft_content_seconds', 'e2e_seconds', 'usage', 'error']}
    state['turns'].append(summary)
    state['messages'] = messages + [{'role': 'assistant', 'content': record['content']}]
    state['health_after'] = snap('/health')
    save(state_path, state)
    print(json.dumps(summary, ensure_ascii=False), flush=True)
    if record['error'] or not record['sse_done'] or record['finish_reason'] != 'stop':
        raise SystemExit('Turn failed or truncated; retained raw record, no automatic retry')
